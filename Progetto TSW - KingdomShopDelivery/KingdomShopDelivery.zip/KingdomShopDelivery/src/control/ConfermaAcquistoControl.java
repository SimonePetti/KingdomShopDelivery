package control;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import model.dao.IndirizzoDao;
import model.dao.CartaDao;
import model.dao.interfacce.IndirizzoDaoInterfaccia;
import model.dao.interfacce.CartaDaoInterfaccia;

import java.math.BigDecimal;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.ArrayList;

public class ConfermaAcquistoControl extends HttpServlet {
	
	private static final long serialVersionUID = 1L;
	
	static IndirizzoDaoInterfaccia IndirizzoDao = new IndirizzoDao();
	static CartaDaoInterfaccia CartaDao = new CartaDao();
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.sendRedirect("/home");
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		HttpSession session = request.getSession(true);

		if(session.getAttribute("idUtente") == null) {
			response.sendRedirect("login.jsp?sendRedirect=confermaAcquisto");
			return;
		} else {
			response.sendRedirect("./confermaAcquisto/indirizzo");
		}
	}

}

package control;

import javax.servlet.http.HttpServlet;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.json.JSONArray;
import org.json.JSONObject;

import model.dao.BarraDiRicercaDao;
import model.dao.interfacce.BarraDiRicercaDaoInterfaccia;
import model.util.DriverManagerConnectionPool;

public class SuggerimentiControl extends HttpServlet {
	
	private static final long serialVersionUID = 1L;
	
	static BarraDiRicercaDaoInterfaccia BarraDiRicercaDao = new BarraDiRicercaDao();

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String searchTerm = request.getParameter("query");
        List<String> suggerimenti = new ArrayList<String>();
        JSONObject jsonResponse = new JSONObject();

        if (searchTerm != null && !searchTerm.trim().isEmpty()) {

            try {
                suggerimenti = BarraDiRicercaDao.getSuggerimenti(searchTerm);
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        jsonResponse.put("Suggerimenti", suggerimenti);
        
        //Rispondi con un JSON
    	response.setContentType("application/json");
    	response.setCharacterEncoding("UTF-8");
    	response.getWriter().write(jsonResponse.toString());
    }
	
}


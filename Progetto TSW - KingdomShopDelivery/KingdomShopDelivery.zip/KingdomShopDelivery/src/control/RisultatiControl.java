package control;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.json.JSONObject;

import model.beans.ProdottoBean;
import model.dao.BarraDiRicercaDao;
import model.dao.interfacce.BarraDiRicercaDaoInterfaccia;

public class RisultatiControl extends HttpServlet {
	
	private static final long serialVersionUID = 1L;
	
	static BarraDiRicercaDaoInterfaccia BarraDiRicercaDao = new BarraDiRicercaDao();
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        
		String searchTerm = request.getParameter("query");
		Collection<ProdottoBean> prodotti = new LinkedList<ProdottoBean>();
		
		HttpSession session = request.getSession(true);
		
		Boolean UtenteLoggato = session.getAttribute("idUtente") != null;
		request.setAttribute("UtenteLoggato", UtenteLoggato);
		
        if (searchTerm != null && !searchTerm.trim().isEmpty()) {

            try {
                prodotti = BarraDiRicercaDao.getProdottiSuggeriti(searchTerm);
            } catch (SQLException e) {
                e.printStackTrace();
            }
        } else {
        	response.sendRedirect("./home");
        }
        
        request.setAttribute("ProdottiSuggeritiCaricati", true);
        request.setAttribute("ProdottiSuggeriti", prodotti);
        RequestDispatcher dispatcher = request.getRequestDispatcher("risultati.jsp");
        dispatcher.forward(request, response);
    }
	
}

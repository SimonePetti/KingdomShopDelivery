package control;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import org.json.JSONObject;

import model.dao.RegistrazioneDao;
import model.dao.interfacce.RegistrazioneDaoInterfaccia;

public class RegistrazioneControl extends HttpServlet {
	
	private static final long serialVersionUID = 1L;
	
	static RegistrazioneDaoInterfaccia RegistrazioneDao = new RegistrazioneDao();
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.sendRedirect("registrazione.jsp");
		return;
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		HttpSession session = request.getSession(true);		
        //Estraggo i dati del form
        String nome = request.getParameter("nome");
    	String cognome = request.getParameter("cognome");
    	String email = request.getParameter("email");
    	String password = request.getParameter("password");
    	int prefissoTelefono = Integer.parseInt(request.getParameter("prefissoTelefono"));
    	long numeroTelefono = Long.parseLong(request.getParameter("numeroTelefono"));
    	String sendRedirect = request.getParameter("sendRedirect");
    		
    	if(sendRedirect != null & sendRedirect.equals("confermaAcquisto")) {
    		sendRedirect = "&sendRedirect=confermaAcquisto";
    	} else {
    		sendRedirect = "";
    	}
        	
    	nome = nome.trim().replaceAll("\\s+", " ");
    	cognome = cognome.trim().replaceAll("\\s+", " ").replaceAll("\\s'\\s", "'").replaceAll("\\s-\\s", "-");
    	email = email.trim();
    		
    	String prefissoTelefonoString = String.valueOf(prefissoTelefono);
    	prefissoTelefonoString = prefissoTelefonoString.replaceAll("\\s+", "");
    	prefissoTelefono = Integer.parseInt(prefissoTelefonoString);
    		
    	String numeroTelefonoString = String.valueOf(numeroTelefono);
    	numeroTelefonoString = numeroTelefonoString.replaceAll("\\s+", "");
    	numeroTelefono = Long.parseLong(numeroTelefonoString);
    		
    	password = toHash(password);
    			
    	try {
    		if(RegistrazioneDao.doSave(nome, cognome, email, password, prefissoTelefono, numeroTelefono)) {
    	   		response.sendRedirect("login.jsp?registrazione=successo" + sendRedirect);
    	   		return;
    		} else {
    	   		response.sendRedirect("registrazione.jsp?registrazione=fallita" + sendRedirect);
    	   		return;
    		}
    	} catch (SQLException e) {
    		System.out.println("Error:" + e.getMessage());
    	}
   		
    	response.sendRedirect("registrazione.jsp?registrazione=fallita" + sendRedirect);
    	return;   		
	}
	
	private String toHash(String password) {
		String hashString = null;
		try {
			java.security.MessageDigest digest = java.security.MessageDigest.getInstance("SHA-512");
			byte[] hash = digest.digest(password.getBytes(StandardCharsets.UTF_8));
			hashString = "";
			for(int i = 0; i < hash.length; i++) {
				hashString += Integer.toHexString((hash[i] & 0xFF) | 0x100).toLowerCase().substring(1,3);
			}
		} catch (java.security.NoSuchAlgorithmException e) {
			System.out.println(e);
		}
		return hashString;
	}

}
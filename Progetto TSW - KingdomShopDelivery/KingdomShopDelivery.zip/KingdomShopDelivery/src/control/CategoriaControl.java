package control;

import java.io.IOException;
import java.sql.SQLException;
import java.util.LinkedList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import model.beans.CartaBean;
import model.dao.ProdottoDao;
import model.dao.interfacce.ProdottoDaoInterfaccia;
import model.beans.ProdottoBean;

public class CategoriaControl extends HttpServlet {
	
	private static final long serialVersionUID = 1L;
	
	static ProdottoDaoInterfaccia ProdottoDao = new ProdottoDao();
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		HttpSession session = request.getSession(true);
		LinkedList<ProdottoBean> prodotti = new LinkedList<ProdottoBean>();
		
		Boolean UtenteLoggato = session.getAttribute("idUtente") != null;
		request.setAttribute("UtenteLoggato", UtenteLoggato);
		
		String Categoria = request.getParameter("nome");
		String SottoCategoria = request.getParameter("sottocategoria");
		
		if(Categoria != null) {Categoria = Categoria.toLowerCase();}
		
		if(Categoria.equals("armatura") || Categoria.equals("arma") || Categoria.equals("vestito") || Categoria.equals("accessorio") || Categoria.equals("scudo")) {

			Categoria = capitalizeFirstLetter(Categoria);
			request.removeAttribute("ProdottiCategoriaCaricati");
			
			try { 
				
				if(Categoria.equals("Armatura") && (SottoCategoria != null && !SottoCategoria.isEmpty())) {
					SottoCategoria.toLowerCase();
					
					if(SottoCategoria.equals("braccia") || SottoCategoria.equals("gambe") || SottoCategoria.equals("corazza") || SottoCategoria.equals("elmo")) {
						SottoCategoria = capitalizeFirstLetter(SottoCategoria);
						prodotti = ProdottoDao.getProdottiCategoria(Categoria,SottoCategoria);
						request.setAttribute("NomeSottoCategoria", SottoCategoria);
					} else {
						prodotti = ProdottoDao.getProdottiCategoria(Categoria,"");
					}
				} else {
					prodotti = ProdottoDao.getProdottiCategoria(Categoria,"");
				}
				
			} catch (SQLException e) {
				System.out.println("Error:" + e.getMessage());
			}
			
			request.setAttribute("ProdottiCategoriaCaricati", true);
			request.setAttribute("ProdottiCategoria", prodotti);
			request.setAttribute("NomeCategoria", Categoria);
			
			RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/categoria.jsp");
			dispatcher.forward(request, response);
			return;
		}
		
		response.sendRedirect("home");
		return;
	}
	
	// Metodo per rendere maiuscola solo la prima lettera
	private String capitalizeFirstLetter(String input) {
	    if (input == null || input.isEmpty()) {
	        return input;
	    }
	    return input.substring(0, 1).toUpperCase() + input.substring(1).toLowerCase();
	}

}

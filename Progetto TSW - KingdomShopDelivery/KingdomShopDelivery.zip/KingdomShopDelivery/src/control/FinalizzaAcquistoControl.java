package control;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import model.beans.ConfermaOrdineBean;
import model.dao.OrdiniDao;
import model.dao.interfacce.OrdiniDaoInterfaccia;

public class FinalizzaAcquistoControl extends HttpServlet {
	
	private static final long serialVersionUID = 1L;
	
	static OrdiniDaoInterfaccia OrdiniDao = new OrdiniDao();
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		ConfermaOrdineBean ordine = new ConfermaOrdineBean();
		HttpSession session = request.getSession(true);
		int id_utente = (int) session.getAttribute("idUtente");
		ordine = (ConfermaOrdineBean) session.getAttribute("AcquistoDaConfermare");
		
		String metodo = request.getParameter("metodo-pagamento");
		int id_carta_pagamento = -1;
		if(metodo.equals("carta")) {
			id_carta_pagamento = Integer.parseInt(request.getParameter("seleziona-carta"));
		}
		
		if(ordine.getNoteSpedizione().isEmpty()) {
			ordine.setNoteSpedizione(null);
		}
		
		ordine.setTipoPagamento(metodo);
		ordine.setIdCartaPagamento(id_carta_pagamento);
		
		try {	
			OrdiniDao.finalizzaAcquisto(id_utente, ordine);
		} catch (SQLException e) {
			System.out.println("Error:" + e.getMessage());
		}
		
		session.setAttribute("stato_acquisto", "successo");
		ConfermaOrdineBean nuovo = new ConfermaOrdineBean();
		session.setAttribute("AcquistoDaConfermare", nuovo);
		
		RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/confermaAcquisto/finalizzato.jsp");
		dispatcher.forward(request, response);
		return;
	}

}

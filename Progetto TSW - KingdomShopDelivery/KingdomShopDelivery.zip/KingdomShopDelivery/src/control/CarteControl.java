package control;

import java.io.IOException;
import java.sql.SQLException;
import java.util.LinkedList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import model.beans.CartaBean;

import model.beans.DatiPersonaliBean;
import model.dao.CartaDao;
import model.dao.interfacce.CartaDaoInterfaccia;

public class CarteControl extends HttpServlet {

	private static final long serialVersionUID = 1L;
	
	static CartaDaoInterfaccia CartaDao = new CartaDao();
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		HttpSession session = request.getSession(true);
		int idUtente = (Integer) session.getAttribute("idUtente");
		LinkedList<CartaBean> carte = new LinkedList<CartaBean>();
		
		String ruoloUtente = (String) session.getAttribute("ruoloUtente");
		if (ruoloUtente == null) {
			ruoloUtente = "utente";
		}
		request.setAttribute("ruoloUtente", ruoloUtente);
		
		try { 
			carte = CartaDao.getCarte(idUtente);
		} catch (SQLException e) {
			System.out.println("Error:" + e.getMessage());
		}
		
		request.setAttribute("CarteCaricate", true);
		request.setAttribute("Carte", carte);	
		
		RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/mioAccount/carte.jsp");
		dispatcher.forward(request, response);
	}
}

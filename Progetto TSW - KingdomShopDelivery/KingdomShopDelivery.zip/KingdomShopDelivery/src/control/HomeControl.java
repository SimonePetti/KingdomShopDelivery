package control;

import model.beans.ProdottoBean;
import model.beans.ProdottoInOffertaBean;
import model.dao.ProdottoDao;
import model.dao.ProdottoInOffertaDao;

import model.dao.interfacce.ProdottoInOffertaDaoInterfaccia;
import model.dao.interfacce.ProdottoDaoInterfaccia;

import java.io.IOException; 
import java.sql.SQLException;
import java.util.List;
import java.util.Collection;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class HomeControl extends HttpServlet {
	
	private static final long serialVersionUID = 1L;
	
	static ProdottoDaoInterfaccia ProdottoDao = new ProdottoDao();
	static ProdottoInOffertaDaoInterfaccia ProdottoInOffertaDao = new ProdottoInOffertaDao();
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		HttpSession session = request.getSession(true);
		
		Boolean UtenteLoggato = session.getAttribute("idUtente") != null;
		request.setAttribute("UtenteLoggato", UtenteLoggato);
		
		List<ProdottoInOffertaBean> prodottiInOfferta = null;
		Collection<ProdottoBean> ultimiArriviProdotti = null;
		Collection<ProdottoBean> prodottiPiuVenduti = null;
		Collection<ProdottoBean> prodottiDiRiserva = null;
		
		request.removeAttribute("ProdottiHomeCaricati");
		request.removeAttribute("ProdottiInOfferta");
		
		try {
			prodottiInOfferta = ProdottoInOffertaDao.getProdottiInOfferta(10);
		} catch (SQLException e) {
			System.out.println("Error:" + e.getMessage());
		}
		request.setAttribute("ProdottiInOfferta", prodottiInOfferta);
		
		request.removeAttribute("UltimiArriviProdotti");
		try {
			ultimiArriviProdotti = ProdottoDao.getUltimiArrivi(10);
		} catch (SQLException e) {
			System.out.println("Error:" + e.getMessage());
		}
		request.setAttribute("UltimiArriviProdotti", ultimiArriviProdotti);
		
		request.removeAttribute("ProdottiPiuVenduti");
		try {
			prodottiPiuVenduti = ProdottoDao.getProdottiPiuVenduti(10);
		} catch (SQLException e) {
			System.out.println("Error:" + e.getMessage());
		}
		request.setAttribute("ProdottiPiuVenduti", prodottiPiuVenduti);
		
		int nullcount = 0;
		
		if(prodottiInOfferta == null || prodottiInOfferta.isEmpty()) {nullcount++;}
		if(ultimiArriviProdotti == null || ultimiArriviProdotti.isEmpty()) {nullcount++;}
		if(prodottiPiuVenduti == null || prodottiPiuVenduti.isEmpty()) {nullcount++;}
		
		request.removeAttribute("ProdottiDiRiserva");
		try {
			
			if(nullcount > 0) {
				prodottiDiRiserva = ProdottoDao.doRetrieveAll(20, "RAND()");
			}
		} catch (SQLException e) {
			System.out.println("Error:" + e.getMessage());
		}
		request.setAttribute("ProdottiDiRiserva", prodottiDiRiserva);
		
		request.setAttribute("ProdottiHomeCaricati", true);
		RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/home.jsp");
		dispatcher.forward(request, response);
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}
}


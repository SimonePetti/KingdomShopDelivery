package control;

import java.io.IOException;
import java.sql.SQLException;
import java.util.LinkedList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import model.beans.CartaBean;
import model.beans.ConfermaOrdineBean;
import model.beans.IndirizzoBean;
import model.dao.CartaDao;
import model.dao.interfacce.CartaDaoInterfaccia;

public class ScegliPagamentoControl extends HttpServlet {
	
	private static final long serialVersionUID = 1L;
	
	static CartaDaoInterfaccia CartaDao = new CartaDao();
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		HttpSession session = request.getSession(true);
		int idUtente = (Integer) session.getAttribute("idUtente");
		LinkedList<CartaBean> carte = new LinkedList<CartaBean>();
		
		try { 
			carte = CartaDao.getCarte(idUtente);
		} catch (SQLException e) {
			System.out.println("Error:" + e.getMessage());
		}
		
		request.setAttribute("CarteCaricate", true);
		request.setAttribute("Carte", carte);
		
		RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/confermaAcquisto/pagamento.jsp");
		dispatcher.forward(request, response);
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		HttpSession session = request.getSession(true);
		int idUtente = (Integer) session.getAttribute("idUtente");
		ConfermaOrdineBean ordine = (ConfermaOrdineBean) session.getAttribute("AcquistoDaConfermare");
		
        // Ottenere i parametri inviati dal form
		int indirizzo_spedizione = Integer.parseInt(request.getParameter("indirizzo_spedizione"));
		int indirizzo_fatturazione = Integer.parseInt(request.getParameter("indirizzo_fatturazione"));
		String note_spedizione = request.getParameter("spedizione-note");
		if(!note_spedizione.equals("")) {note_spedizione = note_spedizione.trim();}
		
		ordine.setIdIndirizzoSpedizione(indirizzo_spedizione);
		ordine.setIdIndirizzoFatturazione(indirizzo_fatturazione);
		ordine.setNoteSpedizione(note_spedizione);

		doGet(request,response);
    }

}

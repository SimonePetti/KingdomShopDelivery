package control;

import model.beans.WishListBean;
import model.dao.WishListDao;
import model.dao.interfacce.WishListDaoInterfaccia;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import java.util.LinkedList;

public class WishListControl extends HttpServlet {
	
	private static final long serialVersionUID = 1L;
	
	static WishListDaoInterfaccia WishListDao = new WishListDao();
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession(true);
		Integer id_utente = (Integer) session.getAttribute("idUtente");
		
		Boolean UtenteLoggato = session.getAttribute("idUtente") != null;
		request.setAttribute("UtenteLoggato", UtenteLoggato);
		
		String action = (String) request.getParameter("action");
		int prodottoId = -1;
		
		if(id_utente != null) {
			
		try {
			if(action != null) {
				try {
					prodottoId = Integer.parseInt(request.getParameter("id"));
				} catch (NumberFormatException e) {
					response.sendRedirect("./home");
					return;
				}

				if(WishListDao.isIn(prodottoId)) {
					
					if(action.equalsIgnoreCase("add") && !WishListDao.isIn(prodottoId,id_utente)) {
						WishListDao.doSave(prodottoId, id_utente);
						
						RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/home.jsp");
						dispatcher.forward(request, response);
						return;
					}
					
					if(action.equalsIgnoreCase("delete")) {
						WishListDao.doDelete(prodottoId,id_utente);
						RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/wishlist.jsp");
						dispatcher.forward(request, response);
						return;
					}
					
					RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/home.jsp");
					dispatcher.forward(request, response);
					return;
				}
			}
			//Else: action � null
			//Carico i prodotti della wishlist
			WishListBean prodottiWishlist = new WishListBean();
			
			request.removeAttribute("ProdottiWishListCaricati");
			request.removeAttribute("ProdottiWishList");
			
			try {
				prodottiWishlist = WishListDao.getProdotti(id_utente);
			} catch (SQLException e) {
				System.out.println("Error:" + e.getMessage());
			}
			
			request.setAttribute("ProdottiWishList", prodottiWishlist);
			request.setAttribute("ProdottiWishListCaricati", true);
			
			RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/wishlist.jsp");
			dispatcher.forward(request, response);
			return;
			
		} catch (SQLException e) {
			System.out.println("Error:" + e.getMessage());
		}
		
		} else {
			//L'utente � un guest
			try {
				LinkedList<Integer> wishList = (LinkedList<Integer>) session.getAttribute("WishListGuest");
				
				if(wishList == null) {
					wishList = new LinkedList<Integer>();
				}
				
				if(action != null) {
					
					try {
						prodottoId = Integer.parseInt(request.getParameter("id"));
					} catch (NumberFormatException e) {
						response.sendRedirect("./home");
						return;
					}
					
					if(WishListDao.isIn(prodottoId)) {

						if(action.equalsIgnoreCase("add") && !wishList.contains(prodottoId)) {
							wishList.addFirst(prodottoId);
							
							session.removeAttribute("WishListGuest");
							session.setAttribute("WishListGuest", wishList);
							
							RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/home.jsp");
							dispatcher.forward(request, response);
							return;
						}
						
						if(action.equalsIgnoreCase("delete")) {
							wishList.remove(Integer.valueOf(prodottoId));
							
							session.removeAttribute("WishListGuest");
							session.setAttribute("WishListGuest", wishList);
							
							RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/wishlist.jsp");
							dispatcher.forward(request, response);
							return;
						}
						RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/home.jsp");
						dispatcher.forward(request, response);
						return;
					}
					
				}
				//Else: action � null
				//Carico i prodotti della wishlist
				WishListBean prodottiWishlist;
				try {
					request.removeAttribute("ProdottiWishListCaricati");

					LinkedList<Integer> prodottiGuest = (LinkedList<Integer>) session.getAttribute("WishListGuest");
					
					if(prodottiGuest == null || prodottiGuest.isEmpty()) {
						prodottiWishlist = new WishListBean();
						request.setAttribute("ProdottiWishList", prodottiWishlist);
						request.setAttribute("ProdottiWishListCaricati", true);
						
						RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/wishlist.jsp");
						dispatcher.forward(request, response);
						return;
					}
					prodottiWishlist = WishListDao.getProdottiGuest(prodottiGuest);
					prodottiWishlist = prodottiWishlist.orderBy(prodottiGuest);
					request.setAttribute("ProdottiWishList", prodottiWishlist);
					request.setAttribute("ProdottiWishListCaricati", true);
				} catch (SQLException e) {
					System.out.println("Error:" + e.getMessage());
				}
				
				RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/wishlist.jsp");
				dispatcher.forward(request, response);
				return;
				
			} catch (SQLException e) {
				System.out.println("Error:" + e.getMessage());
			}
		}

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}

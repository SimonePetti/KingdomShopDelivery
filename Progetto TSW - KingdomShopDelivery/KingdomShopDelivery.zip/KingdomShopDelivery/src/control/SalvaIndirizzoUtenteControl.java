package control;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import model.dao.IndirizzoDao;
import model.dao.interfacce.IndirizzoDaoInterfaccia;
import model.beans.IndirizzoBean;

public class SalvaIndirizzoUtenteControl extends HttpServlet {

	private static final long serialVersionUID = 1L;
	
	static IndirizzoDaoInterfaccia IndirizzoDao = new IndirizzoDao();
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        
		HttpSession session = request.getSession(true);
		int idUtente = (Integer) session.getAttribute("idUtente");
		String messaggioRedirect = "";
		
		String action = request.getParameter("action");
		String[] azione_indirizzo = action.split("_");
		if(azione_indirizzo[0].equals("inserimento") || azione_indirizzo[0].equals("modifica")) {	
		
		// Recupera i valori dal form
        String nome = request.getParameter("nome");
        String cognome = request.getParameter("cognome");
        String via = request.getParameter("via");
        String civico = request.getParameter("civico");
        String cap = request.getParameter("cap");
        String citta = request.getParameter("citta");
        String provincia = request.getParameter("provincia");
        String paese = request.getParameter("paese");
        String[] tipoIndirizzo = request.getParameterValues("tipo-indirizzo");
        
        nome = nome.trim().replaceAll("\\s+", " ");
		cognome = cognome.trim().replaceAll("\\s+", " ").replaceAll("\\s'\\s", "'").replaceAll("\\s-\\s", "-");
		via = via.trim().replaceAll("\\s+", " ").replaceAll("\\s'\\s", "'").replaceAll("\\s-\\s", "-");
		civico = civico.trim().replaceAll("\\s+", " ").replaceAll("\\s'\\s", "'").replaceAll("\\s-\\s", "-");
		citta = citta.trim().replaceAll("\\s+", " ").replaceAll("\\s'\\s", "'").replaceAll("\\s-\\s", "-");
		provincia = provincia.trim().replaceAll("\\s+", " ").replaceAll("\\s'\\s", "'").replaceAll("\\s-\\s", "-");
		paese = paese.trim().replaceAll("\\s+", " ").replaceAll("\\s'\\s", "'").replaceAll("\\s-\\s", "-");
		civico = civico.replaceAll("\\s+", "");
		cap = cap.replaceAll("\\s+", "");

        boolean indirizzoSpedizione = false;
        boolean indirizzoFatturazione = false;

        if (tipoIndirizzo != null) {
            for (String tipo : tipoIndirizzo) {
                if (tipo.equals("spedizione")) {
                    indirizzoSpedizione = true;
                } else if (tipo.equals("fatturazione")) {
                    indirizzoFatturazione = true;
                }
            }
        }
        
        String tipo_indirizzo = "";
        
        if(indirizzoSpedizione && indirizzoFatturazione) {
        	tipo_indirizzo = "Spedizione-Fatturazione";
        } else {
        	if(indirizzoSpedizione) {tipo_indirizzo = "Spedizione";}
        	if(indirizzoFatturazione) {tipo_indirizzo = "Fatturazione";}
        }

        IndirizzoBean indirizzo = new IndirizzoBean();
        indirizzo.setNome(nome);
        indirizzo.setCognome(cognome);
        indirizzo.setVia(via);
        indirizzo.setCivico(civico);
        indirizzo.setCap(cap);
        indirizzo.setCitta(citta);
        indirizzo.setProvincia(provincia);
        indirizzo.setPaese(paese);
        indirizzo.setTipo(tipo_indirizzo);
        
        try {
        	if(azione_indirizzo[0].equals("inserimento")) {messaggioRedirect = IndirizzoDao.aggiungiIndirizzo(idUtente, indirizzo);}
        	if(azione_indirizzo[0].equals("modifica")) {int id_indirizzo = Integer.parseInt(azione_indirizzo[1]); messaggioRedirect = IndirizzoDao.modificaIndirizzo(idUtente, indirizzo, id_indirizzo);}
        } catch (SQLException e) {
			System.out.println("Error:" + e.getMessage());
        }
        
	} else {
		
		try {
			if(azione_indirizzo[0].equals("elimina")) {
				messaggioRedirect = IndirizzoDao.eliminaIndirizzo(idUtente,Integer.parseInt(azione_indirizzo[1]));
			}
		} catch (SQLException e) {
			System.out.println("Error:" + e.getMessage());
        }
	}

        response.sendRedirect("indirizzi"+ messaggioRedirect);
    }

}

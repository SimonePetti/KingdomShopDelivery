package control;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.sql.SQLException;
import java.util.LinkedList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import model.dao.DatiUtenteDao;
import model.dao.interfacce.DatiUtenteDaoInterfaccia;
import model.beans.DatiPersonaliBean;
import model.beans.IndirizzoBean;

public class DatiPersonaliControl extends HttpServlet {
	
	private static final long serialVersionUID = 1L;
	
	static DatiUtenteDaoInterfaccia DatiUtenteDao = new DatiUtenteDao();
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		HttpSession session = request.getSession(true);
		int idUtente = (Integer) session.getAttribute("idUtente");
		DatiPersonaliBean utente = new DatiPersonaliBean();
		
		Boolean UtenteLoggato = session.getAttribute("idUtente") != null;
		request.setAttribute("UtenteLoggato", UtenteLoggato);
		
		
		String ruoloUtente = (String) session.getAttribute("ruoloUtente");
		if (ruoloUtente == null) {
			ruoloUtente = "utente";
		}
		request.setAttribute("ruoloUtente", ruoloUtente);
		
		try { 
			utente = DatiUtenteDao.getDatiPersonali(idUtente);
		} catch (SQLException e) {
			System.out.println("Error:" + e.getMessage());
		}
		
		request.setAttribute("DatiPersonaliCaricati", true);
		request.setAttribute("DatiPersonali", utente);	
		
		RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/mioAccount/dati-personali.jsp");
		dispatcher.forward(request, response);
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		HttpSession session = request.getSession(true);
		int idUtente = (Integer) session.getAttribute("idUtente");
		
		String action = request.getParameter("action");
		
		if(action.equals("modificaDati")) {
			String nome = request.getParameter("nome");
			String cognome = request.getParameter("cognome");
			int prefisso_telefonico = Integer.parseInt(request.getParameter("prefissoTelefono"));
			long numero_telefono = Long.parseLong(request.getParameter("numeroTelefono"));
			String stato_operazione = "";
			
			try {
				stato_operazione = DatiUtenteDao.modificaDati(idUtente,nome,cognome,prefisso_telefonico,numero_telefono);
			} catch (SQLException e) {
				System.out.println("Error:" + e.getMessage());
			}
			response.sendRedirect("./dati-personali.jsp?modificaDati=" + stato_operazione);
		}
		
		if(action.equals("modificaEmail")) {
			String emailAttuale = request.getParameter("emailAttuale");
			String emailNuova = request.getParameter("emailNuova");
			String password = request.getParameter("password");
			String stato_operazione = "";
			
			password = toHash(password);
			
			try {
				stato_operazione = DatiUtenteDao.modificaEmail(idUtente,emailAttuale,emailNuova,password);
			} catch (SQLException e) {
				System.out.println("Error:" + e.getMessage());
			}
			response.sendRedirect("./dati-personali.jsp?modificaEmail=" + stato_operazione);
		}
		
		if(action.equals("modificaPassword")) {
			String email = request.getParameter("email");
			String passwordAttuale = request.getParameter("passwordAttuale");
			String passwordNuova = request.getParameter("passwordNuova");
			String stato_operazione = "";
			
			passwordAttuale = toHash(passwordAttuale);
			passwordNuova = toHash(passwordNuova);
			
			try {
				stato_operazione = DatiUtenteDao.modificaPassword(idUtente,email,passwordAttuale,passwordNuova);
			} catch (SQLException e) {
				System.out.println("Error:" + e.getMessage());
			}
			response.sendRedirect("./dati-personali.jsp?modificaPassword=" + stato_operazione);
		}
	}
	
	private String toHash(String password) {
		String hashString = null;
		try {
			java.security.MessageDigest digest = java.security.MessageDigest.getInstance("SHA-512");
			byte[] hash = digest.digest(password.getBytes(StandardCharsets.UTF_8));
			hashString = "";
			for(int i = 0; i < hash.length; i++) {
				hashString += Integer.toHexString((hash[i] & 0xFF) | 0x100).toLowerCase().substring(1,3);
			}
		} catch (java.security.NoSuchAlgorithmException e) {
			System.out.println(e);
		}
		return hashString;
	}

}

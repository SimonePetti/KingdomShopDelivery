package control;

import model.beans.ProdottoDettaglioBean;
import model.dao.ProdottoDettaglioDao;
import model.dao.interfacce.ProdottoDettaglioDaoInterfaccia;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ProdottoDettagliControl extends HttpServlet {
	
	private static final long serialVersionUID = 1L;
	
	static ProdottoDettaglioDaoInterfaccia ProdottoDettaglioDao = new ProdottoDettaglioDao();
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		int prodottoId = -1;
		
		try {
	        prodottoId = Integer.parseInt(request.getParameter("id"));
	    } catch (NumberFormatException e) {
	        response.sendRedirect("./home");
	        return;
	    }
		
		try {
			request.removeAttribute("ProdottoDettagliCaricato");
			
			ProdottoDettaglioBean pd = ProdottoDettaglioDao.doRetrieveByKey(prodottoId);
			request.setAttribute("ProdottoDettagli", pd);
			request.setAttribute("ProdottoDettagliCaricato", true);
			
			RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/prodotto.jsp");
			dispatcher.forward(request, response);
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}

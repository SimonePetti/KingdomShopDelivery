package control;

import java.io.IOException;
import java.sql.SQLException;
import java.util.LinkedList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import model.beans.CartaBean;
import model.beans.ConfermaOrdineBean;
import model.beans.IndirizzoBean;
import model.dao.IndirizzoDao;
import model.dao.interfacce.IndirizzoDaoInterfaccia;

public class ScegliIndirizzoControl extends HttpServlet {
	
	private static final long serialVersionUID = 1L;
	
	static IndirizzoDaoInterfaccia IndirizzoDao = new IndirizzoDao();
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		HttpSession session = request.getSession(true);
		LinkedList<IndirizzoBean> indirizziSpedizione = new LinkedList<IndirizzoBean>();
		LinkedList<IndirizzoBean> indirizziFatturazione = new LinkedList<IndirizzoBean>();
		int idUtente = (Integer) session.getAttribute("idUtente");
		ConfermaOrdineBean ordine = (ConfermaOrdineBean) session.getAttribute("AcquistoDaConfermare");
		
		try { 
			IndirizzoDao.getIndirizzi(idUtente, indirizziSpedizione, indirizziFatturazione);
		} catch (SQLException e) {
			System.out.println("Error:" + e.getMessage());
		}
		
		request.setAttribute("IndirizziCaricati", true);
		request.setAttribute("IndirizziSpedizione", indirizziSpedizione);
		request.setAttribute("IndirizziFatturazione", indirizziFatturazione);
		
		RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/confermaAcquisto/indirizzo.jsp");
		dispatcher.forward(request, response);
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		HttpSession session = request.getSession(true);
		int idUtente = (Integer) session.getAttribute("idUtente");
		ConfermaOrdineBean ordine = (ConfermaOrdineBean) session.getAttribute("AcquistoDaConfermare");
		
        // Ottenere i parametri inviati dal form
		int indirizzo_spedizione = Integer.parseInt(request.getParameter("indirizzo_spedizione"));
		int indirizzo_fatturazione = Integer.parseInt(request.getParameter("indirizzo_fatturazione"));
		String note_spedizione = request.getParameter("spedizione-note").trim();
		
		ordine.setIdIndirizzoSpedizione(indirizzo_spedizione);
		ordine.setIdIndirizzoFatturazione(indirizzo_fatturazione);
		ordine.setNoteSpedizione(note_spedizione);
		
		session.setAttribute("AcquistoDaConfermare", ordine);

        response.sendRedirect("./pagamento");
    }

}

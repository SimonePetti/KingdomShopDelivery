package control;

import model.beans.OrdineDettagliBean;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import model.dao.OrdiniDao;
import model.dao.interfacce.OrdiniDaoInterfaccia;

public class OrdineDettagliControl extends HttpServlet {
	
	private static final long serialVersionUID = 1L;
	
	static OrdiniDaoInterfaccia OrdiniDao = new OrdiniDao();
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		HttpSession session = request.getSession(true);
		int idUtente = (Integer) session.getAttribute("idUtente");
		
		String ruoloUtente = (String) session.getAttribute("ruoloUtente");
		if (ruoloUtente == null) {
			ruoloUtente = "utente";
		}
		request.setAttribute("ruoloUtente", ruoloUtente);
		
		int numero_ordine = -1;
		OrdineDettagliBean ordine_dettagli = new OrdineDettagliBean();
		
		try {
	        numero_ordine = Integer.parseInt(request.getParameter("ordine"));
	    } catch (NumberFormatException e) {
	        response.sendRedirect("./ordini");
	        return;
	    }
		
		try {
			
			if(!OrdiniDao.isIn(idUtente, numero_ordine)) {
				response.sendRedirect("ordini");
				return;
			}	
			ordine_dettagli = (OrdineDettagliBean) OrdiniDao.getDettagliOrdine(numero_ordine);
		} catch (SQLException e) {
			System.out.println("Error:" + e.getMessage());
		}
		request.removeAttribute("OrdineDettagliCaricati");
		request.setAttribute("OrdineDettagliCaricati", true);
		request.removeAttribute("OrdineDettagli");
		request.setAttribute("OrdineDettagli", ordine_dettagli);
		
		RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/mioAccount/dettagli-ordine.jsp");
		dispatcher.forward(request, response);
		return;
	}

}

package control;

import java.io.IOException;
import java.sql.SQLException;
import java.util.LinkedList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import model.beans.CartaBean;
import model.beans.FatturaBean;
import model.dao.FatturaDao;
import model.dao.interfacce.FatturaDaoInterfaccia;

public class FatturaControl extends HttpServlet {
	
	private static final long serialVersionUID = 1L;
	
	static FatturaDaoInterfaccia FatturaDao = new FatturaDao();
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		HttpSession session = request.getSession(true);
		int idUtente = (Integer) session.getAttribute("idUtente");
		FatturaBean fattura = new FatturaBean();
		int ordineId = -1;
		
		Boolean UtenteLoggato = session.getAttribute("idUtente") != null;
		request.setAttribute("UtenteLoggato", UtenteLoggato);
		
		
		String ordine = request.getParameter("id");
		
		try {
	        ordineId = Integer.parseInt(ordine);
	    } catch (NumberFormatException e) {
	        response.sendRedirect("./home");
	        return;
	    }
		
		try { 
			fattura = FatturaDao.getFatturaOrdine(idUtente, ordineId);
		} catch (SQLException e) {
			System.out.println("Error:" + e.getMessage());
		}
		
		request.setAttribute("FatturaCaricata", true);
		request.setAttribute("Fattura", fattura);	
		
		RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/mioAccount/fattura.jsp");
		dispatcher.forward(request, response);
		return;
	}
}

package control;

import java.io.IOException;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.YearMonth;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import model.beans.CartaBean;
import model.dao.CartaDao;
import model.dao.interfacce.CartaDaoInterfaccia;

public class SalvaCartaUtenteControl extends HttpServlet {
	
	private static final long serialVersionUID = 1L;
		
	static CartaDaoInterfaccia CartaDao = new CartaDao();
		
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	        
		HttpSession session = request.getSession(true);
		int idUtente = (Integer) session.getAttribute("idUtente");
		String messaggioRedirect = "";
			
		String action = request.getParameter("action");
		String[] azione_carta = action.split("_");
		
		if(azione_carta[0].equals("inserimento")) {	
			
		// Recupera i valori dal form
		long numero_carta = Long.parseLong(request.getParameter("numero"));
		String nome_completo = request.getParameter("nome-completo");
		int scadenza_mese = Integer.parseInt(request.getParameter("scadenza-mese"));
		int scadenza_anno = Integer.parseInt(request.getParameter("scadenza-anno"));
		YearMonth scadenza = YearMonth.of(scadenza_anno, scadenza_mese);
		int cvv = Integer.parseInt(request.getParameter("cvv"));
	        
	    nome_completo = nome_completo.trim().replaceAll("\\s+", " ");
	    
	    CartaBean carta = new CartaBean();
	    carta.setNomeCompleto(nome_completo);
	    carta.setNumeroCarta(numero_carta);
	    carta.setScadenza(scadenza);
	    
	    try {
	    	messaggioRedirect = CartaDao.aggiungiCarta(idUtente, carta, cvv);
	    } catch (SQLException e) {
			System.out.println("Error:" + e.getMessage());
	    }
	        
		} else {
			
			try {
				if(azione_carta[0].equals("modifica")) {
					
					int id_carta = Integer.parseInt(azione_carta[1]);
					String nome_completo = request.getParameter("nome-completo-modifica");
					int scadenza_mese = Integer.parseInt(request.getParameter("scadenza-mese-modifica"));
					int scadenza_anno = Integer.parseInt(request.getParameter("scadenza-anno-modifica"));
					YearMonth scadenza = YearMonth.of(scadenza_anno, scadenza_mese);
					
					messaggioRedirect = CartaDao.modificaCarta(idUtente, id_carta, nome_completo, scadenza);
				}
			} catch (SQLException e) {
				System.out.println("Error:" + e.getMessage());
			}
			
			try {
				if(azione_carta[0].equals("elimina")) {
					messaggioRedirect = CartaDao.eliminaCarta(idUtente,Integer.parseInt(azione_carta[1]));
				}
			} catch (SQLException e) {
				System.out.println("Error:" + e.getMessage());
			}
		}
		response.sendRedirect("carte"+ messaggioRedirect);
	}

	
}

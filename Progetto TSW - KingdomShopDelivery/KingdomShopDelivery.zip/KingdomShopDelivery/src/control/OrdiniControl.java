package control;

import model.beans.OrdineBean;
import model.beans.OrdineProdottoBean;
import model.dao.OrdiniDao;
import model.dao.interfacce.OrdiniDaoInterfaccia;

import java.util.LinkedList;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class OrdiniControl extends HttpServlet {
	
	private static final long serialVersionUID = 1L;
	
	static OrdiniDaoInterfaccia OrdiniDao = new OrdiniDao();
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		HttpSession session = request.getSession(true);
		int idUtente = (Integer) session.getAttribute("idUtente");
		
		String ruoloUtente = (String) session.getAttribute("ruoloUtente");
		if (ruoloUtente == null) {
			ruoloUtente = "utente";
		}
		request.setAttribute("ruoloUtente", ruoloUtente);
		
		LinkedList<OrdineBean> ordini = new LinkedList<OrdineBean>();
		
		try {
			ordini = OrdiniDao.getOrdini(idUtente);
		} catch (SQLException e) {
			System.out.println("Error:" + e.getMessage());
		}
		
		request.removeAttribute("OrdiniCaricati");
		request.setAttribute("OrdiniCaricati", true);
		request.setAttribute("Ordini", ordini);
		
		RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/mioAccount/ordini.jsp");
		dispatcher.forward(request, response);
	}

}

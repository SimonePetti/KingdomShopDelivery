package control;

import model.beans.ProdottoBean;
import model.beans.ProdottoInOffertaBean;
import model.dao.ProdottoDao;
import model.dao.ProdottoInOffertaDao;

import model.dao.interfacce.SezioneProdottiInOffertaDaoInterfaccia;
import model.dao.SezioneProdottiInOffertaDao;

import java.io.IOException; 
import java.sql.SQLException;
import java.util.List;
import java.util.Collection;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class SezioneProdottiInOffertaControl extends HttpServlet {
	
	private static final long serialVersionUID = 1L;
	
	static SezioneProdottiInOffertaDaoInterfaccia SezioneProdottiInOffertaDao = new SezioneProdottiInOffertaDao();
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		List<ProdottoInOffertaBean> prodottiInOfferta = null;
		
		HttpSession session = request.getSession(true);
		
		Boolean UtenteLoggato = session.getAttribute("idUtente") != null;
		request.setAttribute("UtenteLoggato", UtenteLoggato);
		
		request.removeAttribute("ProdottiSezioneProdottiInOffertaCaricati");
		request.removeAttribute("ProdottiInOfferta");
		
		try {
			prodottiInOfferta = SezioneProdottiInOffertaDao.getProdottiInOfferta(50);
		} catch (SQLException e) {
			System.out.println("Error:" + e.getMessage());
		}
		
		request.setAttribute("ProdottiInOfferta", prodottiInOfferta);
		
		request.setAttribute("ProdottiSezioneProdottiInOffertaCaricati", true);
		RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/prodottiInOfferta.jsp");
		dispatcher.forward(request, response);
		
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}
}

package control;

import java.io.BufferedReader;
import java.io.IOException;
import java.math.BigDecimal;
import java.sql.SQLException;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.json.JSONObject;
import org.json.JSONArray;

import model.beans.CarrelloProdottoInOffertaBean;
import model.beans.CarrelloBean;
import model.beans.CarrelloProdottoBean;
import model.dao.CarrelloDao;
import model.dao.interfacce.CarrelloDaoInterfaccia;

public class ProcediAllAcquistoControl extends HttpServlet {
	
	private static final long serialVersionUID = 1L;
	
	static CarrelloDaoInterfaccia CarrelloDao = new CarrelloDao();
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		HttpSession session = request.getSession(true);
		
        StringBuilder sb = new StringBuilder();
        try (BufferedReader reader = request.getReader()) {
            String line;
            while ((line = reader.readLine()) != null) {
                sb.append(line);
            }
        }
		
        String jsonString = sb.toString();
        JSONObject jsonObject = new JSONObject(jsonString);
        JSONObject jsonResponse = new JSONObject();
        
        String azione = jsonObject.getString("Azione");
        JSONArray carrello_da_verificare = jsonObject.getJSONArray("CarrelloDaVerificare");
        
        if(azione.equals("verificaCarrello")) {
        	
        int contatore_modifiche = 0;
        
        if(session.getAttribute("idUtente") != null) {
        
        int id_utente = (int) session.getAttribute("idUtente");
        
        LinkedHashMap<List<Integer>,BigDecimal> carrello_visualizzato = new LinkedHashMap<List<Integer>,BigDecimal>();
        for(int i = 0; i < carrello_da_verificare.length(); i++) {
        	JSONObject elemento = carrello_da_verificare.getJSONObject(i);
        	
        	int id = elemento.getInt("id");
            int idTaglia = elemento.getInt("idTaglia");
            BigDecimal prezzoProdotto = elemento.getBigDecimal("prezzoProdotto");

            List<Integer> chiave = Arrays.asList(id, idTaglia);
            carrello_visualizzato.put(chiave, prezzoProdotto);
        }
        try {
        	CarrelloBean carrello = CarrelloDao.getProdotti(id_utente);
        	for(Map.Entry<CarrelloProdottoBean, Integer> entry : carrello.getProdotti().entrySet()) {
        		CarrelloProdottoBean prodotto = entry.getKey();
                Integer quantita = entry.getValue();
                Boolean prodotto_in_offerta = (prodotto instanceof CarrelloProdottoInOffertaBean) ? true : false;
                
                List<Integer> chiaveDaCercare = new ArrayList<>();
                chiaveDaCercare.add(prodotto.getIdProdotto());
                chiaveDaCercare.add(prodotto.getIdTaglia());
                
                BigDecimal prezzo = BigDecimal.ZERO.setScale(2);
                
                if (carrello_visualizzato.containsKey(chiaveDaCercare)) {
                	prezzo = carrello_visualizzato.get(chiaveDaCercare);
                } else {
                	prezzo = (prodotto_in_offerta) ? ((CarrelloProdottoInOffertaBean) prodotto).getPrezzoScontato() : prodotto.getPrezzoTaglia();
                }
                
            	int quantitaDisponibile = prodotto.getQuantitaDisponibileTaglia();
            	BigDecimal prezzoCorrente = (prodotto_in_offerta) ? ((CarrelloProdottoInOffertaBean) prodotto).getPrezzoScontato() : prodotto.getPrezzoTaglia(); 

                if (quantitaDisponibile < quantita) {
                	contatore_modifiche++;
                }
                
                if(quantitaDisponibile > quantita && quantita == 0) {
                	contatore_modifiche++;
                }

                if(prodotto_in_offerta) {
                	
                	if(prezzoCorrente.compareTo(prezzo) != 0) {
                		contatore_modifiche++;
                	}
                } else {
                	
                	if (prezzoCorrente.compareTo(prezzo) != 0) {
                		contatore_modifiche++;
                    }
                }  
                if(contatore_modifiche >= 1) {
                	break;
                }
            }  
        } catch (SQLException e) {
			System.out.println("Error:" + e.getMessage());
		}
        }
        
    	//Rispondi con un JSON
    	response.setContentType("application/json");
    	response.setCharacterEncoding("UTF-8");
    	jsonResponse.put("contatoreModifiche", contatore_modifiche);
    	response.getWriter().write(jsonResponse.toString());
		}
	}

}
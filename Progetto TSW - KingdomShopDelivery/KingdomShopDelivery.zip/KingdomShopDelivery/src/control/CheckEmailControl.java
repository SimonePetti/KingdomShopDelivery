package control;

import org.json.JSONObject;

import model.dao.RegistrazioneDao;
import model.dao.interfacce.RegistrazioneDaoInterfaccia;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.BufferedReader;
import java.io.IOException;
import java.sql.SQLException;

public class CheckEmailControl extends HttpServlet {
	
	private static final long serialVersionUID = 1L;
	
	static RegistrazioneDaoInterfaccia RegistrazioneDao = new RegistrazioneDao();
	
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		// Leggi il corpo della richiesta JSON
        BufferedReader reader = request.getReader();
        JSONObject jsonObject = new JSONObject(reader.readLine());
        JSONObject jsonResponse = new JSONObject();
        
        String email = jsonObject.getString("EmailDaControllare");
    	email = email.trim();
    	
    	try {
    		if(RegistrazioneDao.ControllaEmail(email)) {
    			jsonResponse.put("EmailGiaPresente", "true");
    		} else {
    			jsonResponse.put("EmailGiaPresente", "false");
    		}
    	} catch (SQLException e) {
			System.out.println("Error:" + e.getMessage());
		}
    	
    	//Rispondo con un JSON
    	response.setContentType("application/json");
    	response.setCharacterEncoding("UTF-8");
    	response.getWriter().write(jsonResponse.toString());
    }
}

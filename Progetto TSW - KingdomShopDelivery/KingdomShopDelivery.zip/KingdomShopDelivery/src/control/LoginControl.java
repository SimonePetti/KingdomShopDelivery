package control;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.Collection;
import java.util.Enumeration;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import model.beans.CarrelloBean;
import model.beans.CarrelloProdottoBean;
import model.beans.CarrelloProdottoInOffertaBean;
import model.beans.ConfermaOrdineBean;
import model.beans.WishListBean;
import model.dao.CarrelloDao;
import model.dao.RegistrazioneDao;
import model.dao.LoginDao;
import model.dao.interfacce.LoginDaoInterfaccia;
import model.dao.interfacce.WishListDaoInterfaccia;

public class LoginControl extends HttpServlet {
	
	private static final long serialVersionUID = 1L;
	
	static LoginDaoInterfaccia LoginDao = new LoginDao();
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.sendRedirect("login.jsp");
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		HttpSession session = request.getSession(true);
		Integer UtenteLoggato;
		String ruoloUtente;
		
		String email = request.getParameter("email");
		String password = request.getParameter("password");
		String sendRedirect = request.getParameter("sendRedirect");
		Boolean sendRedirectConfermaAcquisto = false;

		if(sendRedirect != null && sendRedirect.equals("confermaAcquisto")) {
			sendRedirect = "&sendRedirect=confermaAcquisto";
			sendRedirectConfermaAcquisto = true;
		} else {
			sendRedirect = "";
		}
    	
		email = email.trim();
		password = toHash(password);
		
		try {
			if((UtenteLoggato = LoginDao.ControllaCredenziali(email, password)) != -1) {
				pulisciSessione(session);
				session.setAttribute("idUtente", UtenteLoggato);
				ruoloUtente = LoginDao.getRuoloUtente(UtenteLoggato);
				session.setAttribute("ruoloUtente", ruoloUtente);
				ConfermaOrdineBean acquistoDaConfermare = new ConfermaOrdineBean();
				session.setAttribute("AcquistoDaConfermare", acquistoDaConfermare);
				
				if(sendRedirectConfermaAcquisto) {
					response.sendRedirect("./carrello");
				} else {
					response.sendRedirect("home.jsp");
				}
	    		return;
			} else {
	    		response.sendRedirect("login.jsp?login=fallito" + sendRedirect);
	    		return;
			}
		} catch (SQLException e) {
			System.out.println("Error:" + e.getMessage());
		}
		response.sendRedirect("login.jsp?login=fallito" + sendRedirect);
		return;
	}
	
	private String toHash(String password) {
		String hashString = null;
		try {
			java.security.MessageDigest digest = java.security.MessageDigest.getInstance("SHA-512");
			byte[] hash = digest.digest(password.getBytes(StandardCharsets.UTF_8));
			hashString = "";
			for(int i = 0; i < hash.length; i++) {
				hashString += Integer.toHexString((hash[i] & 0xFF) | 0x100).toLowerCase().substring(1,3);
			}
		} catch (java.security.NoSuchAlgorithmException e) {
			System.out.println(e);
		}
		return hashString;
	}
	
	private void pulisciSessione(HttpSession session) {
	    Enumeration<String> attributeNames = session.getAttributeNames();
	    
	    while (attributeNames.hasMoreElements()) {
	        String attributeName = attributeNames.nextElement();
	        session.removeAttribute(attributeName);
	    }
		
	}
	
}

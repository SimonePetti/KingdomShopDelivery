package control;

import java.io.BufferedReader;
import java.io.IOException;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.*;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.json.JSONObject;
import org.json.JSONArray;

import model.beans.CarrelloBean;
import model.beans.CarrelloProdottoBean;
import model.beans.CarrelloProdottoInOffertaBean;
import model.beans.WishListBean;
import model.dao.CarrelloDao;
import model.dao.WishListDao;
import model.dao.interfacce.CarrelloDaoInterfaccia;
import model.dao.interfacce.WishListDaoInterfaccia;

import java.io.InputStream;
import java.util.Base64;
import java.io.ByteArrayOutputStream;

public class CarrelloControl extends HttpServlet {
	
	private static final long serialVersionUID = 1L;

	static CarrelloDaoInterfaccia CarrelloDao = new CarrelloDao();
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		HttpSession session = request.getSession(true);
		CarrelloBean carrello = null;
		
		Integer id_utente = (Integer) session.getAttribute("idUtente");
		String action = (String) request.getParameter("action");
		
		int prodottoId = -1;
		int tagliaId = -1;
		
		Boolean UtenteLoggato = session.getAttribute("idUtente") != null;
		request.setAttribute("UtenteLoggato", UtenteLoggato);
		
		Boolean aggiungiMessaggioProdottoNonPiuDisponibile = false;
		Boolean aggiungiMessaggioProdottoCambioQuantitaCarrello = false;
		Boolean aggiungiMessaggioProdottoDiNuovoDisponibile = false;
		
		if(id_utente != null) {
			
		try {
				if(action != null) {
					
					try {
						prodottoId = Integer.parseInt(request.getParameter("id"));
						tagliaId = Integer.parseInt(request.getParameter("taglia")); 
						
					} catch (NumberFormatException e) { 
						response.sendRedirect("./home");
						return;
					}
					
					if(CarrelloDao.isIn(prodottoId,tagliaId)) {
						
						if(action.equalsIgnoreCase("add")) {
				
							if(CarrelloDao.isInCarrello(tagliaId,id_utente)) {
								CarrelloDao.incrementaDiUno(tagliaId,id_utente);
							} else {
								CarrelloDao.doSave(tagliaId, id_utente, 1);
							}
							
							response.sendRedirect("prodotto?id=" + prodottoId);
							return;
						}
						
						//Controllo se bisogna eliminare qualcosa
						if(action.equalsIgnoreCase("delete")) {
							CarrelloDao.doDelete(tagliaId,id_utente);
							response.sendRedirect("carrello");
							return;
						}
						
						response.sendRedirect("carrello");
						return;
					}
				}
				
				CarrelloBean carrelloProdottiDisponibili = new CarrelloBean();
				CarrelloBean carrelloProdottiNonDisponibili = new CarrelloBean();
				
				request.removeAttribute("ProdottiCarrelloCaricati");;
				request.removeAttribute("ProdottiCarrelloDisponibili");
				request.removeAttribute("ProdottiCarrelloNonDisponibili");
				
				carrello = CarrelloDao.getProdotti(id_utente);
				
				for(Map.Entry<CarrelloProdottoBean, Integer> entry : carrello.getProdotti().entrySet()) {
		    		
					CarrelloProdottoBean prodotto = entry.getKey();
					int quantita = entry.getValue();
					
		    		if(quantita > prodotto.getQuantitaDisponibileTaglia()) { 
		    			
		    			CarrelloDao.modificaQuantitaCarrello(prodotto.getIdTaglia(), id_utente, prodotto.getQuantitaDisponibileTaglia());	
		    			
		    			if(prodotto.getQuantitaDisponibileTaglia() == 0) {
		    				carrelloProdottiNonDisponibili.setProdottoLast(prodotto, 0);
		    				aggiungiMessaggioProdottoNonPiuDisponibile = true;
		    			} else {
		    			carrelloProdottiDisponibili.setProdottoLast(prodotto, prodotto.getQuantitaDisponibileTaglia());
		    			aggiungiMessaggioProdottoCambioQuantitaCarrello = true;
		    			}
		    		} else {
		    			
		    			if(quantita == 0) {		    				
		    				
		    				if(prodotto.getQuantitaDisponibileTaglia() > 0) {
		    					
		    					CarrelloDao.modificaQuantitaCarrello(prodotto.getIdTaglia(), id_utente, 1);
		    					carrelloProdottiDisponibili.setProdottoLast(prodotto, 1);
				    		    aggiungiMessaggioProdottoDiNuovoDisponibile = true;
		    				} else {
		    					carrelloProdottiNonDisponibili.setProdottoLast(prodotto, 0);
		    				}
		    			} else {
		    				carrelloProdottiDisponibili.setProdottoLast(prodotto, quantita);
		    			}
		    		}		
		    	}
		    	
		    	if(aggiungiMessaggioProdottoNonPiuDisponibile) {
		    		request.setAttribute("MessaggioProdottoNonPiuDisponibile", "Alcuni articoli nel tuo carrello non sono pi� disponibili al momento.");
		    	}
		    	
		    	if(aggiungiMessaggioProdottoCambioQuantitaCarrello) {
		    		request.setAttribute("MessaggioProdottoCambioQuantitaCarrello", "Alcuni articoli nel tuo carrello sono stati aggiornati a causa della disponibilit� limitata.");
		    	}
		    	
		    	if(aggiungiMessaggioProdottoDiNuovoDisponibile) {
		    		request.setAttribute("MessaggioProdottoDiNuovoDisponibile", "Alcuni articoli nel tuo carrello sono di nuovo disponibili. La quantit� � stata impostata su 1.");
		    	}
				
				request.setAttribute("ProdottiCarrelloDisponibili", carrelloProdottiDisponibili);
				request.setAttribute("ProdottiCarrelloNonDisponibili", carrelloProdottiNonDisponibili);
				request.setAttribute("ProdottiCarrelloCaricati", true);
				RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/carrello.jsp");
				dispatcher.forward(request, response); 
				return;
				
		} catch (SQLException e) {
				System.out.println("Error:" + e.getMessage());
		}
			
		} else {

		try {
				LinkedHashMap<List<Integer>, Integer> carrelloGuest = (LinkedHashMap<List<Integer>, Integer>) session.getAttribute("CarrelloGuest");
				
				if(carrelloGuest == null) {
					carrelloGuest = new LinkedHashMap<List<Integer>, Integer>();
				}
				
				if(action != null) {
					
					try {
						prodottoId = Integer.parseInt(request.getParameter("id"));
						tagliaId = Integer.parseInt(request.getParameter("taglia"));
					} catch (NumberFormatException e) {
						response.sendRedirect("./home");
						return;
					}
					
					if(CarrelloDao.isIn(prodottoId,tagliaId)) {
						
						if(action.equalsIgnoreCase("add")) {
							
	                    	int quantitaDisponibile = CarrelloDao.getQuantitaDisponibileTaglia(tagliaId);
	                    	
	                    	if(quantitaDisponibile > 0) {
	                    		
	                    		if(contieneProdotto_Taglia(carrelloGuest, prodottoId, tagliaId)) {
									aumentaQuantita_ProdottoTaglia(carrelloGuest, prodottoId, tagliaId, quantitaDisponibile);
								} else {
									
									LinkedHashMap<List<Integer>, Integer> temp = new LinkedHashMap<List<Integer>, Integer>();
									temp.put(Arrays.asList(prodottoId, tagliaId), 1);
									temp.putAll(carrelloGuest);
									carrelloGuest = temp;
								
									session.removeAttribute("CarrelloGuest");
									session.setAttribute("CarrelloGuest", carrelloGuest);
								}
	                    	}
	                    	
							response.sendRedirect("prodotto?id=" + prodottoId);
							return;
						}
						
						if(action.equalsIgnoreCase("delete")) {
					
							carrelloGuest.remove(Arrays.asList(prodottoId,tagliaId));
							
							session.removeAttribute("CarrelloGuest");
							session.setAttribute("CarrelloGuest", carrelloGuest);
							
							response.sendRedirect("carrello");
							return;
						}
						
						response.sendRedirect("carrello");
						return;
					}
					
				}
				
				request.removeAttribute("ProdottiCarrelloCaricati");
				request.removeAttribute("ProdottiCarrelloDisponibili");
				request.removeAttribute("ProdottiCarrelloNonDisponibili");
				
				CarrelloBean carrelloProdottiDisponibili = new CarrelloBean();
				CarrelloBean carrelloProdottiNonDisponibili = new CarrelloBean();
				
				if(carrelloGuest == null || carrelloGuest.isEmpty()) {
					
					request.setAttribute("ProdottiCarrelloDisponibili", carrelloProdottiDisponibili);
					request.setAttribute("ProdottiCarrelloNonDisponibili", carrelloProdottiNonDisponibili);
					request.setAttribute("ProdottiCarrelloCaricati", true);
						
					RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/carrello.jsp");
					dispatcher.forward(request, response);
					return; 
				}
				
				carrello = CarrelloDao.getProdottiGuest(carrelloGuest);
				carrello = carrello.orderBy(carrelloGuest);
				
				for(Map.Entry<CarrelloProdottoBean, Integer> entry : carrello.getProdotti().entrySet()) {
		    		
					CarrelloProdottoBean prodotto = entry.getKey();
					int quantita = entry.getValue();
					
		    		if(quantita > prodotto.getQuantitaDisponibileTaglia()) {
		    			
		    			
		    		    for (Map.Entry<List<Integer>, Integer> entrycarrelloGuest : carrelloGuest.entrySet()) {
		    		        List<Integer> chiave = entrycarrelloGuest.getKey();
		    		        
		    		        if (chiave.equals(Arrays.asList(prodotto.getIdProdotto(), prodotto.getIdTaglia()))) {
		    		            carrelloGuest.put(chiave, prodotto.getQuantitaDisponibileTaglia()); 
		    		            break;
		    		        }
		    		    }
		    			
		    			if(prodotto.getQuantitaDisponibileTaglia() == 0) {
		    				carrelloProdottiNonDisponibili.setProdottoLast(prodotto, 0);
		    				aggiungiMessaggioProdottoNonPiuDisponibile = true;
		    			} else {
		    			carrelloProdottiDisponibili.setProdottoLast(prodotto, prodotto.getQuantitaDisponibileTaglia());
		    			aggiungiMessaggioProdottoCambioQuantitaCarrello = true;
		    			}
		    		} else {

		    			if(quantita == 0) {		    				
		    				
		    				if(prodotto.getQuantitaDisponibileTaglia() > 0) {
		    				
		    					for (Map.Entry<List<Integer>, Integer> entrycarrelloGuest : carrelloGuest.entrySet()) {
		    						List<Integer> chiave = entrycarrelloGuest.getKey();
			    		        
		    						if (chiave.equals(Arrays.asList(prodotto.getIdProdotto(), prodotto.getIdTaglia()))) {
		    							
		    							carrelloGuest.put(chiave, 1);
		    							break;
		    						}
		    					}
		    					carrelloProdottiDisponibili.setProdottoLast(prodotto, 1);
		    					aggiungiMessaggioProdottoDiNuovoDisponibile = true;
		    				} else {

		    					carrelloProdottiNonDisponibili.setProdottoLast(prodotto, 0);
		    				}
		    			} else {
		    				carrelloProdottiDisponibili.setProdottoLast(prodotto, quantita);
		    			}	 
		    		}
		    	}
				
    		    session.setAttribute("CarrelloGuest", carrelloGuest);
		    	
		    	if(aggiungiMessaggioProdottoNonPiuDisponibile) {
		    		request.setAttribute("MessaggioProdottoNonPiuDisponibile", "Alcuni articoli nel tuo carrello non sono pi� disponibili al momento.");
		    	} 
		    	
		    	if(aggiungiMessaggioProdottoCambioQuantitaCarrello) {
		    		request.setAttribute("MessaggioProdottoCambioQuantitaCarrello", "Alcuni articoli nel tuo carrello sono stati aggiornati a causa della disponibilit� limitata.");
		    	}
		    	
		    	if(aggiungiMessaggioProdottoDiNuovoDisponibile) {
		    		request.setAttribute("MessaggioProdottoDiNuovoDisponibile", "Alcuni articoli nel tuo carrello sono di nuovo disponibili. La quantit� � stata impostata su 1.");
		    	}
				 
				request.setAttribute("ProdottiCarrelloDisponibili", carrelloProdottiDisponibili);
				request.setAttribute("ProdottiCarrelloNonDisponibili", carrelloProdottiNonDisponibili);
				request.setAttribute("ProdottiCarrelloCaricati", true);
				
				RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/carrello.jsp");
				dispatcher.forward(request, response);
				return;
				
		} catch (SQLException e) {
				System.out.println("Error:" + e.getMessage());
		}
			
		}
	}
	
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		HttpSession session = request.getSession(true);
		
		Integer id_utente = (Integer) session.getAttribute("idUtente");
		
        BufferedReader reader = request.getReader();
        JSONObject jsonObject = new JSONObject(reader.readLine());
        JSONObject jsonResponse = new JSONObject();
        
        String action = jsonObject.getString("action");
        int prodottoId = jsonObject.getInt("idProdotto");
		int tagliaId = jsonObject.getInt("idTaglia");
        
        if(id_utente != null) {
        	
        	try {
        		
        	if(prodottoId != -1 && tagliaId != -1) {
        		
        		if(CarrelloDao.isIn(prodottoId,tagliaId)) {
        			
        			if(action.equalsIgnoreCase("modificaQuantita")) {
        				
                		int quantitaNuova = jsonObject.getInt("quantitaNuova");	
        				
        				if(CarrelloDao.isInCarrello(tagliaId,id_utente)) {
            				CarrelloDao.aumentaQuantita(tagliaId, id_utente, quantitaNuova);
            			} 
        				jsonResponse.put("ModificaEffettuata", "true");
                	}
				}
        	} else {jsonResponse.put("ModificaEffettuata", "true");}
        		
        		CarrelloBean carrello = CarrelloDao.getProdotti(id_utente);
        		CarrelloBean carrelloProdottiDisponibili = new CarrelloBean();
        		
        		Boolean aggiungiMessaggioProdottoNonPiuDisponibile = false;
				Boolean aggiungiMessaggioProdottoCambioQuantitaCarrello = false;
				Boolean aggiungiMessaggioProdottoDiNuovoDisponibile = false;
				
				JSONArray Messaggi = new JSONArray();
				JSONArray CarrelloProdottiDisponibili = new JSONArray();
				JSONArray CarrelloProdottiNonDisponibili = new JSONArray();
				JSONObject CarrelloInformazioniTotale = new JSONObject();
				
				if(!carrello.isEmpty()) {
        		
        		for(Map.Entry<CarrelloProdottoBean, Integer> entry : carrello.getProdotti().entrySet()) {
		    		
        			JSONObject prodottoJson = new JSONObject();
        			int quantitaJson = 0;
        			Boolean prodottoDisponibile = true;
        			
					CarrelloProdottoBean prodotto = entry.getKey();
					int quantita = entry.getValue();
					
		    		if(quantita > prodotto.getQuantitaDisponibileTaglia()) { 
		    			
		    			CarrelloDao.modificaQuantitaCarrello(prodotto.getIdTaglia(), id_utente, prodotto.getQuantitaDisponibileTaglia());	
		    			
		    			if(prodotto.getQuantitaDisponibileTaglia() == 0) {
		    				quantitaJson = 0;
		    				prodottoDisponibile = false;
		    				aggiungiMessaggioProdottoNonPiuDisponibile = true;
		    			} else {
		    				quantitaJson = prodotto.getQuantitaDisponibileTaglia();
		    				prodottoDisponibile = true;
		    				aggiungiMessaggioProdottoCambioQuantitaCarrello = true;
		    			}
		    		} else {
		    			
		    			if(quantita == 0) {		    				
		    				
		    				if(prodotto.getQuantitaDisponibileTaglia() > 0) {
		    					
		    					CarrelloDao.modificaQuantitaCarrello(prodotto.getIdTaglia(), id_utente, 1);
		    					quantitaJson = 1;
		    					prodottoDisponibile = true;
				    		    aggiungiMessaggioProdottoDiNuovoDisponibile = true;
		    				} else {
		    					quantitaJson = 0;
		    					prodottoDisponibile = false;
		    				}
		    			} else {
		    				quantitaJson = quantita;
		    				prodottoDisponibile = true;
		    			}
		    		}
		    		
		    		prodottoJson.put("id_prodotto", prodotto.getIdProdotto());
		    		prodottoJson.put("id_taglia", prodotto.getIdTaglia());
		    		prodottoJson.put("nome_prodotto", prodotto.getNomeProdotto());
		    		prodottoJson.put("marca_prodotto", prodotto.getMarcaProdotto());
		    		prodottoJson.put("nome_taglia", prodotto.getNomeTaglia());
		    		prodottoJson.put("prezzo_taglia", prodotto.getPrezzoTaglia());
		    		prodottoJson.put("iva", prodotto.getIva().toString());
		    		prodottoJson.put("quantita_disponibile_taglia", prodotto.getQuantitaDisponibileTaglia());
		    		prodottoJson.put("quantita_inserita", quantitaJson);
		    		
		    	    if (prodotto.getImmagine() != null) {
		    	        try {
		    	            InputStream immagine = prodotto.getImmagine();
		    	            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
		    	            byte[] buffer = new byte[1024];
		    	            int bytesRead;
		    	            while ((bytesRead = immagine.read(buffer)) != -1) {
		    	                byteArrayOutputStream.write(buffer, 0, bytesRead);
		    	            }
		    	            String base64Image = Base64.getEncoder().encodeToString(byteArrayOutputStream.toByteArray());
		    	            prodottoJson.put("immagine", base64Image);
		    	        } catch (IOException e) {
		    	            e.printStackTrace();
		    	            prodottoJson.put("immagine", "");
		    	        }
		    	    }	
		    		
		    		if(prodotto instanceof CarrelloProdottoInOffertaBean) {
		    			CarrelloProdottoInOffertaBean offerta = (CarrelloProdottoInOffertaBean) prodotto;
		    			prodottoJson.put("taglia_in_offerta", true);
		    			prodottoJson.put("prezzo_iniziale", offerta.getPrezzoIniziale());
		    			prodottoJson.put("percentuale_sconto", offerta.getPercentualeSconto());
		    			prodottoJson.put("prezzo_scontato", offerta.getPrezzoScontato());
		    		} else {
		    			prodottoJson.put("taglia_in_offerta", false);
		    		}
		    		
		    		if(prodottoDisponibile) {
		    			CarrelloProdottiDisponibili.put(prodottoJson);
		    			carrelloProdottiDisponibili.aggiungiProdotto(prodotto, quantitaJson);
		    		} else {
		    			CarrelloProdottiNonDisponibili.put(prodottoJson);
		    		}
		    	}
        		
        		CarrelloInformazioniTotale.put("subtotale", carrelloProdottiDisponibili.calcolaPrezzoTotale().toString());
        		CarrelloInformazioniTotale.put("costo_spedizione", carrelloProdottiDisponibili.calcolaCostoSpedizione());
        		CarrelloInformazioniTotale.put("costo_totale", carrelloProdottiDisponibili.calcolaPrezzoTotaleCarrello().toString());	
        		
        	if(aggiungiMessaggioProdottoNonPiuDisponibile) {
        			JSONObject MPNPD = new JSONObject();
        			MPNPD.put("id_tag", "MessaggioProdottoNonPiuDisponibile");
        			MPNPD.put("Messaggio", "Alcuni articoli nel tuo carrello non sono pi� disponibili al momento.");
        			Messaggi.put(MPNPD);
		    	}
		    	
		    	if(aggiungiMessaggioProdottoCambioQuantitaCarrello) {
		    		JSONObject MPCQC = new JSONObject();
		    		MPCQC.put("id_tag", "MessaggioProdottoCambioQuantitaCarrello");
		    		MPCQC.put("Messaggio", "Alcuni articoli nel tuo carrello sono stati aggiornati a causa della disponibilit� limitata.");
        			Messaggi.put(MPCQC);
		    	}
		    	
		    	if(aggiungiMessaggioProdottoDiNuovoDisponibile) {
		    		JSONObject MPDND = new JSONObject();
		    		MPDND.put("id_tag", "MessaggioProdottoDiNuovoDisponibile");
		    		MPDND.put("Messaggio", "Alcuni articoli nel tuo carrello sono di nuovo disponibili. La quantit� � stata impostata su 1.");
        			Messaggi.put(MPDND);
		    	}
		    	
				}
		    	
		    	jsonResponse.put("CarrelloProdottiDisponibili", CarrelloProdottiDisponibili);
		    	jsonResponse.put("CarrelloInformazioniTotale", CarrelloInformazioniTotale);
		    	jsonResponse.put("CarrelloProdottiNonDisponibili", CarrelloProdottiNonDisponibili);
		    	jsonResponse.put("Messaggi", Messaggi);
        	
        	} catch (SQLException e) {
				System.out.println("Error:" + e.getMessage());
        	}
        	
        	//Rispondi con un JSON
        	response.setContentType("application/json");
        	response.setCharacterEncoding("UTF-8");
        	response.getWriter().write(jsonResponse.toString());
        	
        } else { //guest
        	
        	LinkedHashMap<List<Integer>, Integer> carrelloGuest = (LinkedHashMap<List<Integer>, Integer>) session.getAttribute("CarrelloGuest");
        	
        	try {
            	if(CarrelloDao.isIn(prodottoId,tagliaId)) {

            		if(action.equalsIgnoreCase("modificaQuantita")) {

                    	int quantitaNuova = jsonObject.getInt("quantitaNuova");	
                    	int quantitaDisponibile = CarrelloDao.getQuantitaDisponibileTaglia(tagliaId);
                    	
                    	if(quantitaDisponibile == 0) {quantitaDisponibile = 1;} 
                    	
                    	if(quantitaNuova > quantitaDisponibile) {
            				quantitaNuova = quantitaDisponibile;
            			}
                    	
                    	if(contieneProdotto_Taglia(carrelloGuest, prodottoId, tagliaId)) {
    						modificaQuantita_ProdottoTaglia(carrelloGuest, prodottoId, tagliaId, quantitaNuova);
    					}
       	 
            			jsonResponse.put("ModificaEffettuata", "true");
                    	}
    				}
            	
            	CarrelloBean carrello = new CarrelloBean();
        		CarrelloBean carrelloProdottiDisponibili = new CarrelloBean();
        		
        		Boolean aggiungiMessaggioProdottoNonPiuDisponibile = false;
				Boolean aggiungiMessaggioProdottoCambioQuantitaCarrello = false;
				Boolean aggiungiMessaggioProdottoDiNuovoDisponibile = false;
				
				JSONArray Messaggi = new JSONArray();
				JSONArray CarrelloProdottiDisponibili = new JSONArray();
				JSONArray CarrelloProdottiNonDisponibili = new JSONArray();
				JSONObject CarrelloInformazioniTotale = new JSONObject();
				
				if(!carrelloGuest.isEmpty()) {
				
				carrello = CarrelloDao.getProdottiGuest(carrelloGuest);
				carrello = carrello.orderBy(carrelloGuest);
				
				for(Map.Entry<CarrelloProdottoBean, Integer> entry : carrello.getProdotti().entrySet()) {
					
					JSONObject prodottoJson = new JSONObject();
        			int quantitaJson = 0;
        			Boolean prodottoDisponibile = true;
		    		
					CarrelloProdottoBean prodotto = entry.getKey();
					int quantita = entry.getValue();
					
		    		if(quantita > prodotto.getQuantitaDisponibileTaglia()) {
		    			
		    		    for (Map.Entry<List<Integer>, Integer> entrycarrelloGuest : carrelloGuest.entrySet()) {
		    		        List<Integer> chiave = entrycarrelloGuest.getKey();
		    		        
		    		        if (chiave.equals(Arrays.asList(prodotto.getIdProdotto(), prodotto.getIdTaglia()))) {
		    		            
		    		            carrelloGuest.put(chiave, prodotto.getQuantitaDisponibileTaglia());
		    		            break;
		    		        }
		    		    }
		    			
		    			if(prodotto.getQuantitaDisponibileTaglia() == 0) {
		    				quantitaJson = 0;
		    				prodottoDisponibile = false;
		    				aggiungiMessaggioProdottoNonPiuDisponibile = true;
		    			} else {
		    				quantitaJson = prodotto.getQuantitaDisponibileTaglia();
		    				prodottoDisponibile = true;
		    				aggiungiMessaggioProdottoCambioQuantitaCarrello = true;
		    			}
		    		} else {
		    			
		    			if(quantita == 0) {		    				
		    				
		    				if(prodotto.getQuantitaDisponibileTaglia() > 0) {
		    				
		    					
		    					for (Map.Entry<List<Integer>, Integer> entrycarrelloGuest : carrelloGuest.entrySet()) {
		    						List<Integer> chiave = entrycarrelloGuest.getKey();
			    		        
		    						if (chiave.equals(Arrays.asList(prodotto.getIdProdotto(), prodotto.getIdTaglia()))) {
		    							
		    							carrelloGuest.put(chiave, 1);
		    							break;
		    						}
		    					}
		    					quantitaJson = 1;
			    				prodottoDisponibile = true;
		    					aggiungiMessaggioProdottoDiNuovoDisponibile = true;
		    				} else {
		    					quantitaJson = 0;
			    				prodottoDisponibile = false;
		    				}
		    			} else {
		    				quantitaJson = quantita;
		    				prodottoDisponibile = true;
		    			}	 
		    		}
		    				
		    		prodottoJson.put("id_prodotto", prodotto.getIdProdotto());
		    		prodottoJson.put("id_taglia", prodotto.getIdTaglia());
		    		prodottoJson.put("nome_prodotto", prodotto.getNomeProdotto());
		    		prodottoJson.put("marca_prodotto", prodotto.getMarcaProdotto());
		    		prodottoJson.put("nome_taglia", prodotto.getNomeTaglia());
		    		prodottoJson.put("prezzo_taglia", prodotto.getPrezzoTaglia());
		    		prodottoJson.put("iva", prodotto.getIva().toString());
		    		prodottoJson.put("quantita_disponibile_taglia", prodotto.getQuantitaDisponibileTaglia());
		    		prodottoJson.put("quantita_inserita", quantitaJson);
		    		
		    	    if (prodotto.getImmagine() != null) {
		    	        try {
		    	            InputStream immagine = prodotto.getImmagine();
		    	            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
		    	            byte[] buffer = new byte[1024];
		    	            int bytesRead;
		    	            while ((bytesRead = immagine.read(buffer)) != -1) {
		    	                byteArrayOutputStream.write(buffer, 0, bytesRead);
		    	            }
		    	            String base64Image = Base64.getEncoder().encodeToString(byteArrayOutputStream.toByteArray());
		    	            prodottoJson.put("immagine", base64Image);
		    	        } catch (IOException e) {
		    	            e.printStackTrace();
		    	            prodottoJson.put("immagine", "");
		    	        }
		    	    }	
		    		
		    		if(prodotto instanceof CarrelloProdottoInOffertaBean) {
		    			CarrelloProdottoInOffertaBean offerta = (CarrelloProdottoInOffertaBean) prodotto;
		    			prodottoJson.put("taglia_in_offerta", true);
		    			prodottoJson.put("prezzo_iniziale", offerta.getPrezzoIniziale());
		    			prodottoJson.put("percentuale_sconto", offerta.getPercentualeSconto());
		    			prodottoJson.put("prezzo_scontato", offerta.getPrezzoScontato());
		    		} else {
		    			prodottoJson.put("taglia_in_offerta", false);
		    		}
		    		
		    		if(prodottoDisponibile) {
		    			CarrelloProdottiDisponibili.put(prodottoJson);
		    			carrelloProdottiDisponibili.aggiungiProdotto(prodotto, quantitaJson);
		    		} else {
		    			CarrelloProdottiNonDisponibili.put(prodottoJson);
		    		}
		    	}
				
				CarrelloInformazioniTotale.put("subtotale", carrelloProdottiDisponibili.calcolaPrezzoTotale().toString());
        		CarrelloInformazioniTotale.put("costo_spedizione", carrelloProdottiDisponibili.calcolaCostoSpedizione());
        		CarrelloInformazioniTotale.put("costo_totale", carrelloProdottiDisponibili.calcolaPrezzoTotaleCarrello().toString());				
				
        		if(aggiungiMessaggioProdottoNonPiuDisponibile) {
        			JSONObject MPNPD = new JSONObject();
        			MPNPD.put("id_tag", "MessaggioProdottoNonPiuDisponibile");
        			MPNPD.put("Messaggio", "Alcuni articoli nel tuo carrello non sono pi� disponibili al momento.");
        			Messaggi.put(MPNPD);
		    	}
		    	
		    	if(aggiungiMessaggioProdottoCambioQuantitaCarrello) {
		    		JSONObject MPCQC = new JSONObject();
		    		MPCQC.put("id_tag", "MessaggioProdottoCambioQuantitaCarrello");
		    		MPCQC.put("Messaggio", "Alcuni articoli nel tuo carrello sono stati aggiornati a causa della disponibilit� limitata.");
        			Messaggi.put(MPCQC);
		    	}
		    	
		    	if(aggiungiMessaggioProdottoDiNuovoDisponibile) {
		    		JSONObject MPDND = new JSONObject();
		    		MPDND.put("id_tag", "MessaggioProdottoDiNuovoDisponibile");
		    		MPDND.put("Messaggio", "Alcuni articoli nel tuo carrello sono di nuovo disponibili. La quantit� � stata impostata su 1.");
        			Messaggi.put(MPDND);
		    	}
		    	
				}
		    	
		    	jsonResponse.put("CarrelloProdottiDisponibili", CarrelloProdottiDisponibili);
		    	jsonResponse.put("CarrelloInformazioniTotale", CarrelloInformazioniTotale);
		    	jsonResponse.put("CarrelloProdottiNonDisponibili", CarrelloProdottiNonDisponibili);
		    	jsonResponse.put("Messaggi", Messaggi);
            	
            	} catch (SQLException e) {
    				System.out.println("Error:" + e.getMessage());
            	}
            	
            	//Rispondi con un JSON
            	response.setContentType("application/json");
            	response.setCharacterEncoding("UTF-8");
            	response.getWriter().write(jsonResponse.toString());
        }
	}
	
	private boolean contieneProdotto_Taglia(LinkedHashMap<List<Integer>, Integer> carrelloGuest, int id_prodotto, int id_taglia) {
		
		for (Map.Entry<List<Integer>, Integer> entry : carrelloGuest.entrySet()) {
            List<Integer> chiave = entry.getKey();
            
            if (chiave.get(0) == id_prodotto && chiave.get(1) == id_taglia) {
                return true;
            }
        }
		return false;
	}
	
	private void aumentaQuantita_ProdottoTaglia(LinkedHashMap<List<Integer>, Integer> carrelloGuest, int id_prodotto, int id_taglia, int quantitaDisponibile) {
		
		for (Map.Entry<List<Integer>, Integer> entry : carrelloGuest.entrySet()) {
            List<Integer> chiave = entry.getKey();
            
            if (chiave.get(0) == id_prodotto && chiave.get(1) == id_taglia) {
            	if(entry.getValue() < quantitaDisponibile) {
            		carrelloGuest.put(chiave, entry.getValue() + 1);
            	}
            return;
            }
        }
	}
	
	private void modificaQuantita_ProdottoTaglia(LinkedHashMap<List<Integer>, Integer> carrelloGuest, int id_prodotto, int id_taglia, int quantita) {
		
		for (Map.Entry<List<Integer>, Integer> entry : carrelloGuest.entrySet()) {
            List<Integer> chiave = entry.getKey();
            
            if (chiave.get(0) == id_prodotto && chiave.get(1) == id_taglia) {
                carrelloGuest.put(chiave, quantita);
                return;
            }
        }
	}
	
}

package control.admin;

import java.io.IOException;
import java.sql.SQLException;
import java.util.LinkedList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import model.beans.Admin_ProdottoBean;
import model.beans.CartaBean;
import model.dao.Admin_ProdottiDao;
import model.dao.interfacce.Admin_ProdottiDaoInterfaccia;

public class GestioneProdottiControl extends HttpServlet {
	
	private static final long serialVersionUID = 1L;
	
	static Admin_ProdottiDaoInterfaccia Admin_ProdottiDao  = new Admin_ProdottiDao();
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		HttpSession session = request.getSession(true);
		int idUtente = (Integer) session.getAttribute("idUtente");
		LinkedList<Admin_ProdottoBean> prodotti = new LinkedList<Admin_ProdottoBean>();
		
		try { 
			prodotti = Admin_ProdottiDao.getProdotti();
		} catch (SQLException e) {
			System.out.println("Error:" + e.getMessage());
		}
		
		request.setAttribute("ProdottiCaricati", true);
		request.setAttribute("Prodotti", prodotti);	
		
		RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/admin/prodotti.jsp");
		dispatcher.forward(request, response);
	}

}

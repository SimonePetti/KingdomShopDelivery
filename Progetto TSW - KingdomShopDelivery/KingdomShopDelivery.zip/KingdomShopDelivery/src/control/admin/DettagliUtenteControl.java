package control.admin;

import java.io.IOException;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.beans.Admin_OrdineBean;
import model.beans.UtenteDettagliBean;
import model.dao.Admin_UtentiDao;
import model.dao.interfacce.Admin_UtentiDaoInterfaccia;

public class DettagliUtenteControl extends HttpServlet {
	
	private static final long serialVersionUID = 1L;
	
	static Admin_UtentiDaoInterfaccia UtentiDao = new Admin_UtentiDao();
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		int idUtente = -1;
		
		try {
	        idUtente = Integer.parseInt(request.getParameter("id"));
	    } catch (NumberFormatException e) {
	        response.sendRedirect("./utenti");
	        return;
	    }
		
		UtenteDettagliBean utente = new UtenteDettagliBean();
		
		try {
			utente = UtentiDao.getDettagliUtente(idUtente); 
		} catch (SQLException e) {
			System.out.println("Error:" + e.getMessage());
		}
		
		request.setAttribute("UtenteDettagliCaricati", true);
		request.setAttribute("UtenteDettagli", utente);
		
		RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/admin/utente.jsp");
		dispatcher.forward(request, response); 
		return;
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		int idUtente = -1;
		
		try {
	        idUtente = Integer.parseInt(request.getParameter("id"));
	    } catch (NumberFormatException e) {
	        response.sendRedirect("./utenti");
	        return;
	    }
		
		UtenteDettagliBean utente = new UtenteDettagliBean();
		String filtro_ordini = "";
		DateTimeFormatter formato = DateTimeFormatter.ofPattern("dd-MM-yyyy");
		
		String dataInizioStr = request.getParameter("dataInizio");
        LocalDate dataInizio = null;
        if (dataInizioStr != null && !dataInizioStr.trim().isEmpty()) {
            dataInizio = LocalDate.parse(dataInizioStr);
        }

        String dataFineStr = request.getParameter("dataFine");
        LocalDate dataFine = null;
        if (dataFineStr != null && !dataFineStr.trim().isEmpty()) {
            dataFine = LocalDate.parse(dataFineStr);
        }
		
		try {
			utente = UtentiDao.getDettagliUtente(idUtente, dataInizio, dataFine);
		} catch (SQLException e) {
			System.out.println("Error:" + e.getMessage());
		}
		
		if(dataInizio != null && dataFine != null) {
			filtro_ordini = " dal " + dataInizio.format(formato) + " al " + dataFine.format(formato);
		} else {
			if(dataInizio != null && dataFine == null) {
				filtro_ordini = " dal " + dataInizio.format(formato) + " ad oggi" ;
			} else {
				filtro_ordini = " fino al " + dataFine.format(formato);
			}
		}
		
		request.setAttribute("UtenteDettagliCaricati", true);
		request.setAttribute("UtenteDettagli", utente);
		request.setAttribute("filtroOrdini", filtro_ordini);
		
		RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/admin/utente.jsp");
		dispatcher.forward(request, response); 
		return;
	}

}

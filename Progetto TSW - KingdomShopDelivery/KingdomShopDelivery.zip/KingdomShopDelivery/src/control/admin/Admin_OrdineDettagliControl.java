package control.admin;

import java.io.IOException;
import java.sql.SQLException;
import java.util.LinkedHashMap;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.beans.Admin_OrdineBean;
import model.beans.Admin_OrdineDettagliBean;
import model.beans.OrdineDettagliBean;
import model.dao.Admin_OrdiniDao;
import model.dao.interfacce.Admin_OrdiniDaoInterfaccia;


public class Admin_OrdineDettagliControl extends HttpServlet {
	
	private static final long serialVersionUID = 1L;
	
	static Admin_OrdiniDaoInterfaccia OrdiniDao = new Admin_OrdiniDao();
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		int numero_ordine = -1;
		LinkedHashMap<Admin_OrdineDettagliBean,Integer> ordine = new LinkedHashMap<Admin_OrdineDettagliBean,Integer>();
		
		try {
	        numero_ordine = Integer.parseInt(request.getParameter("ordine"));
	    } catch (NumberFormatException e) {
	        response.sendRedirect("ordini");
	        return;
	    }
		
		try {
			ordine = OrdiniDao.getOrdineDettagli(numero_ordine);
		} catch (SQLException e) {
			System.out.println("Error:" + e.getMessage());
		}
		
		request.setAttribute("OrdineDettagliCaricati", true);
		request.setAttribute("Ordine", ordine);
		
		RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/admin/dettagli-ordine.jsp");
		dispatcher.forward(request, response); 
		return;
		
	}
}

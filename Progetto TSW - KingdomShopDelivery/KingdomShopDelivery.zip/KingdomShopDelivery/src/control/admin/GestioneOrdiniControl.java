package control.admin;

import java.io.IOException;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.LinkedList;
import java.util.List;
import java.util.LinkedHashMap;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.beans.Admin_OrdineBean;
import model.dao.Admin_OrdiniDao;
import model.dao.interfacce.Admin_OrdiniDaoInterfaccia;

public class GestioneOrdiniControl extends HttpServlet {

	private static final long serialVersionUID = 1L;
	
	static Admin_OrdiniDaoInterfaccia OrdiniDao = new Admin_OrdiniDao();
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		LinkedHashMap<Admin_OrdineBean,Integer> ordini = new LinkedHashMap<Admin_OrdineBean,Integer>();
		
		try {
			ordini = OrdiniDao.getOrdini();
		} catch (SQLException e) {
			System.out.println("Error:" + e.getMessage());
		}
		
		request.setAttribute("OrdiniCaricati", true);
		request.setAttribute("Ordini", ordini);
		
		RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/admin/ordini.jsp");
		dispatcher.forward(request, response); 
		return;	
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		LinkedHashMap<Admin_OrdineBean,Integer> ordini = new LinkedHashMap<Admin_OrdineBean,Integer>();
		String filtro_ordini = "";
		DateTimeFormatter formato = DateTimeFormatter.ofPattern("dd-MM-yyyy");
		
		String dataInizioStr = request.getParameter("dataInizio");
        LocalDate dataInizio = null;
        if (dataInizioStr != null && !dataInizioStr.trim().isEmpty()) {
            dataInizio = LocalDate.parse(dataInizioStr);
        }

        String dataFineStr = request.getParameter("dataFine");
        LocalDate dataFine = null;
        if (dataFineStr != null && !dataFineStr.trim().isEmpty()) {
            dataFine = LocalDate.parse(dataFineStr);
        }
		
		try {
			ordini = OrdiniDao.getOrdini(dataInizio, dataFine);
		} catch (SQLException e) {
			System.out.println("Error:" + e.getMessage());
		}
		
		request.setAttribute("OrdiniCaricati", true);
		request.setAttribute("Ordini", ordini);
		
		if(dataInizio != null && dataFine != null) {
			filtro_ordini = " dal " + dataInizio.format(formato) + " al " + dataFine.format(formato);
		} else {
			if(dataInizio != null && dataFine == null) {
				filtro_ordini = " dal " + dataInizio.format(formato) + " ad oggi" ;
			} else {
				filtro_ordini = " fino al " + dataFine.format(formato);
			}
		}
		
		request.setAttribute("filtroOrdini", filtro_ordini);
		
		RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/admin/ordini.jsp");
		dispatcher.forward(request, response); 
		return;	
	}
	
}

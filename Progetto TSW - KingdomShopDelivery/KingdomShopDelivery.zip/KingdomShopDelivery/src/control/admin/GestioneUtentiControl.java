package control.admin;

import java.io.IOException;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.dao.Admin_UtentiDao;
import model.dao.interfacce.Admin_UtentiDaoInterfaccia;
import model.beans.Admin_OrdineBean;
import model.beans.UtenteBean;

import java.util.List;
import java.util.LinkedHashMap;
import java.util.LinkedList;

public class GestioneUtentiControl extends HttpServlet {
	
	private static final long serialVersionUID = 1L;
	
	static Admin_UtentiDaoInterfaccia UtentiDao = new Admin_UtentiDao();
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		List<UtenteBean> utenti = new LinkedList<UtenteBean>();
		
		try {
			utenti = UtentiDao.getUtenti();
		} catch (SQLException e) {
			System.out.println("Error:" + e.getMessage());
		}
		
		request.setAttribute("UtentiCaricati", true);
		request.setAttribute("Utenti", utenti);
		
		RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/admin/utenti.jsp");
		dispatcher.forward(request, response); 
		return;
	}

}

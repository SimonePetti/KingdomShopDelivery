package control.admin;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import model.beans.UtenteDettagliBean;
import model.dao.Admin_ProdottiDao;
import model.dao.Admin_UtentiDao;
import model.dao.interfacce.Admin_ProdottiDaoInterfaccia;
import model.dao.interfacce.Admin_UtentiDaoInterfaccia;

public class Admin_ModificaRuoloControl extends HttpServlet {
	
	private static final long serialVersionUID = 1L;
	
	static Admin_UtentiDaoInterfaccia UtentiDao = new Admin_UtentiDao();

protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		HttpSession session = request.getSession(true);
	
		int idUtente = -1;
		int id_admin = (int) session.getAttribute("idUtente");
		
		try {
	        idUtente = Integer.parseInt(request.getParameter("utente"));
	    } catch (NumberFormatException e) {
	        response.sendRedirect("./utenti");
	        return;
	    }
		
		String nuovo_ruolo = request.getParameter("ruolo");
		
		if((!nuovo_ruolo.equals("utente") && !nuovo_ruolo.equals("admin")) && idUtente <= 0) {
			response.sendRedirect("./utenti");
	        return;
		}
		
		if(idUtente == id_admin ) {
			response.sendRedirect("./utenti?modificaRuolo=stessoUtente");
			return;
		}
		
		try {
			UtentiDao.modificaRuolo(idUtente, nuovo_ruolo); 
		} catch (SQLException e) {
			System.out.println("Error:" + e.getMessage());
		}
		
		response.sendRedirect("./utenti?modificaRuolo=successo");
		return;
	}
}

package control.admin;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.dao.Admin_UtentiDao;
import model.dao.Admin_OrdiniDao;
import model.dao.Admin_ProdottiDao;
import model.dao.interfacce.Admin_UtentiDaoInterfaccia;
import model.dao.interfacce.Admin_OrdiniDaoInterfaccia;
import model.dao.interfacce.Admin_ProdottiDaoInterfaccia;

public class DashboardControl extends HttpServlet {
	
	private static final long serialVersionUID = 1L;
	
	static Admin_UtentiDaoInterfaccia UtentiDao = new Admin_UtentiDao();
	static Admin_OrdiniDaoInterfaccia OrdiniDao = new Admin_OrdiniDao();
	static Admin_ProdottiDaoInterfaccia ProdottiDao = new Admin_ProdottiDao();
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		int utenti_totali = -1;
		int utenti_nuovi = -1;
		int vendite_totali = -1;
		int vendite_nuove = -1;
		int prodotti_catalogo = -1;
		int prodotti_venduti = -1;
		int prodotti_venduti_recentemente = -1;
		
		try {
			
			utenti_totali = UtentiDao.getNumeroUtentiTotali();
			utenti_nuovi = UtentiDao.getNumeroUtentiNuovi();
			vendite_totali = OrdiniDao.getNumeroVenditeTotali();
			vendite_nuove = OrdiniDao.getNumeroVenditeNuove();
			prodotti_catalogo = ProdottiDao.getNumeroProdotti();
			prodotti_venduti = OrdiniDao.getNumeroProdottiVenduti();
			prodotti_venduti_recentemente = OrdiniDao.getNumeroProdottiVendutiRecentemente();
			
		} catch (SQLException e) {
			System.out.println("Error:" + e.getMessage());
		}
		
		request.setAttribute("NumeroUtentiTotali",utenti_totali);
		request.setAttribute("NumeroUtentiNuovi",utenti_nuovi);
		request.setAttribute("NumeroVenditeTotali",vendite_totali);
		request.setAttribute("NumeroVenditeNuove",vendite_nuove);
		request.setAttribute("NumeroProdotti",prodotti_catalogo);
		request.setAttribute("NumeroProdottiVenduti",prodotti_venduti);
		request.setAttribute("NumeroProdottiVendutiRecentemente",prodotti_venduti_recentemente);
		request.setAttribute("DashboardCaricata", true);
		
		RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/admin/dashboard.jsp");
		dispatcher.forward(request, response); 
		return;
	}

}

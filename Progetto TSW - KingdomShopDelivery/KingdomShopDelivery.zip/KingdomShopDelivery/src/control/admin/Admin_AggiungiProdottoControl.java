package control.admin;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.nio.file.Paths;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.LinkedList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Part;

import model.beans.Admin_ProdottoDaAggiungereBean;
import model.beans.Admin_ProdottoTagliaDaAggiungereBean;
import model.dao.Admin_ProdottiDao;
import model.dao.interfacce.Admin_ProdottiDaoInterfaccia;

@MultipartConfig
public class Admin_AggiungiProdottoControl extends HttpServlet {
	
	private static final long serialVersionUID = 1L;
	
	static Admin_ProdottiDaoInterfaccia Admin_ProdottiDao  = new Admin_ProdottiDao();
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		HttpSession session = request.getSession(true);
		int idUtente = (Integer) session.getAttribute("idUtente");
		response.setCharacterEncoding("UTF-8");
        response.setContentType("text/html; charset=UTF-8");
		
		RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/admin/aggiungiProdotto.jsp");
		dispatcher.forward(request, response);
		return;
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        
        HttpSession session = request.getSession(true);
        int idUtente = (Integer) session.getAttribute("idUtente");
        String UPLOAD_DIRECTORY = "C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/KSD_immagini";
        request.setCharacterEncoding("UTF-8");
        response.setCharacterEncoding("UTF-8");
        response.setContentType("text/html; charset=UTF-8");
        
        String nome = request.getParameter("nome");
        String marca = request.getParameter("marca");
        String descrizione = request.getParameter("descrizione");
        String categoria = request.getParameter("categoria");
        String sottoCategoria = request.getParameter("sottocategoria");
        String ivaStr = request.getParameter("iva");
        BigDecimal iva = null;
        if (ivaStr != null && !ivaStr.trim().isEmpty()) {
            iva = new BigDecimal(ivaStr);
        }
        
        String percentualeScontoStr = request.getParameter("taglie_percentuale_sconto");
        BigDecimal percentualeSconto = null;
        if (percentualeScontoStr != null && !percentualeScontoStr.trim().isEmpty()) {
            percentualeSconto = new BigDecimal(percentualeScontoStr);
        }
        
        String dataInizioStr = request.getParameter("taglie_data_inizio");
        LocalDate dataInizio = null;
        if (dataInizioStr != null && !dataInizioStr.trim().isEmpty()) {
            dataInizio = LocalDate.parse(dataInizioStr);
        }

        String dataFineStr = request.getParameter("taglie_data_fine");
        LocalDate dataFine = null;
        if (dataFineStr != null && !dataFineStr.trim().isEmpty()) {
            dataFine = LocalDate.parse(dataFineStr);
        }
        
        Part filePart = request.getPart("immagine");
        InputStream inputStream = null;
        String fileName = "";
        String fullFilePath = "";
        
        String nome_nuova_taglia = request.getParameter("nuovo_nome_taglia");
        nome_nuova_taglia = nome_nuova_taglia.trim();
        String pnt = request.getParameter("nuovo_prezzo_taglia");
        String qnt = request.getParameter("nuovo_quantita_taglia");
        BigDecimal prezzo_nuova_taglia = new BigDecimal("0");
        int quantita_nuova_taglia = -1;

        if(nome_nuova_taglia != null && !nome_nuova_taglia.trim().isEmpty()) {
        	prezzo_nuova_taglia = new BigDecimal(pnt.trim());
        	quantita_nuova_taglia = Integer.parseInt(qnt.trim());
        }
        
        nome = nome.trim().replaceAll("\\s+", " ").replaceAll("\\s'\\s", "'").replaceAll("\\s-\\s", "-");
        marca = marca.trim().replaceAll("\\s+", " ").replaceAll("\\s'\\s", "'").replaceAll("\\s-\\s", "-");
        descrizione = descrizione.trim().replaceAll("\\s+", " ").replaceAll("\\s'\\s", "'").replaceAll("\\s-\\s", "-");
        
        if (filePart != null && filePart.getSize() > 0) {
            fileName = Paths.get(filePart.getSubmittedFileName()).getFileName().toString();
            inputStream = filePart.getInputStream();
            
            
            String uploadFilePath = UPLOAD_DIRECTORY;
            File uploadDir = new File(uploadFilePath);
            if (!uploadDir.exists()) {
                uploadDir.mkdirs();
            }
            File file = new File(uploadDir, fileName);
            fullFilePath = file.getAbsolutePath();
            try (FileOutputStream fos = new FileOutputStream(file)) {
                byte[] buffer = new byte[1024];
                int bytesRead;
                while ((bytesRead = inputStream.read(buffer)) != -1) {
                    fos.write(buffer, 0, bytesRead);
                }
            }
        }
        
        Admin_ProdottoDaAggiungereBean prodotto = new Admin_ProdottoDaAggiungereBean();
        prodotto.setNomeProdotto(nome);
        prodotto.setMarca(marca);
        prodotto.setDescrizione(descrizione);
        prodotto.setCategoria(categoria);
        prodotto.setSottoCategoria(sottoCategoria);
        prodotto.setIva(iva);
        prodotto.setPercentualeSconto(percentualeSconto);
        prodotto.setDataInizio(dataInizio);
        prodotto.setDataFine(dataFine);
        
        if (inputStream != null) {
            prodotto.setImmagine(inputStream);
        }
        
        Admin_ProdottoTagliaDaAggiungereBean taglia = new Admin_ProdottoTagliaDaAggiungereBean();
        taglia.setNomeTaglia(nome_nuova_taglia);
        taglia.setPrezzoTaglia(prezzo_nuova_taglia);
        taglia.setQuantitaDisponibile(quantita_nuova_taglia);
        
        prodotto.aggiungiTaglia(taglia);
        
        try {
            Admin_ProdottiDao.inserisciProdotto(prodotto, fullFilePath, taglia);
            response.sendRedirect("./prodotti?inserimento=successo");
        } catch (SQLException e) {
            System.out.println("Error:" + e.getMessage());
        }
    }

}

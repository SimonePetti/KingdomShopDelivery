package control.admin;

import java.io.IOException;
import java.sql.SQLException;
import java.util.LinkedList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import model.beans.Admin_ProdottoBean;
import model.dao.Admin_ProdottiDao;
import model.dao.interfacce.Admin_ProdottiDaoInterfaccia;

public class Admin_EliminaProdottoControl extends HttpServlet {
	
private static final long serialVersionUID = 1L;
	
	static Admin_ProdottiDaoInterfaccia Admin_ProdottiDao  = new Admin_ProdottiDao();
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		HttpSession session = request.getSession(true);
		int idUtente = (Integer) session.getAttribute("idUtente");
		int idProdotto = -1;
		try {
	        idProdotto = Integer.parseInt(request.getParameter("id"));
	    } catch (NumberFormatException e) {
	        response.sendRedirect("./home");
	        return;
	    }
		
		try { 
			Admin_ProdottiDao.eliminaProdotto(idProdotto);
		} catch (SQLException e) {
			System.out.println("Error:" + e.getMessage());
		}	
		
		response.sendRedirect("./prodotti?eliminazione=successo");
	}

}

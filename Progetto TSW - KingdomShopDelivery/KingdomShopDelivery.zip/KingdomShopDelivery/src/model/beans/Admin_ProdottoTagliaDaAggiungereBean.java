package model.beans;

import model.beans.Admin_ProdottoTagliaDaModificareBean;

public class Admin_ProdottoTagliaDaAggiungereBean extends Admin_ProdottoTagliaDaModificareBean {
	
	private static final long serialVersionUID = 1L;
	
	//Costruttore vuoto
	public Admin_ProdottoTagliaDaAggiungereBean() {
		super();
	}
}

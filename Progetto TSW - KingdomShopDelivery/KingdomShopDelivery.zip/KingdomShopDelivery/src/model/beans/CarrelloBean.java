package model.beans;

import java.io.Serializable;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.math.BigDecimal;


public class CarrelloBean implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private LinkedHashMap<CarrelloProdottoBean, Integer> prodotti;
	
	//Costruttore vuoto
	public CarrelloBean() {
		prodotti = new LinkedHashMap<CarrelloProdottoBean, Integer>();
	}
	

	public void aggiungiProdotto(CarrelloProdottoBean prodotto, int quantita) {
		if(prodotti.containsKey(prodotto)) {
			prodotti.put(prodotto, prodotti.get(prodotto) + quantita);
		} else {
			prodotti.put(prodotto, quantita);
		}
	}
	

	public void rimuoviProdotto(CarrelloProdottoBean prodotto) {
		prodotti.remove(prodotto);
	}
	

    public int getQuantita(CarrelloProdottoBean prodotto) {
        return prodotti.getOrDefault(prodotto, 0);
    }


    public LinkedHashMap<CarrelloProdottoBean, Integer> getProdotti() {
        return prodotti;
    }
    
    public void diminuisciQuantitaProdotto(CarrelloProdottoBean prodotto, int quantita) {
        if (prodotti.containsKey(prodotto)) {
            int quantitaAttuale = prodotti.get(prodotto);
            if (quantitaAttuale > quantita) {
                prodotti.put(prodotto, quantitaAttuale - quantita);
            } else {
                prodotti.remove(prodotto);
            }
        }
    }
    
    public BigDecimal calcolaPrezzoTotale() {
        BigDecimal prezzoTotale = BigDecimal.ZERO.setScale(2);

        for (CarrelloProdottoBean prodotto : prodotti.keySet()) {

            int quantita = prodotti.get(prodotto);

            BigDecimal costoProdotto;

            if (prodotto instanceof CarrelloProdottoInOffertaBean) {
                CarrelloProdottoInOffertaBean prodottoInOfferta = (CarrelloProdottoInOffertaBean) prodotto;
                costoProdotto = prodottoInOfferta.getPrezzoScontato().multiply(BigDecimal.valueOf(quantita));
            } else {
                costoProdotto = prodotto.getPrezzoTaglia().multiply(BigDecimal.valueOf(quantita));
            }
            prezzoTotale = prezzoTotale.add(costoProdotto);
        }

        return prezzoTotale.setScale(2);
    }
    
    public BigDecimal calcolaPrezzoTotaleCarrello() {
    	BigDecimal prezzoProdotti = BigDecimal.ZERO.setScale(2);
    	BigDecimal totale = BigDecimal.ZERO.setScale(2);
    	BigDecimal costoSpedizione = BigDecimal.ZERO.setScale(2);
    	
    	prezzoProdotti = this.calcolaPrezzoTotale();
    	costoSpedizione = this.calcolaCostoSpedizione();
    	totale = prezzoProdotti.add(costoSpedizione);
    	return totale.setScale(2);
    }
    
    public BigDecimal calcolaCostoSpedizione() {
        BigDecimal sogliaSpedizioneGratuita = new BigDecimal("30.00");
        BigDecimal costoSpedizioneStandard = new BigDecimal("4.99");
        BigDecimal zero = BigDecimal.ZERO.setScale(2);

        if (this.calcolaPrezzoTotale().compareTo(sogliaSpedizioneGratuita) >= 0) {
            return zero;
        }
        return costoSpedizioneStandard;
    }
    
    public boolean isEmpty() {
    	
    	if(this.prodotti.isEmpty()) {
    		return true;
    	}
    	return false;
    }
    
    public void setProdottoFirst(CarrelloProdottoBean prodotto, int quantita) {
    	
    	LinkedHashMap<CarrelloProdottoBean, Integer> prodottiTemp = new LinkedHashMap<CarrelloProdottoBean, Integer>();
    	prodottiTemp.put(prodotto, quantita);
    	prodottiTemp.putAll(this.prodotti);
    	
        this.prodotti = prodottiTemp;
    }
    
    public void setProdottoLast(CarrelloProdottoBean prodotto, int quantita) {
        this.prodotti.put(prodotto, quantita);
    }
    
    public CarrelloBean orderBy(LinkedHashMap<List<Integer>, Integer> prodottiGuest) {

    	CarrelloBean prodottiOrdinati = new CarrelloBean();
    	LinkedHashMap<CarrelloProdottoBean, Integer> prodotti = this.getProdotti(); 
    	 
    	for (Map.Entry<List<Integer>, Integer> entry : prodottiGuest.entrySet()) {
    	    List<Integer> chiaveGuest = entry.getKey();
    	    
    	    for (Map.Entry<CarrelloProdottoBean, Integer> prodottoEntry : prodotti.entrySet()) {
    	        CarrelloProdottoBean chiaveProdotto = prodottoEntry.getKey();
    	        
    	        if (chiaveProdotto.getIdProdotto() == chiaveGuest.get(0) && 
    	            chiaveProdotto.getIdTaglia() == chiaveGuest.get(1)) {
    	        	
    	            prodottiOrdinati.setProdottoLast(chiaveProdotto, entry.getValue());
    	            break; 
    	        }
    	    }
    	}
    return prodottiOrdinati;
    }
	
}

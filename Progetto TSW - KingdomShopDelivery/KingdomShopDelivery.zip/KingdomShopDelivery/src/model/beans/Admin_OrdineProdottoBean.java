package model.beans;

import java.io.InputStream;
import java.io.Serializable;

public class Admin_OrdineProdottoBean implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private int id_prodotto;
	private int id_taglia;
	private String nome;
	private String marca;
	private String nome_taglia;
	private int quantita_acquistata;
	
	//Costruttore vuoto
	public Admin_OrdineProdottoBean() {
		this.id_prodotto = -1;
		this.id_taglia = -1;
		this.nome = "";
		this.marca = "";
		this.nome_taglia = "";
	}

}

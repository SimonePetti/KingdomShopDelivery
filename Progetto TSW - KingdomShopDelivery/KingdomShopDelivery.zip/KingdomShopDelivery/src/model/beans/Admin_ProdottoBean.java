package model.beans;

import java.io.ByteArrayInputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.math.BigDecimal;

public class Admin_ProdottoBean {
	
private static final long serialVersionUID = 1L; 

	private int id;
	private String nome;
	private String marca;
	private InputStream immagine;
	
	//Costruttore vuoto
	public Admin_ProdottoBean() {
		this.id = -1;
		this.nome = "";
		this.marca = "";
		this.immagine = null;
	}

	public int getId() {
		return this.id;
	}
	
	public void setId(int id) {
		this.id = id;
	}
	
	public String getNome() {
		return this.nome;
	}
	
	public void setNome(String nome) {
		this.nome = nome;
	}
	
	public String getMarca() {
		return this.marca;
	}
	
	public void setMarca(String marca) {
		this.marca = marca;
	}
	
	public InputStream getImmagine() {
		return this.immagine;
	}
	
	public void setImmagine(InputStream immagine) {
		this.immagine = immagine;
	}

	public void setImageFromByteArray(byte[] imageData) {
        this.immagine = new ByteArrayInputStream(imageData);
    }

    public void setImageFromFile(String filePath) throws FileNotFoundException {
        this.immagine = new FileInputStream(filePath); 
    }
}

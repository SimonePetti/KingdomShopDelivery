package model.beans;

import model.beans.OrdineDettagliBean;
import java.util.LinkedList;

import java.time.LocalDate;

public class UtenteDettagliBean extends UtenteBean {

	private static final long serialVersionUID = 1L;
	
	private String nome;
	private String cognome;
	private int prefisso_telefonico;
	private long numero_telefono;
	private LocalDate data_registrazione;
	private LinkedList<OrdineDettagliBean> ordini;

	//Costruttore vuoto
	public UtenteDettagliBean() {
		super();
		this.nome = "";
		this.cognome = "";
		this.prefisso_telefonico = 0;
		this.numero_telefono = 0;
		this.data_registrazione = null;
		this.ordini = new LinkedList<OrdineDettagliBean>();
	}
	
	public String getNome() {
		return this.nome;
	}
	
	public void setNome(String nome) {
		this.nome = nome;
	}
	
	public String getCognome() {
		return this.cognome;
	}
	
	public void setCognome(String cognome) {
		this.cognome = cognome;
	}
	
	public int getPrefissoTelefonico() {
		return this.prefisso_telefonico;
	}
	
	public void setPrefissoTelefonico(int prefisso_telefonico) {
		this.prefisso_telefonico = prefisso_telefonico;
	}
	
	public long getNumeroTelefono() {
		return this.numero_telefono;
	}
	
	public void setNumeroTelefono(long numero_telefono) {
		this.numero_telefono = numero_telefono;
	}
	
	public LocalDate getDataRegistrazione() {
		return this.data_registrazione;
	}
	
	public void setDataRegistrazione(LocalDate data_registrazione) {
		this.data_registrazione = data_registrazione;
	}
	
	public LinkedList<OrdineDettagliBean> getOrdini() {
		return this.ordini;
	}
	
	public void setOrdini(LinkedList<OrdineDettagliBean> ordini) {
		this.ordini = ordini;
	}
	
}

package model.beans;

import java.math.BigDecimal;
import java.math.RoundingMode;

public class ProdottoInOffertaBean extends ProdottoBean {
	
	private static final long serialVersionUID = 1L;
	
	private BigDecimal prezzoIniziale;
	private BigDecimal percentualeSconto;
	
	//Costruttore vuoto
	public ProdottoInOffertaBean() {
		super();
		this.prezzoIniziale = BigDecimal.ZERO.setScale(2);
		this.percentualeSconto = BigDecimal.ZERO.setScale(2);
	}
	
	public BigDecimal getPrezzoIniziale() {
		return this.prezzoIniziale;
	}
	
	public void setPrezzoIniziale(BigDecimal prezzoIniziale) {
		this.prezzoIniziale = prezzoIniziale;
	}
	
	public BigDecimal getPercentualeSconto() {
		return this.percentualeSconto;
	}
	
	public void setPercentualeSconto(BigDecimal percentualeSconto) {
		this.percentualeSconto = percentualeSconto;
	}

	public BigDecimal getPrezzoScontato() {
		BigDecimal sconto = this.prezzoIniziale.multiply(this.percentualeSconto).divide(BigDecimal.valueOf(100)).setScale(2, RoundingMode.HALF_UP);
		return this.prezzoIniziale.subtract(sconto).setScale(2);
	}
}

package model.beans;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.LinkedList;

public class Admin_OrdineBean implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private int numero_ordine;
	private LocalDate data_acquisto;
	private LocalDate data_consegna;
	private BigDecimal totale_ordine;
	private BigDecimal iva_totale;
	
	//Costruttore vuoto
	public Admin_OrdineBean() {
		this.numero_ordine = -1;
		this.data_acquisto = null;
		this.data_consegna = null;
		this.totale_ordine = BigDecimal.ZERO.setScale(2);
		this.iva_totale = BigDecimal.ZERO.setScale(2);
	}
	
	public int getNumeroOrdine() {
		return this.numero_ordine;
	}
	
	public void setNumeroOrdine(int numero_ordine) {
		this.numero_ordine = numero_ordine;
	} 
	
	public LocalDate getDataAcquisto() {
		return this.data_acquisto;
	}
	
	public void setDataAcquisto(LocalDate data_acquisto) {
		this.data_acquisto = data_acquisto;
	}
	
	public LocalDate getDataConsegna() {
		return this.data_consegna;
	}
	
	public void setDataConsegna(LocalDate data_consegna) {
		this.data_consegna = data_consegna;
	}
	
	public BigDecimal getTotaleOrdine() {
		return this.totale_ordine;
	}
	
	public void setTotaleOrdine(BigDecimal totale_ordine) {
		this.totale_ordine = totale_ordine;
	}
	
	public void aggiungiAlTotale(BigDecimal importo) {
		this.totale_ordine = this.totale_ordine.add(importo);
	}

	public BigDecimal getIvaTotaleOrdine() {
		return this.iva_totale;
	}
	
	public void setIvaTotaleOrdine(BigDecimal iva_totale) {
		this.iva_totale = iva_totale;
	}
	
	public void aggiungiAllIvaTotale(BigDecimal importo) {
		this.iva_totale = this.iva_totale.add(importo);
	}
	
}

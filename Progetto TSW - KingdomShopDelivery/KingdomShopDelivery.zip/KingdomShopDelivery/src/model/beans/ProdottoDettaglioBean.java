package model.beans;

import java.math.BigDecimal;
import java.util.List;
import java.util.ArrayList;

public class ProdottoDettaglioBean extends ProdottoBean {
	
	private static final long serialVersionUID = 1L;
	
	private String descrizione;
	private BigDecimal iva;
	private List<ProdottoTagliaBean> taglie;
	
	//Costruttore vuoto
	public ProdottoDettaglioBean() {
		super();
		this.descrizione = "";
		this.iva = BigDecimal.ZERO.setScale(2);
		this.taglie = new ArrayList<>();
	}
	
	public String getDescrizione() {
        return this.descrizione;
    }

    public void setDescrizione(String descrizione) {
        this.descrizione = descrizione;
    }

    public BigDecimal getIva() {
        return this.iva;
    }

    public void setIva(BigDecimal iva) {
        this.iva = iva;
    }

    public List<ProdottoTagliaBean> getTaglie() {
        return this.taglie;
    }
    
    public void setTaglie(ProdottoTagliaBean taglia) {
        this.taglie.add(taglia);
    }

    public void setTaglie(List<ProdottoTagliaBean> taglie) {
        this.taglie.addAll(taglie);
    }
}

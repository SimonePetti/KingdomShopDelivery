package model.beans;

import java.math.BigDecimal;
import java.util.LinkedList;

public class Admin_OrdineDettagliBean extends Admin_OrdineBean {
	
	private static final long serialVersionUID = 1L;
	
	private LinkedList<Admin_OrdineProdottoDettagliBean> prodotti;
	
	private String nome_cliente;
	private String cognome_cliente;
	private String paese_cliente;
	private String provincia_cliente;
	private String citta_cliente;
	private String via_cliente;
	private String cap_cliente;
	private String civico_cliente;
	private String note_spedizione;
	
	private String fattura_nome_cliente;
	private String fattura_cognome_cliente;
	private String fattura_paese_cliente;
	private String fattura_provincia_cliente;
	private String fattura_citta_cliente;
	private String fattura_via_cliente;
	private String fattura_cap_cliente;
	private String fattura_civico_cliente;
	
	//Costruttore vuoto
	public Admin_OrdineDettagliBean() {
		super();
		this.prodotti = new LinkedList<Admin_OrdineProdottoDettagliBean>();
		this.nome_cliente = "";
		this.cognome_cliente = "";
		this.paese_cliente = "";
		this.provincia_cliente = "";
		this.citta_cliente = "";
		this.via_cliente = "";
		this.cap_cliente = "";
		this.civico_cliente = "";
		this.note_spedizione = "";
	}
	
	public LinkedList<Admin_OrdineProdottoDettagliBean> getProdotti() {
		return this.prodotti;
	}
	
	public void setProdotti(LinkedList<Admin_OrdineProdottoDettagliBean> prodotti) {
		this.prodotti = prodotti;
	}
	
	public void setProdotto(Admin_OrdineProdottoDettagliBean prodotto) {
		this.prodotti.add(prodotto);
	}
	
	public String getNomeCliente() {
        return this.nome_cliente;
    }

    public void setNomeCliente(String nome_cliente) {
        this.nome_cliente = nome_cliente;
    }

    public String getCognomeCliente() {
        return cognome_cliente;
    }

    public void setCognomeCliente(String cognome_cliente) {
        this.cognome_cliente = cognome_cliente;
    }

    public String getPaeseCliente() {
        return this.paese_cliente;
    }

    public void setPaeseCliente(String paese_cliente) {
        this.paese_cliente = paese_cliente;
    }

    public String getProvinciaCliente() {
        return this.provincia_cliente;
    }

    public void setProvinciaCliente(String provincia_cliente) {
        this.provincia_cliente = provincia_cliente;
    }

    public String getCittaCliente() {
        return this.citta_cliente;
    }

    public void setCittaCliente(String citta_cliente) {
        this.citta_cliente = citta_cliente;
    }

    public String getViaCliente() {
        return this.via_cliente;
    }

    public void setViaCliente(String via_cliente) {
        this.via_cliente = via_cliente;
    }

    public String getCapCliente() {
        return this.cap_cliente;
    }

    public void setCapCliente(String cap_cliente) {
        this.cap_cliente = cap_cliente;
    }

    public String getCivicoCliente() {
        return civico_cliente;
    }

    public void setCivicoCliente(String civico_cliente) {
        this.civico_cliente = civico_cliente;
    }

    public String getNoteSpedizione() {
        return note_spedizione;
    }

    public void setNoteSpedizione(String note_spedizione) {
        this.note_spedizione = note_spedizione;
    }
    
    public String getFatturaNomeCliente() {
        return fattura_nome_cliente;
    }

    public void setFatturaNomeCliente(String fattura_nome_cliente) {
        this.fattura_nome_cliente = fattura_nome_cliente;
    }

    public String getFatturaCognomeCliente() {
        return fattura_cognome_cliente;
    }

    public void setFatturaCognomeCliente(String fattura_cognome_cliente) {
        this.fattura_cognome_cliente = fattura_cognome_cliente;
    }

    public String getFatturaPaeseCliente() {
        return fattura_paese_cliente;
    }

    public void setFatturaPaeseCliente(String fattura_paese_cliente) {
        this.fattura_paese_cliente = fattura_paese_cliente;
    }

    public String getFatturaProvinciaCliente() {
        return fattura_provincia_cliente;
    }

    public void setFatturaProvinciaCliente(String fattura_provincia_cliente) {
        this.fattura_provincia_cliente = fattura_provincia_cliente;
    }

    public String getFatturaCittaCliente() {
        return fattura_citta_cliente;
    }

    public void setFatturaCittaCliente(String fattura_citta_cliente) {
        this.fattura_citta_cliente = fattura_citta_cliente;
    }

    public String getFatturaViaCliente() {
        return fattura_via_cliente;
    }

    public void setFatturaViaCliente(String fattura_via_cliente) {
        this.fattura_via_cliente = fattura_via_cliente;
    }

    public String getFatturaCapCliente() {
        return fattura_cap_cliente;
    }

    public void setFatturaCapCliente(String fattura_cap_cliente) {
        this.fattura_cap_cliente = fattura_cap_cliente;
    }

    public String getFatturaCivicoCliente() {
        return fattura_civico_cliente;
    }

    public void setFatturaCivicoCliente(String fattura_civico_cliente) {
        this.fattura_civico_cliente = fattura_civico_cliente;
    }
    
    public BigDecimal calcolaCostoSpedizione() {
        BigDecimal sogliaSpedizioneGratuita = new BigDecimal("30.00");
        BigDecimal costoSpedizioneStandard = new BigDecimal("4.99");
        BigDecimal zero = BigDecimal.ZERO.setScale(2);

        if (this.getTotaleOrdine().compareTo(sogliaSpedizioneGratuita) >= 0) {
            return zero;
        }
        return costoSpedizioneStandard;
    }
    
    public BigDecimal calcolaPrezzoTotaleOrdine() {
    	BigDecimal prezzoProdotti = BigDecimal.ZERO.setScale(2);
    	BigDecimal totale = BigDecimal.ZERO.setScale(2);
    	BigDecimal costoSpedizione = BigDecimal.ZERO.setScale(2);
    	
    	prezzoProdotti = this.getTotaleOrdine();
    	costoSpedizione = this.calcolaCostoSpedizione();
    	totale = prezzoProdotti.add(costoSpedizione);
    	return totale.setScale(2);
    }

}

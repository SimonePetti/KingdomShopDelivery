package model.beans;

import java.io.Serializable;
import java.math.BigDecimal;
import java.io.ByteArrayInputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;

//Potresti prendere in considerazione il fatto di ereditare ProdottoBean

public class CarrelloProdottoBean implements Serializable {

	private static final long serialVersionUID = 1L;
	
	// Informazioni sul prodotto
    private int idProdotto;
    private String marcaProdotto;
    private String nomeProdotto;
    private InputStream immagine;
    private BigDecimal iva;

    // Informazioni sulla taglia
    private int idTaglia;
    private String nomeTaglia;
    private BigDecimal prezzoTaglia;
    private int quantitaDisponibileTaglia;

    // Costruttore vuoto
    public CarrelloProdottoBean() {
        this.idProdotto = -1;
        this.nomeProdotto = "";
        this.marcaProdotto = "";
        this.immagine = null;
        this.iva = BigDecimal.ZERO.setScale(2);
        this.idTaglia = -1;
        this.nomeTaglia = "";
        this.prezzoTaglia = BigDecimal.ZERO.setScale(2);
        this.quantitaDisponibileTaglia = 0;
    }

    public int getIdProdotto() {
        return this.idProdotto;
    }

    public void setIdProdotto(int prodottoId) {
        this.idProdotto = prodottoId;
    }
    
    public String getMarcaProdotto() {
        return this.marcaProdotto;
    }

    public void setMarcaProdotto(String prodottoMarca) {
        this.marcaProdotto = prodottoMarca;
    }

    public String getNomeProdotto() {
        return nomeProdotto;
    }

    public void setNomeProdotto(String nomeProdotto) {
        this.nomeProdotto = nomeProdotto;
    }

    public InputStream getImmagine() {
        return immagine;
    }
    
  	public void setImageFromByteArray(byte[] imageData) {
          this.immagine = new ByteArrayInputStream(imageData);
      }
  	
    public void setImageFromFile(String filePath) throws FileNotFoundException {
         this.immagine = new FileInputStream(filePath); 
    }
      
    public void setImmagine(InputStream immagineProdotto) {
        this.immagine = immagineProdotto;
    }

    public BigDecimal getIva() {
        return iva;
    }

    public void setIva(BigDecimal iva) {
        this.iva = iva;
    }

    public int getIdTaglia() {
        return idTaglia;
    }

    public void setIdTaglia(int tagliaId) {
        this.idTaglia = tagliaId;
    }

    public String getNomeTaglia() {
        return nomeTaglia;
    }

    public void setNomeTaglia(String nomeTaglia) {
        this.nomeTaglia = nomeTaglia;
    }

    public BigDecimal getPrezzoTaglia() {
        return prezzoTaglia;
    }

    public void setPrezzoTaglia(BigDecimal prezzoTaglia) {
        this.prezzoTaglia = prezzoTaglia;
    }

    public int getQuantitaDisponibileTaglia() {
        return quantitaDisponibileTaglia;
    }

    public void setQuantitaDisponibileTaglia(int quantita) {
        this.quantitaDisponibileTaglia = quantita;
    }

}

package model.beans;

import java.io.Serializable;
import java.util.LinkedList;
import java.util.List;

public class WishListBean implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private LinkedList<ProdottoBean> prodottiWishlist;
	
	public WishListBean() {
		this.prodottiWishlist = new LinkedList<ProdottoBean>();
	}
	
	public List<ProdottoBean> getProdotti() {
        return this.prodottiWishlist;
    }

    public void setProdotto(ProdottoBean prodotto) {
        this.prodottiWishlist.add(prodotto);
    }
    
    public void setProdottoFirst(ProdottoBean prodotto) {
        this.prodottiWishlist.addFirst(prodotto);
    }
    
    public void setProdottoLast(ProdottoBean prodotto) {
        this.prodottiWishlist.addLast(prodotto);
    }

    public void setProdotti(List<ProdottoBean> prodotti) {
        this.prodottiWishlist.addAll(prodotti);
    }
    
    public boolean isProdottoPresente(int idProdotto) {
    	for(ProdottoBean prodotto : prodottiWishlist) {
    		if(prodotto.getId() == idProdotto) {
    			return true;
    		}
    	}
    	return false;
    }
    
    public boolean isEmpty() {
    	
    	if(this.prodottiWishlist.isEmpty()) {
    		return true;
    	}
    	return false;
    }
    
    public WishListBean orderBy(LinkedList<Integer> prodottiGuest) {
    	
    	WishListBean prodottiOrdinati = new WishListBean();
    	List<ProdottoBean> prodotti = this.getProdotti();
    	
    	for(Integer id : prodottiGuest) {
    		for(ProdottoBean prodotto : prodotti) {
    			if(id == prodotto.getId()) {
    				prodottiOrdinati.setProdottoLast(prodotto);
    				break;
    			}
    		}
    	}
    	return prodottiOrdinati;
    }
	
}

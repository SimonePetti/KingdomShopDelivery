package model.beans;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDate;

public class Admin_ProdottoTagliaDaModificareBean implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private int id_taglia;
	private String nome_taglia;
	private BigDecimal prezzo_base_taglia;
	private int quantita_disponibile;
	
	//Costruttore vuoto
	public Admin_ProdottoTagliaDaModificareBean() {
		this.id_taglia = -1;
		this.nome_taglia = "";
		this.prezzo_base_taglia = BigDecimal.ZERO.setScale(2);
		this.quantita_disponibile = -1;
	}
	
	public int getIdTaglia() {
        return id_taglia;
    }

    public void setIdTaglia(int id_taglia) {
        this.id_taglia = id_taglia;
    }

    public String getNomeTaglia() {
        return nome_taglia;
    }

    public void setNomeTaglia(String nome_taglia) {
        this.nome_taglia = nome_taglia;
    }

    public BigDecimal getPrezzoTaglia() {
        return prezzo_base_taglia;
    }

    public void setPrezzoTaglia(BigDecimal prezzo) {
        this.prezzo_base_taglia = prezzo;
    }

    public int getQuantitaDisponibile() {
        return quantita_disponibile;
    }

    public void setQuantitaDisponibile(int quantita_disponibile) {
        this.quantita_disponibile = quantita_disponibile;
    }
   
}

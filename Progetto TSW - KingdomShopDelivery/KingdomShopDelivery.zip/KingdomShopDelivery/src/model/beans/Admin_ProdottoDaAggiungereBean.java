package model.beans;

import java.util.LinkedList;

import model.beans.Admin_ProdottoDaModificareBean;

public class Admin_ProdottoDaAggiungereBean extends Admin_ProdottoDaModificareBean {
	
	private static final long serialVersionUID = 1L;
	
	//Costruttore vuoto
	public Admin_ProdottoDaAggiungereBean() {
		super();
	}
	
	public void aggiungiTaglia(Admin_ProdottoTagliaDaAggiungereBean taglia) {
		this.getTaglie().add(taglia);
	}
}

package model.beans;

import java.io.Serializable;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.io.InputStream;

public class CarrelloProdottoInOffertaBean extends CarrelloProdottoBean {

    private static final long serialVersionUID = 1L;

    private BigDecimal prezzoIniziale;
    private BigDecimal percentualeSconto;

    // Costruttore vuoto
    public CarrelloProdottoInOffertaBean() {
    	super();
        this.prezzoIniziale = BigDecimal.ZERO.setScale(2);
        this.percentualeSconto = BigDecimal.ZERO.setScale(2);
    }

    public BigDecimal getPrezzoIniziale() {
        return prezzoIniziale;
    }

    public void setPrezzoIniziale(BigDecimal prezzoIniziale) {
        this.prezzoIniziale = prezzoIniziale;
    }

    public BigDecimal getPercentualeSconto() {
        return percentualeSconto;
    }

    public void setPercentualeSconto(BigDecimal percentualeSconto) {
        this.percentualeSconto = percentualeSconto;
    }
    
    public BigDecimal getPrezzoScontato() {
    	return this.prezzoIniziale.multiply(new BigDecimal(100).subtract(percentualeSconto)).divide(new BigDecimal(100)).setScale(2,RoundingMode.HALF_UP);
    }
}


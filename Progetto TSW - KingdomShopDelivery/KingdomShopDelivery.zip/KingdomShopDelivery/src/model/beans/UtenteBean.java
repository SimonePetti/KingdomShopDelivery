package model.beans;

import java.io.Serializable;

public class UtenteBean implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private int id_utente;
	private String email;
	private String ruolo;
	
	//Costruttore vuoto
	public UtenteBean() {
		this.id_utente = -1;
		this.email = "";
		this.ruolo = "utente";
	}
	
	public int getIdUtente() {
		return this.id_utente;
	}
	
	public void setIdUtente(int id_utente) {
		this.id_utente = id_utente;
	}
	
	public String getEmailUtente() {
		return this.email;
	}
	
	public void setEmailUtente(String email) {
		this.email = email;
	}
	
	public String getRuoloUtente() {
		return this.ruolo;
	}
	
	public void setRuoloUtente(String ruolo) {
		this.ruolo = ruolo;
	}

}

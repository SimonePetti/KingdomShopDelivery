package model.beans;

import java.io.Serializable;

public class IndirizzoBean implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private int id_indirizzo;
	private String nome;
	private String cognome;
	private String paese;
	private String provincia;
	private String citta;
	private String via;
	private String cap;
	private String civico;
	private String tipo;
	
	//Costruttore vuoto
	public IndirizzoBean() {
		this.id_indirizzo = -1;
		this.nome = "";
		this.cognome = "";
		this.paese = "";
		this.provincia = "";
		this.citta = "";
		this.via = "";
		this.cap = "";
		this.civico = "";
		this.tipo = "";
	}
	
	public int getIdIndirizzo() {
		return this.id_indirizzo;
	}
	
	public void setIdIndirizzo(int id_indirizzo) {
		this.id_indirizzo = id_indirizzo;
	}
	
	public String getNome() {
        return this.nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCognome() {
        return cognome;
    }

    public void setCognome(String cognome) {
        this.cognome = cognome;
    }

    public String getPaese() {
        return this.paese;
    }

    public void setPaese(String paese) {
        this.paese = paese;
    }

    public String getProvincia() {
        return this.provincia;
    }

    public void setProvincia(String provincia) {
        this.provincia = provincia;
    }

    public String getCitta() {
        return this.citta;
    }

    public void setCitta(String citta) {
        this.citta = citta;
    }

    public String getVia() {
        return this.via;
    }

    public void setVia(String via) {
        this.via = via;
    }

    public String getCap() {
        return this.cap;
    }

    public void setCap(String cap) {
        this.cap = cap;
    }

    public String getCivico() {
        return civico;
    }

    public void setCivico(String civico) {
        this.civico = civico;
    }
    
    public String getTipo() {
    	return this.tipo;
    }
    
    public void setTipo(String tipo) {
    	this.tipo = tipo;
    }
	
}

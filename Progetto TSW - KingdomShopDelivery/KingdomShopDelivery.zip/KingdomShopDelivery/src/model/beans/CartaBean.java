package model.beans;

import java.io.Serializable;

import java.time.YearMonth;

public class CartaBean implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private int id_carta;
	private String nome_completo;
	private long numero_carta;
	private YearMonth scadenza;
	
	//Costruttore vuoto
	public CartaBean() {
		this.id_carta = -1;
		this.nome_completo = "";
		this.numero_carta = -1;
		this.scadenza = null;
	}
	
	public int getIdCarta() {
		return this.id_carta;
	}
	
	public void setIdCarta(int id_carta) {
		this.id_carta = id_carta;
	}
	
	public String getNomeCompleto() {
		return this.nome_completo;
	}
	
	public void setNomeCompleto(String nome_completo) {
		this.nome_completo = nome_completo;
	}
	
	public long getNumeroCarta() {
		return this.numero_carta;
	}
	
	public void setNumeroCarta(long numero_carta) {
		this.numero_carta = numero_carta;
	}
	
	public YearMonth getScadenza() {
		return this.scadenza;
	}
	
	public void setScadenza(YearMonth scadenza) {
		this.scadenza = scadenza;
	}
	

}

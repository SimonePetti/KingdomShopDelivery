package model.beans;

import java.io.Serializable;

public class ConfermaOrdineBean implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private int id_indirizzoSpedizione;
	private int id_indirizzoFatturazione;
	private String tipoPagamento;
	private int id_cartaPagamento;
	private String note_spedizione;
	
	//Costruttore vuoto
	public ConfermaOrdineBean() {
		this.id_indirizzoSpedizione = -1;
		this.id_indirizzoFatturazione = -1;
		this.tipoPagamento = "";
		this.id_cartaPagamento = -1;
		this.note_spedizione = "";
	}
	
	public int getIdIndirizzoSpedizione() {
        return id_indirizzoSpedizione;
    }

    public void setIdIndirizzoSpedizione(int id_indirizzoSpedizione) {
        this.id_indirizzoSpedizione = id_indirizzoSpedizione;
    }

    public int getIdIndirizzoFatturazione() {
        return id_indirizzoFatturazione;
    }

    public void setIdIndirizzoFatturazione(int id_indirizzoFatturazione) {
        this.id_indirizzoFatturazione = id_indirizzoFatturazione;
    }

    public String getTipoPagamento() {
        return tipoPagamento;
    }

    public void setTipoPagamento(String tipoPagamento) {
        this.tipoPagamento = tipoPagamento;
    }

    public int getIdCartaPagamento() {
        return id_cartaPagamento;
    }

    public void setIdCartaPagamento(int idCartaPagamento) {
        this.id_cartaPagamento = idCartaPagamento;
    }
    
    public String getNoteSpedizione() {
        return note_spedizione;
    }

    public void setNoteSpedizione(String note_spedizione) {
        this.note_spedizione = note_spedizione;
    }

}

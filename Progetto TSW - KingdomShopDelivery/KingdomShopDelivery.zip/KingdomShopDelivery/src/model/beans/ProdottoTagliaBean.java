package model.beans;

import java.io.Serializable;
import java.math.BigDecimal;

public class ProdottoTagliaBean implements Serializable{ //senza estendere ProdottoBean
	
	private static final long serialVersionUID = 1L;
	
	private int idTaglia;
	private String nomeTaglia;
	private int quantitaDisponibile;
	private BigDecimal prezzoTaglia;

	//Costruttore vuoto
	public ProdottoTagliaBean() {
		this.idTaglia = -1;
		this.nomeTaglia = "";
		this.quantitaDisponibile = -1;
		this.prezzoTaglia = BigDecimal.ZERO.setScale(2);
	}
	
	public int getIdTaglia() {
        return this.idTaglia;
    }

    public void setIdTaglia(int idTaglia) {
        this.idTaglia = idTaglia;
    }

    public String getNomeTaglia() {
        return this.nomeTaglia;
    }

    public void setNomeTaglia(String nomeTaglia) {
        this.nomeTaglia = nomeTaglia;
    }

    public int getQuantitaDisponibile() {
        return this.quantitaDisponibile;
    }

    public void setQuantitaDisponibile(int quantitaDisponibile) {
        this.quantitaDisponibile = quantitaDisponibile;
    }
    
    public BigDecimal getPrezzoTaglia() {
        return this.prezzoTaglia.setScale(2);
    }

    public void setPrezzoTaglia(BigDecimal prezzoTaglia) {
        this.prezzoTaglia = prezzoTaglia;
    }
    
}

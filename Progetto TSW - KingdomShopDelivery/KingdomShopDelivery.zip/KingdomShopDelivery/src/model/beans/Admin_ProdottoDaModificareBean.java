package model.beans;

import java.io.ByteArrayInputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.LinkedList;

public class Admin_ProdottoDaModificareBean implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private int id_prodotto;
	private String nome_prodotto;
	private String marca;
	private String descrizione;
	private String categoria;
	private String sotto_categoria;
	private BigDecimal iva;
	private InputStream immagine;
	private BigDecimal percentuale_sconto;
	private LocalDate data_inizio;
	private LocalDate data_fine;
	private LinkedList<Admin_ProdottoTagliaDaModificareBean> taglie;
	
	//Costruttore vuoto
	public Admin_ProdottoDaModificareBean() {
		this.id_prodotto = -1;
		this.nome_prodotto = "";
		this.marca = "";
		this.descrizione = "";
		this.categoria = "";
		this.sotto_categoria = "";
		this.iva = BigDecimal.ZERO.setScale(2);
		this.immagine = null;
		this.percentuale_sconto = null;
		this.data_inizio = null;
		this.data_fine = null;
		this.taglie = new LinkedList<Admin_ProdottoTagliaDaModificareBean>();
	}
	
	public int getIdProdotto() {
        return id_prodotto;
    }

    public void setIdProdotto(int id_prodotto) {
        this.id_prodotto = id_prodotto;
    }

    public String getNomeProdotto() {
        return nome_prodotto;
    }

    public void setNomeProdotto(String nome) {
        this.nome_prodotto = nome;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getDescrizione() {
        return descrizione;
    }

    public void setDescrizione(String descrizione) {
        this.descrizione = descrizione;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    public String getSottoCategoria() {
        return sotto_categoria;
    }

    public void setSottoCategoria(String sotto_categoria) {
        this.sotto_categoria = sotto_categoria;
    }

    public BigDecimal getIva() {
        return iva;
    }

    public void setIva(BigDecimal iva) {
        this.iva = iva;
    }

    public InputStream getImmagine() {
		return this.immagine;
	}
	
	public void setImmagine(InputStream immagine) {
		this.immagine = immagine;
	}

	public void setImageFromByteArray(byte[] imageData) {
        this.immagine = new ByteArrayInputStream(imageData);
    }

    public void setImageFromFile(String filePath) throws FileNotFoundException {
        this.immagine = new FileInputStream(filePath); 
    }
    
    public BigDecimal getPercentualeSconto() {
    	return this.percentuale_sconto;
    }
    
    public void setPercentualeSconto(BigDecimal percentuale_sconto) {
    	this.percentuale_sconto = percentuale_sconto;
    }

    public LinkedList<Admin_ProdottoTagliaDaModificareBean> getTaglie() {
        return taglie;
    }

    public LocalDate getDataInizio() {
    	return this.data_inizio;
    }
    
    public void setDataInizio(LocalDate data_inizio) {
    	this.data_inizio = data_inizio;
    }
    
    public LocalDate getDataFine() {
    	return this.data_fine;
    }
    
    public void setDataFine(LocalDate data_fine) {
    	this.data_fine = data_fine;
    }
    
    public void setTaglie(LinkedList<Admin_ProdottoTagliaDaModificareBean> taglie) {
        this.taglie = taglie;
    }
	
    public void aggiungiTaglia(Admin_ProdottoTagliaDaModificareBean taglia) {
		this.taglie.add(taglia);
	}
}

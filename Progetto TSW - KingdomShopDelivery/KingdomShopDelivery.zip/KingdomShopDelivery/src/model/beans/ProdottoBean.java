package model.beans;

import java.io.Serializable;
import java.math.BigDecimal;
import java.io.FileInputStream;
import java.io.ByteArrayInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
//
public class ProdottoBean implements Serializable { 
	
	private static final long serialVersionUID = 1L;
	
	private int id;
	private String nome;
	private String marca;
	private InputStream immagine; 
	private BigDecimal prezzoMinimo;
	
	//Costruttore vuoto
	public ProdottoBean() {
		this.id = -1;
		this.nome = "";
		this.marca = "";
		this.immagine = null;
		this.prezzoMinimo = BigDecimal.ZERO.setScale(2); 
	}

	public int getId() {
		return this.id;
	}
	
	public void setId(int id) {
		this.id = id;
	}
	
	public String getNome() {
		return this.nome;
	}
	
	public void setNome(String nome) {
		this.nome = nome;
	}
	
	public String getMarca() {
		return this.marca;
	}
	
	public void setMarca(String marca) {
		this.marca = marca;
	}
	
	public InputStream getImmagine() {
		return this.immagine;
	}
	
	public void setImmagine(InputStream immagine) {
		this.immagine = immagine;
	}

	public void setImageFromByteArray(byte[] imageData) {
        this.immagine = new ByteArrayInputStream(imageData);
    }

    public void setImageFromFile(String filePath) throws FileNotFoundException {
        this.immagine = new FileInputStream(filePath); 
    }
	
	public BigDecimal getPrezzoMinimo() {
		return this.prezzoMinimo;
	}
	
	public void setPrezzoMinimo(BigDecimal prezzoMinimo) {
		this.prezzoMinimo = prezzoMinimo;
	}
}

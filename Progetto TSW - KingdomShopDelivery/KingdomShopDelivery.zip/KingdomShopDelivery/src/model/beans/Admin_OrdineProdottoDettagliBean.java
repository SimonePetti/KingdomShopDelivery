package model.beans;

import java.io.Serializable;
import java.math.BigDecimal;

public class Admin_OrdineProdottoDettagliBean implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private int id_prodotto;
	private int id_taglia;
	private String nome;
	private String marca;
	private String nome_taglia;
	private int quantita_acquistata;
	private BigDecimal prezzo_singolo;
	private BigDecimal iva;
	
	//Costruttore vuoto
	public Admin_OrdineProdottoDettagliBean() {
		this.id_prodotto = -1;
		this.id_taglia = -1;
		this.nome = "";
		this.marca = "";
		this.nome_taglia = "";
		this.quantita_acquistata = -1;
		this.prezzo_singolo = BigDecimal.ZERO.setScale(2);
		this.iva = BigDecimal.ZERO.setScale(2);
	}
	
	public int getIdProdotto() {
		return this.id_prodotto;
	}
		
	public void setIdProdotto(int id_prodotto) {
		this.id_prodotto = id_prodotto;
	}
	
	public int getIdTaglia() {
		return this.id_taglia;
	}
		
	public void setIdTaglia(int id_taglia) {
		this.id_taglia = id_taglia;
	}
		
	public String getNome() {
		return this.nome;
	}
		
	public void setNome(String nome) {
		this.nome = nome;
	}
		
	public String getMarca() {
		return this.marca;
	}
		
	public void setMarca(String marca) {
		this.marca = marca;
	}
	
	public String getNomeTaglia() {
		return this.nome_taglia;
	}
		
	public void setNomeTaglia(String nome_taglia) {
		this.nome_taglia = nome_taglia;
	}
	
	public int getQuantitaAcquistata() {
        return quantita_acquistata;
    }

    public void setQuantitaAcquistata(int quantita_acquistata) {
        this.quantita_acquistata = quantita_acquistata;
    }

    public BigDecimal getPrezzoSingolo() {
        return prezzo_singolo;
    }

    public void setPrezzoSingolo(BigDecimal prezzo_singolo) {
        this.prezzo_singolo = prezzo_singolo;
    }

    public BigDecimal getIva() {
        return iva;
    }

    public void setIva(BigDecimal iva) {
        this.iva = iva;
    }

}

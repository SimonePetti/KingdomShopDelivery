package model.beans;

import java.io.ByteArrayInputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.io.Serializable;
import java.math.BigDecimal;

public class OrdineProdottoBean implements Serializable {

	private static final long serialVersionUID = 1L;

	private int id_prodotto;
	private int id_taglia;
	private String nome;
	private String marca;
	private String nome_taglia;
	private InputStream immagine;
		
	//Costruttore vuoto
	public OrdineProdottoBean() {
		this.id_prodotto = -1;
		this.id_taglia = -1;
		this.nome = "";
		this.marca = "";
		this.nome_taglia = "";
		this.immagine = null;
	}

	public int getIdProdotto() {
		return this.id_prodotto;
	}
		
	public void setIdProdotto(int id_prodotto) {
		this.id_prodotto = id_prodotto;
	}
	
	public int getIdTaglia() {
		return this.id_taglia;
	}
		
	public void setIdTaglia(int id_taglia) {
		this.id_taglia = id_taglia;
	}
		
	public String getNome() {
		return this.nome;
	}
		
	public void setNome(String nome) {
		this.nome = nome;
	}
		
	public String getMarca() {
		return this.marca;
	}
		
	public void setMarca(String marca) {
		this.marca = marca;
	}
	
	public String getNomeTaglia() {
		return this.nome_taglia;
	}
		
	public void setNomeTaglia(String nome_taglia) {
		this.nome_taglia = nome_taglia;
	}
	
	public InputStream getImmagine() {
		return this.immagine;
	}
		
	public void setImmagine(InputStream immagine) {
		this.immagine = immagine;
	}

	public void setImageFromByteArray(byte[] imageData) {
		this.immagine = new ByteArrayInputStream(imageData);
	}

	public void setImageFromFile(String filePath) throws FileNotFoundException {
		this.immagine = new FileInputStream(filePath); 
	}
}

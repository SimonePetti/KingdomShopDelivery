package model.beans;

import java.io.Serializable;
import java.time.LocalDate;

public class DatiPersonaliBean implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private int id_utente;
	private String nome;
	private String cognome;
	private int prefisso_telefonico;
	private long numero_telefono;
	private LocalDate data_iscrizione;
	private String email;
	
	//Costruttore vuoto
	public DatiPersonaliBean() {
		this.id_utente = -1;
		this.nome = "";
		this.cognome = "";
		this.prefisso_telefonico = -1;
		this.numero_telefono = -1;
		this.data_iscrizione = null;
		this.email = "";
	}
	
	public int getIdUtente() {
		return this.id_utente;
	}
	
	public void setIdUtente(int id_utente) {
		this.id_utente = id_utente;
	}
	
	public String getNome() {
		return this.nome;
	}
	
	public void setNome(String nome) {
		this.nome = nome;
	}
	
	public String getCognome() {
		return this.cognome;
	}
	
	public void setCognome(String cognome) {
		this.cognome = cognome;
	}
	
	public int getPrefissoTelefonico() {
		return this.prefisso_telefonico;
	}
	
	public void setPrefissoTelefonico(int prefisso_telefonico) {
		this.prefisso_telefonico = prefisso_telefonico;
	}
	
	public long getNumeroTelefono() {
		return this.numero_telefono;
	}
	
	public void setNumeroTelefono(long numero_telefono) {
		this.numero_telefono = numero_telefono;
	}
	
	public LocalDate getDataRegistrazione() {
		return this.data_iscrizione;
	}
	
	public void setDataRegistrazione(LocalDate data_iscrizione) {
		this.data_iscrizione = data_iscrizione;
	}
	
	public String getEmail() {
		return this.email;
	}
	
	public void setEmail(String email) {
		this.email = email;
	}

}

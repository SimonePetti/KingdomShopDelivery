package model.beans;

import java.io.InputStream;

import java.math.BigDecimal;

public class OrdineProdottoDettagliBean extends OrdineProdottoBean {
	
	private static final long serialVersionUID = 1L;
	
	private int quantita_acquistata;
	private BigDecimal prezzo_singolo;
	private BigDecimal iva;

	//Costruttore vuoto
	public OrdineProdottoDettagliBean() {
		super();
		this.quantita_acquistata = -1;
		this.prezzo_singolo = BigDecimal.ZERO.setScale(2);
		this.iva = BigDecimal.ZERO.setScale(2);
	}
	
	public int getQuantitaAcquistata() {
        return quantita_acquistata;
    }

    public void setQuantitaAcquistata(int quantita_acquistata) {
        this.quantita_acquistata = quantita_acquistata;
    }

    public BigDecimal getPrezzoSingolo() {
        return prezzo_singolo;
    }

    public void setPrezzoSingolo(BigDecimal prezzo_singolo) {
        this.prezzo_singolo = prezzo_singolo;
    }

    public BigDecimal getIva() {
        return iva;
    }

    public void setIva(BigDecimal iva) {
        this.iva = iva;
    }
   
}

package model.beans;

import java.time.LocalDate;

public class FatturaBean {
	
	private static final long serialVersionUID = 1L;
	
	private String nome_azienda;
	private String paese_azienda;
	private String provincia_azienda;
	private String citta_azienda;
	private String via_azienda;
	private String cap_azienda;
	private String partivaIva_azienda;
	
	private LocalDate data_emissione;
	private String metodo_pagamento;
	private String note;
	private String nome_cliente;
	private String cognome_cliente;
	private String paese_cliente;
	private String provincia_cliente;
	private String citta_cliente;
	private String via_cliente;
	private String civico_cliente;
	private String cap_cliente;
	
	public String getNomeAzienda() {
        return nome_azienda;
    }

    public void setNomeAzienda(String nome_azienda) {
        this.nome_azienda = nome_azienda;
    }

    public String getPaeseAzienda() {
        return paese_azienda;
    }

    public void setPaeseAzienda(String paese_azienda) {
        this.paese_azienda = paese_azienda;
    }

    public String getProvinciaAzienda() {
        return provincia_azienda;
    }

    public void setProvinciaAzienda(String provincia_azienda) {
        this.provincia_azienda = provincia_azienda;
    }

    public String getCittaAzienda() {
        return citta_azienda;
    }

    public void setCittaAzienda(String citta_azienda) {
        this.citta_azienda = citta_azienda;
    }

    public String getViaAzienda() {
        return via_azienda;
    }

    public void setViaAzienda(String via_azienda) {
        this.via_azienda = via_azienda;
    }

    public String getCapAzienda() {
        return cap_azienda;
    }

    public void setCapAzienda(String cap_azienda) {
        this.cap_azienda = cap_azienda;
    }

    public String getPartivaIvaAzienda() {
        return partivaIva_azienda;
    }

    public void setPartivaIvaAzienda(String partivaIva_azienda) {
        this.partivaIva_azienda = partivaIva_azienda;
    }
    
    public LocalDate getDataEmissione() {
        return data_emissione;
    }

    public void setDataEmissione(LocalDate data_emissione) {
        this.data_emissione = data_emissione;
    }

    public String getMetodoPagamento() {
        return metodo_pagamento;
    }

    public void setMetodoPagamento(String metodo_pagamento) {
        this.metodo_pagamento = metodo_pagamento;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }

    public String getNomeCliente() {
        return nome_cliente;
    }

    public void setNomeCliente(String nome_cliente) {
        this.nome_cliente = nome_cliente;
    }

    public String getCognomeCliente() {
        return cognome_cliente;
    }

    public void setCognomeCliente(String cognome_cliente) {
        this.cognome_cliente = cognome_cliente;
    }

    public String getPaeseCliente() {
        return paese_cliente;
    }

    public void setPaeseCliente(String paese_cliente) {
        this.paese_cliente = paese_cliente;
    }

    public String getProvinciaCliente() {
        return provincia_cliente;
    }

    public void setProvinciaCliente(String provincia_cliente) {
        this.provincia_cliente = provincia_cliente;
    }

    public String getCittaCliente() {
        return citta_cliente;
    }

    public void setCittaCliente(String citta_cliente) {
        this.citta_cliente = citta_cliente;
    }

    public String getViaCliente() {
        return via_cliente;
    }

    public void setViaCliente(String via_cliente) {
        this.via_cliente = via_cliente;
    }

    public String getCivicoCliente() {
        return civico_cliente;
    }

    public void setCivicoCliente(String civico_cliente) {
        this.civico_cliente = civico_cliente;
    }

    public String getCapCliente() {
        return cap_cliente;
    }

    public void setCapCliente(String cap_cliente) {
        this.cap_cliente = cap_cliente;
    }

}

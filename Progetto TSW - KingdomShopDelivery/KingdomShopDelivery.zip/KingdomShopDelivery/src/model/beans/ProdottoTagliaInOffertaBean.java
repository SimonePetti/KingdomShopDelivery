package model.beans;

import java.math.BigDecimal;
import java.math.RoundingMode;

public class ProdottoTagliaInOffertaBean extends ProdottoTagliaBean {
	
	private static final long serialVersionUID = 1L;
	
    private BigDecimal percentualeSconto;
    
  //Costruttore vuoto
  	public ProdottoTagliaInOffertaBean() {
  		super();
  		this.percentualeSconto = BigDecimal.ZERO.setScale(2);
  	}

    public BigDecimal getPercentualeSconto() {
        return this.percentualeSconto;
    }

    public void setPercentualeSconto(BigDecimal percentualeSconto) {
        this.percentualeSconto = percentualeSconto;
    }

    public BigDecimal getCalcolaPrezzoTaglia() {
        BigDecimal prezzoIniziale = this.getPrezzoTaglia();
        BigDecimal percentualeSconto = getPercentualeSconto();
        return prezzoIniziale != null && percentualeSconto != null 
        		? prezzoIniziale.subtract(prezzoIniziale.multiply(percentualeSconto.divide(new BigDecimal(100)).setScale(2,RoundingMode.HALF_UP)))
                : this.getPrezzoTaglia();
    }
}


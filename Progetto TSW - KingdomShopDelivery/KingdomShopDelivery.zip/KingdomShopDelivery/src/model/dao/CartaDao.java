package model.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.YearMonth;
import java.util.LinkedList;

import model.beans.CartaBean;
import model.dao.interfacce.CartaDaoInterfaccia;
import model.util.DriverManagerConnectionPool;


public class CartaDao implements CartaDaoInterfaccia {
	
	private static final String TABLE_Carta = "Carta";

	public LinkedList<CartaBean> getCarte(int id_utente) throws SQLException {
		
		Connection connection = null;
	    PreparedStatement preparedStatement = null;
	    LinkedList<CartaBean> carte = new LinkedList<CartaBean>();
	    
	    String selectSQL = "SELECT ID_Carta, NumeroCarta, DataScadenza, NomeCompletoIntestatario "
	    		         + "FROM " + TABLE_Carta + " "
	    		         + "WHERE Utente = ? "
	    		         + "ORDER BY ID_Carta DESC";
	    
	    try {
	        connection = DriverManagerConnectionPool.getConnection();
	        preparedStatement = connection.prepareStatement(selectSQL);
	        
	        preparedStatement.setInt(1, id_utente);
	        
	        ResultSet rs = preparedStatement.executeQuery();
	        
	        while(rs.next()) {
	        	CartaBean carta = new CartaBean();
	        	
	        	carta.setIdCarta(rs.getInt("ID_Carta"));
	        	carta.setNomeCompleto(rs.getString("NomeCompletoIntestatario"));
	        	carta.setNumeroCarta(rs.getLong("NumeroCarta") % 10000);
	        	carta.setScadenza(YearMonth.from(rs.getDate("DataScadenza").toLocalDate()));
	        	
	        	carte.add(carta);
	        }

	    } finally {
	        if (preparedStatement != null) {
	            preparedStatement.close();
	        }
	        if (connection != null) {
	            DriverManagerConnectionPool.releaseConnection(connection);
	        }
	    }
	    return carte;	
	}
	
	public synchronized String aggiungiCarta(int id_utente, CartaBean carta, int cvv) throws SQLException {
		
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		String messaggioRedirect;
		LocalDate dataScadenza = carta.getScadenza().atDay(1);
		
		String selectSQL = "SELECT NumeroCarta "
	   			  				   + "FROM " + TABLE_Carta + " "
	                               + "WHERE Utente = ? AND NumeroCarta = ?";
		
		try {
			connection = DriverManagerConnectionPool.getConnection();
			
			preparedStatement = connection.prepareStatement(selectSQL);
			
			preparedStatement.setInt(1, id_utente);
			preparedStatement.setLong(2, carta.getNumeroCarta());
			
			ResultSet rs = preparedStatement.executeQuery();
			
			if(rs.next()) {
				//La carta esiste
				messaggioRedirect="?inserimento=giaPresente";	
			} else {
				
				PreparedStatement preparedStatement1 = null;
				
				String insertSQL = "INSERT INTO " + TABLE_Carta + "(Utente,NumeroCarta,DataScadenza,CVV,NomeCompletoIntestatario) VALUES(?,?,?,?,?)";
				
				preparedStatement1 = connection.prepareStatement(insertSQL);
				
				preparedStatement1.setInt(1, id_utente);
				preparedStatement1.setLong(2, carta.getNumeroCarta());
	            preparedStatement1.setDate(3, Date.valueOf(dataScadenza));
	            preparedStatement1.setInt(4, cvv);
	            preparedStatement1.setString(5, carta.getNomeCompleto());
				
	            preparedStatement1.executeUpdate();				
				
				connection.commit();
				messaggioRedirect="?inserimento=successo";
			}

		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				DriverManagerConnectionPool.releaseConnection(connection);
			}
		}
		return messaggioRedirect;
	}
	
	public synchronized String modificaCarta(int id_utente, int id_carta, String nome_completo, YearMonth data_scadenza) throws SQLException {
		
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		String messaggioRedirect = "";
		LocalDate dataScadenza = data_scadenza.atDay(1);
		
		String selectSQL = "SELECT * FROM " + TABLE_Carta + " WHERE Utente = ? AND ID_Carta = ?";
		
		try {
			connection = DriverManagerConnectionPool.getConnection();
			
			preparedStatement = connection.prepareStatement(selectSQL);
			
			preparedStatement.setInt(1, id_utente);
			preparedStatement.setInt(2, id_carta);
			
			ResultSet rs = preparedStatement.executeQuery();
			
			if(rs.next()) {
				//La carta esiste
				
				PreparedStatement preparedStatement1 = null;
	            
				String updateSQL = "UPDATE " + TABLE_Carta + " "
						 		 + "SET DataScadenza = ?, NomeCompletoIntestatario = ? "
				                 + "WHERE Utente = ? AND ID_Carta = ?";
					
				preparedStatement1 = connection.prepareStatement(updateSQL);
					
				preparedStatement1.setDate(1, Date.valueOf(dataScadenza));
	            preparedStatement1.setString(2, nome_completo);
	            preparedStatement1.setInt(3, id_utente);
	            preparedStatement1.setLong(4, id_carta);
		            
		        preparedStatement1.executeUpdate();
		        connection.commit();
		        messaggioRedirect = "?modifica=successo";
				
			} else {
				messaggioRedirect="?modifica=cartaAssente";
			}

		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				DriverManagerConnectionPool.releaseConnection(connection);
			}
		}
		return messaggioRedirect;
	}
	
	public synchronized String eliminaCarta(int id_utente, int id_carta) throws SQLException {
		
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		String messaggioRedirect = "";

		String deleteSQL = "DELETE FROM " + TABLE_Carta + " WHERE Utente = ? AND ID_carta = ?";
		
		try {
			connection = DriverManagerConnectionPool.getConnection();
			
			preparedStatement = connection.prepareStatement(deleteSQL);
			
			preparedStatement.setInt(1, id_utente);
			preparedStatement.setInt(2, id_carta);
			
			preparedStatement.executeUpdate();
			messaggioRedirect = "?eliminazione=successo";

		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				DriverManagerConnectionPool.releaseConnection(connection);
			}
		}
		return messaggioRedirect;
	}
	
}

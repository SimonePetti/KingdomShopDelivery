package model.dao;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;

import model.beans.CarrelloProdottoBean;
import model.beans.CarrelloProdottoInOffertaBean;
import model.beans.ProdottoBean;
import model.beans.ProdottoInOffertaBean;
import model.dao.interfacce.EventoAggiornaDB_DaoInterfaccia;
import model.util.DriverManagerConnectionPool;


public class EventoAggiornaDB_Dao implements EventoAggiornaDB_DaoInterfaccia {
	
	private static final String TABLE_Prodotto = "Prodotto";
	private static final String TABLE_ProdottoTaglia = "Prodotto_Taglia";
	private static final String TABLE_Sconto = "Sconto";
	
	public void aggiornaScontoProdotto(int id_prodotto) throws SQLException {
		Connection connection = null;
	    PreparedStatement preparedStatement = null;
	    
	    String selectSQL = "SELECT * "
	    		         + "FROM " + TABLE_Prodotto + " p JOIN " + TABLE_Sconto + " s ON p.ID_Prodotto = s.Prodotto "
	    		         + "WHERE p.Cancellato = FALSE AND ID_Prodotto = ? AND s.DataInizio <= CURDATE() AND s.DataFine >= CURDATE()";
	    
	    try {
	        connection = DriverManagerConnectionPool.getConnection();
	        preparedStatement = connection.prepareStatement(selectSQL);
	        
	        preparedStatement.setInt(1, id_prodotto);
	        
	        ResultSet rs = preparedStatement.executeQuery();
	        
	        if(rs.next()) {
	        	BigDecimal prezzoMinimo = null;
	        	BigDecimal prezzoIniziale = null;
	        	BigDecimal percentualeSconto = rs.getBigDecimal("PercentualeSconto");
	        	
	        	String taglieSQL = "SELECT pt.Prezzo "
	        					 + "FROM " + TABLE_Prodotto + " p JOIN " + TABLE_ProdottoTaglia + " pt ON p.ID_Prodotto = pt.Prodotto "
	        					 + "WHERE p.ID_Prodotto = ? AND p.Cancellato = FALSE";
	        	
	        	PreparedStatement ps1 = connection.prepareStatement(taglieSQL);
	        	ps1.setInt(1, id_prodotto);
	        	ResultSet rs_taglie = ps1.executeQuery();
	        	
	        	while(rs_taglie.next()) {
	        		BigDecimal prezzo = rs_taglie.getBigDecimal("Prezzo").setScale(2);
	        		BigDecimal prezzoScontato = prezzo.subtract(prezzo.multiply(percentualeSconto.divide(new BigDecimal("100")))).setScale(2,RoundingMode.HALF_UP);
	        		
	        		if(prezzoMinimo == null || prezzoScontato.compareTo(prezzoMinimo) < 0) {
	        			prezzoMinimo = prezzoScontato;
	        			prezzoIniziale = prezzo;
	        		}
	        	}
	        	
	        	if(prezzoMinimo != null && prezzoIniziale != null) {
	        		String updateSQL = "UPDATE " + TABLE_Prodotto + " "
	        						 + "SET PrezzoMinimo = ?, PrezzoMinimoEScontato = TRUE, PrezzoInizialePrezzoMinimo = ? "
	        						 + "WHERE ID_Prodotto = ? AND Cancellato = FALSE";

	        		PreparedStatement ps2 = connection.prepareStatement(updateSQL);
	        		ps2.setBigDecimal(1, prezzoMinimo);
	        		ps2.setBigDecimal(2, prezzoIniziale);
	        		ps2.setInt(3, id_prodotto);
	        		
	        		ps2.executeUpdate();
	        		connection.commit();
	        	}
	        }

	    } finally {
	        if (preparedStatement != null) {
	            preparedStatement.close();
	        }
	        if (connection != null) {
	            DriverManagerConnectionPool.releaseConnection(connection);
	        }
	    }
	}
	
	public void eliminaScontoProdotto(int id_prodotto) throws SQLException {
		Connection connection = null;
	    PreparedStatement preparedStatement = null;
	    
	    String selectSQL = "SELECT * "
	    		         + "FROM " + TABLE_Prodotto + " p JOIN " + TABLE_Sconto + " s ON p.ID_Prodotto = s.Prodotto "
	    		         + "WHERE p.Cancellato = FALSE AND ID_Prodotto = ? AND s.DataFine < CURDATE()";
	    
	    try {
	        connection = DriverManagerConnectionPool.getConnection();
	        preparedStatement = connection.prepareStatement(selectSQL);
	        
	        preparedStatement.setInt(1, id_prodotto);
	        
	        ResultSet rs = preparedStatement.executeQuery();
	        
	        if(rs.next()) {
	        	BigDecimal prezzoMinimo = null;

	        	String taglieSQL = "SELECT pt.Prezzo "
	        					 + "FROM " + TABLE_Prodotto + " p JOIN " + TABLE_ProdottoTaglia + " pt ON p.ID_Prodotto = pt.Prodotto "
	        					 + "WHERE p.ID_Prodotto = ? AND p.Cancellato = FALSE";
	        	
	        	PreparedStatement ps1 = connection.prepareStatement(taglieSQL);
	        	ps1.setInt(1, id_prodotto);
	        	ResultSet rs_taglie = ps1.executeQuery();
	        	
	        	while(rs_taglie.next()) {
	        		BigDecimal prezzo = rs_taglie.getBigDecimal("Prezzo").setScale(2);
	        		
	        		if(prezzoMinimo == null || prezzo.compareTo(prezzoMinimo) < 0) {
	        			prezzoMinimo = prezzo;
	        		}
	        	}
	        	
	        	if(prezzoMinimo != null) {
	        		String updateSQL = "UPDATE " + TABLE_Prodotto + " "
	        						 + "SET PrezzoMinimo = ?, PrezzoMinimoEScontato = FALSE, PrezzoInizialePrezzoMinimo = 0 "
	        						 + "WHERE ID_Prodotto = ? AND Cancellato = FALSE";

	        		PreparedStatement ps2 = connection.prepareStatement(updateSQL);
	        		ps2.setBigDecimal(1, prezzoMinimo);
	        		ps2.setInt(2, id_prodotto);
	        		
	        		ps2.executeUpdate();
	        		
	        		String deleteSQL = "DELETE FROM " + TABLE_Sconto + " WHERE Prodotto = ?";
	        		PreparedStatement ps3 = connection.prepareStatement(deleteSQL);
	        		ps3.setInt(1, id_prodotto);
	        		
	        		ps3.executeUpdate();
	        		connection.commit();
	        	}
	        }
	        
	    } catch (SQLException e) {

	        if (connection != null) {
	            try {
	                connection.rollback();
	            } catch (SQLException rollbackEx) {
	                rollbackEx.printStackTrace();
	            }
	        }
	        throw e;
	    } finally {
	        if (preparedStatement != null) {
	            preparedStatement.close();
	        }
	        if (connection != null) {
	            DriverManagerConnectionPool.releaseConnection(connection);
	        }
	    }
	}
	
	public void eliminaScontoScadutoProdotto(int id_prodotto) throws SQLException {
		Connection connection = null;
	    PreparedStatement preparedStatement = null;
	    
	    String selectSQL = "SELECT * "
	    		         + "FROM " + TABLE_Prodotto + " p JOIN " + TABLE_Sconto + " s ON p.ID_Prodotto = s.Prodotto "
	    		         + "WHERE p.Cancellato = FALSE AND ID_Prodotto = ?";
	    
	    try {
	        connection = DriverManagerConnectionPool.getConnection();
	        preparedStatement = connection.prepareStatement(selectSQL);
	        
	        preparedStatement.setInt(1, id_prodotto);
	        
	        ResultSet rs = preparedStatement.executeQuery();
	        
	        if(rs.next()) {
	        	BigDecimal prezzoMinimo = null;

	        	String taglieSQL = "SELECT pt.Prezzo "
	        					 + "FROM " + TABLE_Prodotto + " p JOIN " + TABLE_ProdottoTaglia + " pt ON p.ID_Prodotto = pt.Prodotto "
	        					 + "WHERE p.ID_Prodotto = ? AND p.Cancellato = FALSE";
	        	
	        	PreparedStatement ps1 = connection.prepareStatement(taglieSQL);
	        	ps1.setInt(1, id_prodotto);
	        	ResultSet rs_taglie = ps1.executeQuery();
	        	
	        	while(rs_taglie.next()) {
	        		BigDecimal prezzo = rs_taglie.getBigDecimal("Prezzo").setScale(2);
	        		
	        		if(prezzoMinimo == null || prezzo.compareTo(prezzoMinimo) < 0) {
	        			prezzoMinimo = prezzo;
	        		}
	        	}
	        	
	        	if(prezzoMinimo != null) {
	        		String updateSQL = "UPDATE " + TABLE_Prodotto + " "
	        						 + "SET PrezzoMinimo = ?, PrezzoMinimoEScontato = FALSE, PrezzoInizialePrezzoMinimo = 0 "
	        						 + "WHERE ID_Prodotto = ? AND Cancellato = FALSE";

	        		PreparedStatement ps2 = connection.prepareStatement(updateSQL);
	        		ps2.setBigDecimal(1, prezzoMinimo);
	        		ps2.setInt(2, id_prodotto);
	        		
	        		ps2.executeUpdate();
	        		
	        		String deleteSQL = "DELETE FROM " + TABLE_Sconto + " WHERE Prodotto = ?";
	        		PreparedStatement ps3 = connection.prepareStatement(deleteSQL);
	        		ps3.setInt(1, id_prodotto);
	        		
	        		ps3.executeUpdate();
	        		connection.commit();
	        	}
	        }
	        
	    } catch (SQLException e) {

	        if (connection != null) {
	            try {
	                connection.rollback();
	            } catch (SQLException rollbackEx) {
	                rollbackEx.printStackTrace();
	            }
	        }
	        throw e;
	    } finally {
	        if (preparedStatement != null) {
	            preparedStatement.close();
	        }
	        if (connection != null) {
	            DriverManagerConnectionPool.releaseConnection(connection);
	        }
	    }
	}
	
	public void aggiornaPrezzoMinimoProdotto(int id_prodotto) throws SQLException {
		Connection connection = null;
	    PreparedStatement preparedStatement = null;
	    
	    String selectSQL = "SELECT * "
	    		         + "FROM " + TABLE_Prodotto + " p "
	    		         + "WHERE p.Cancellato = FALSE AND ID_Prodotto = ?";
	    
	    try {
	        connection = DriverManagerConnectionPool.getConnection();
	        preparedStatement = connection.prepareStatement(selectSQL);
	        
	        preparedStatement.setInt(1, id_prodotto);
	        
	        ResultSet rs = preparedStatement.executeQuery();
	        
	        if(rs.next()) {
	        	BigDecimal prezzoMinimo = null;
	        	
	        	String taglieSQL = "SELECT pt.Prezzo "
	        					 + "FROM " + TABLE_Prodotto + " p JOIN " + TABLE_ProdottoTaglia + " pt ON p.ID_Prodotto = pt.Prodotto "
	        					 + "WHERE p.ID_Prodotto = ? AND p.Cancellato = FALSE";
	        	
	        	PreparedStatement ps1 = connection.prepareStatement(taglieSQL);
	        	ps1.setInt(1, id_prodotto);
	        	ResultSet rs_taglie = ps1.executeQuery();
	        	
	        	while(rs_taglie.next()) {
	        		BigDecimal prezzo = rs_taglie.getBigDecimal("Prezzo").setScale(2);
	        		
	        		if(prezzoMinimo == null || prezzo.compareTo(prezzoMinimo) < 0) {
	        			prezzoMinimo = prezzo;
	        		}
	        	}
	        	
	        	if(prezzoMinimo != null) {
	        		String updateSQL = "UPDATE " + TABLE_Prodotto + " "
	        						 + "SET PrezzoMinimo = ? "
	        						 + "WHERE ID_Prodotto = ? AND Cancellato = FALSE";

	        		PreparedStatement ps2 = connection.prepareStatement(updateSQL);
	        		ps2.setBigDecimal(1, prezzoMinimo);
	        		ps2.setInt(2, id_prodotto);
	        		
	        		ps2.executeUpdate();
	        		connection.commit();
	        	}
	        }

	    } finally {
	        if (preparedStatement != null) {
	            preparedStatement.close();
	        }
	        if (connection != null) {
	            DriverManagerConnectionPool.releaseConnection(connection);
	        }
	    }
	}
	
	public synchronized ProdottoInOffertaBean getProdottoInOffertaBeanAggiornato(int id_prodotto) throws SQLException {
		aggiornaScontoProdotto(id_prodotto);
		
		Connection connection = null;
	    PreparedStatement preparedStatement = null;
	    ProdottoInOffertaBean prodotto = new ProdottoInOffertaBean();
	    
	    String selectSQL = "SELECT * "
	    		         + "FROM " + TABLE_Prodotto + " "
	    		         + "WHERE Cancellato = FALSE AND ID_Prodotto = ?";
	    
	    try {
	        connection = DriverManagerConnectionPool.getConnection();
	        preparedStatement = connection.prepareStatement(selectSQL);
	        
	        preparedStatement.setInt(1, id_prodotto);
	        
	        ResultSet rs = preparedStatement.executeQuery();
	        
	        if(rs.next()) {
	        	prodotto.setId(rs.getInt("ID_prodotto"));
	            prodotto.setNome(rs.getString("Nome"));
	            prodotto.setMarca(rs.getString("Marca"));
	            byte[] Immagine = rs.getBytes("Immagine");
	            if(Immagine != null) {
	            	prodotto.setImageFromByteArray(Immagine);
	            }
	            prodotto.setPrezzoMinimo(rs.getBigDecimal("PrezzoMinimo"));
	            prodotto.setPrezzoIniziale(rs.getBigDecimal("PrezzoInizialePrezzoMinimo"));
	            prodotto.setPercentualeSconto(rs.getBigDecimal("PercentualeSconto"));
	        }

	    } finally {
	        if (preparedStatement != null) {
	            preparedStatement.close();
	        }
	        if (connection != null) {
	            DriverManagerConnectionPool.releaseConnection(connection);
	        }
	    }
	    return prodotto;
	}
	
	public synchronized ProdottoBean getProdottoBeanAggiornato(int id_prodotto) throws SQLException {
		eliminaScontoProdotto(id_prodotto);
		
		Connection connection = null;
	    PreparedStatement preparedStatement = null;
	    ProdottoInOffertaBean prodotto = new ProdottoInOffertaBean();
	    
	    String selectSQL = "SELECT * "
	    		         + "FROM " + TABLE_Prodotto + " "
	    		         + "WHERE Cancellato = FALSE AND ID_Prodotto = ?";
	    
	    try {
	        connection = DriverManagerConnectionPool.getConnection();
	        preparedStatement = connection.prepareStatement(selectSQL);
	        
	        preparedStatement.setInt(1, id_prodotto);
	        
	        ResultSet rs = preparedStatement.executeQuery();
	        
	        if(rs.next()) {
	        	prodotto.setId(rs.getInt("ID_prodotto"));
	            prodotto.setNome(rs.getString("Nome"));
	            prodotto.setMarca(rs.getString("Marca"));
	            byte[] Immagine = rs.getBytes("Immagine");
	            if(Immagine != null) {
	            	prodotto.setImageFromByteArray(Immagine);
	            }
	            prodotto.setPrezzoMinimo(rs.getBigDecimal("PrezzoMinimo"));
	        }

	    } finally {
	        if (preparedStatement != null) {
	            preparedStatement.close();
	        }
	        if (connection != null) {
	            DriverManagerConnectionPool.releaseConnection(connection);
	        }
	    }
	    return prodotto;
	}
	
	public BigDecimal getPercentualeScontoAggiornata(int id_prodotto) throws SQLException {
		aggiornaScontoProdotto(id_prodotto);
		
		Connection connection = null;
	    PreparedStatement preparedStatement = null;
	    BigDecimal percentuale_aggiornata = new BigDecimal(0);
	    
	    String selectSQL = "SELECT s.PercentualeSconto "
	    		         + "FROM " + TABLE_Prodotto + " p JOIN " + TABLE_Sconto + " s ON p.ID_Prodotto = s.Prodotto "
	    		         + "WHERE p.Cancellato = FALSE AND p.ID_Prodotto = ?";
	    
	    try {
	        connection = DriverManagerConnectionPool.getConnection();
	        preparedStatement = connection.prepareStatement(selectSQL);
	        
	        preparedStatement.setInt(1, id_prodotto);
	        
	        ResultSet rs = preparedStatement.executeQuery();
	        
	        if(rs.next()) {
	        	percentuale_aggiornata = rs.getBigDecimal("PercentualeSconto");
	        }

	    } finally {
	        if (preparedStatement != null) {
	            preparedStatement.close();
	        }
	        if (connection != null) {
	            DriverManagerConnectionPool.releaseConnection(connection);
	        }
	    }
	   return percentuale_aggiornata;
	}
	
	public synchronized CarrelloProdottoInOffertaBean getCarrelloProdottoInOffertaBeanAggiornato(int id_prodotto) throws SQLException {
		aggiornaScontoProdotto(id_prodotto);
		
		Connection connection = null;
	    PreparedStatement preparedStatement = null;
	    CarrelloProdottoInOffertaBean prodotto = new CarrelloProdottoInOffertaBean();
	    
	    String selectSQL = "SELECT * "
		         + "FROM " + TABLE_Prodotto + " p JOIN " + TABLE_ProdottoTaglia + " pt ON p.ID_Prodotto = pt.Prodotto"
		         + "WHERE p.Cancellato = FALSE AND p.ID_Prodotto = ?";
	    
	    try {
	        connection = DriverManagerConnectionPool.getConnection();
	        preparedStatement = connection.prepareStatement(selectSQL);
	        
	        preparedStatement.setInt(1, id_prodotto);
	        
	        ResultSet rs = preparedStatement.executeQuery();
	        
	        if(rs.next()) {
	        	
	        	prodotto.setIdProdotto(rs.getInt("ID_prodotto"));
	            prodotto.setNomeProdotto(rs.getString("Nome"));
	            prodotto.setMarcaProdotto(rs.getString("Marca"));
	            byte[] Immagine = rs.getBytes("Immagine");
	            if(Immagine != null) {
	            	prodotto.setImageFromByteArray(Immagine);
	            }
	            prodotto.setIva(rs.getBigDecimal("Iva"));
	    		prodotto.setIdTaglia(rs.getInt("ID_ProdottoTaglia"));
	    		prodotto.setNomeTaglia(rs.getString("NomeTaglia"));
	    		prodotto.setPrezzoIniziale(rs.getBigDecimal("Prezzo"));
	    		prodotto.setPercentualeSconto(rs.getBigDecimal("PercentualeSconto"));
	    		prodotto.setQuantitaDisponibileTaglia(rs.getInt("QuantitaDisponibile"));
	        }

	    } finally {
	        if (preparedStatement != null) {
	            preparedStatement.close();
	        }
	        if (connection != null) {
	            DriverManagerConnectionPool.releaseConnection(connection);
	        }
	    }
	    return prodotto;
	}
	
	public synchronized CarrelloProdottoBean getCarrelloProdottoBeanAggiornato(int id_prodotto) throws SQLException {
		eliminaScontoProdotto(id_prodotto);
		
		Connection connection = null;
	    PreparedStatement preparedStatement = null;
	    CarrelloProdottoInOffertaBean prodotto = new CarrelloProdottoInOffertaBean();
	    
	    String selectSQL = "SELECT * "
	    		         + "FROM " + TABLE_Prodotto + " p JOIN " + TABLE_ProdottoTaglia + " pt ON p.ID_Prodotto = pt.Prodotto "
	    		         + "WHERE Cancellato = FALSE AND ID_Prodotto = ?";
	    
	    try {
	        connection = DriverManagerConnectionPool.getConnection();
	        preparedStatement = connection.prepareStatement(selectSQL);
	        
	        preparedStatement.setInt(1, id_prodotto);
	        
	        ResultSet rs = preparedStatement.executeQuery();
	        
	        if(rs.next()) {
	    		
	        	prodotto.setIdProdotto(rs.getInt("ID_prodotto"));
	            prodotto.setNomeProdotto(rs.getString("Nome"));
	            prodotto.setMarcaProdotto(rs.getString("Marca"));
	            byte[] Immagine = rs.getBytes("Immagine");
	            if(Immagine != null) {
	            	prodotto.setImageFromByteArray(Immagine);
	            }
	            prodotto.setIva(rs.getBigDecimal("Iva"));
	    		prodotto.setIdTaglia(rs.getInt("ID_ProdottoTaglia"));
	    		prodotto.setNomeTaglia(rs.getString("NomeTaglia"));
	    		prodotto.setPrezzoTaglia(rs.getBigDecimal("Prezzo"));
	    		prodotto.setQuantitaDisponibileTaglia(rs.getInt("QuantitaDisponibile"));
	        }

	    } finally {
	        if (preparedStatement != null) {
	            preparedStatement.close();
	        }
	        if (connection != null) {
	            DriverManagerConnectionPool.releaseConnection(connection);
	        }
	    }
	    return prodotto;
	}
	
	public synchronized LocalDate getDataInizioAggiornata(int id_prodotto) throws SQLException {
		Connection connection = null;
	    PreparedStatement preparedStatement = null;
	    LocalDate dataInizio_aggiornata = null;
	    
	    String selectSQL = "SELECT s.DataInizio "
	    		         + "FROM " + TABLE_Prodotto + " p JOIN " + TABLE_Sconto + " s ON p.ID_Prodotto = s.Prodotto "
	    		         + "WHERE p.Cancellato = FALSE AND p.ID_Prodotto = ?";
	    
	    try {
	        connection = DriverManagerConnectionPool.getConnection();
	        preparedStatement = connection.prepareStatement(selectSQL);
	        
	        preparedStatement.setInt(1, id_prodotto);
	        
	        ResultSet rs = preparedStatement.executeQuery();
	        
	        if(rs.next()) {
	        	dataInizio_aggiornata = rs.getDate("DataInizio").toLocalDate();
	        }

	    } finally {
	        if (preparedStatement != null) {
	            preparedStatement.close();
	        }
	        if (connection != null) {
	            DriverManagerConnectionPool.releaseConnection(connection);
	        }
	    }
	   return dataInizio_aggiornata;
	}
	
	public synchronized LocalDate getDataFineAggiornata(int id_prodotto) throws SQLException {
		Connection connection = null;
	    PreparedStatement preparedStatement = null;
	    LocalDate dataFine_aggiornata = null;
	    
	    String selectSQL = "SELECT s.DataFine "
	    		         + "FROM " + TABLE_Prodotto + " p JOIN " + TABLE_Sconto + " s ON p.ID_Prodotto = s.Prodotto "
	    		         + "WHERE p.Cancellato = FALSE AND p.ID_Prodotto = ?";
	    
	    try {
	        connection = DriverManagerConnectionPool.getConnection();
	        preparedStatement = connection.prepareStatement(selectSQL);
	        
	        preparedStatement.setInt(1, id_prodotto);
	        
	        ResultSet rs = preparedStatement.executeQuery();
	        
	        if(rs.next()) {
	        	dataFine_aggiornata = rs.getDate("DataInizio").toLocalDate();
	        }

	    } finally {
	        if (preparedStatement != null) {
	            preparedStatement.close();
	        }
	        if (connection != null) {
	            DriverManagerConnectionPool.releaseConnection(connection);
	        }
	    }
	   return dataFine_aggiornata;
	}

}

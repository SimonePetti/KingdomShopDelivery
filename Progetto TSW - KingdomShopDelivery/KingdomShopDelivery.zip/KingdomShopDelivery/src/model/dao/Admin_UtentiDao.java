package model.dao;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;
import java.util.ArrayList;
import java.util.LinkedList;

import model.beans.OrdineDettagliBean;
import model.beans.OrdineProdottoDettagliBean;
import model.beans.UtenteBean;
import model.beans.UtenteDettagliBean;
import model.dao.interfacce.Admin_UtentiDaoInterfaccia;
import model.util.DriverManagerConnectionPool;


public class Admin_UtentiDao implements Admin_UtentiDaoInterfaccia {
	
	private static final String TABLE_Utente = "Utente";
	private static final String TABLE_Prodotto = "Prodotto";
	private static final String TABLE_ProdottoTaglia = "Prodotto_Taglia";
	private static final String TABLE_Sconto = "Sconto";
	private static final String TABLE_Acquisto = "Acquisto";
	private static final String TABLE_AcquistoDettagli = "Acquisto_Dettaglio";
	private static final String TABLE_Fattura = "Fattura";
	
	public synchronized int getNumeroUtentiTotali() throws SQLException {
		
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		int numero_utenti = 0;
		
		String selectSQL = "SELECT COUNT(*) AS NumeroUtenti "
						 + "FROM " + TABLE_Utente;
		
		try {
			connection = DriverManagerConnectionPool.getConnection();
			
			preparedStatement = connection.prepareStatement(selectSQL);
			
			ResultSet rs = preparedStatement.executeQuery();
			
			if(rs.next()) {
				numero_utenti = rs.getInt("NumeroUtenti");
			}

		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				DriverManagerConnectionPool.releaseConnection(connection);
			}
		}
		return numero_utenti;
	}
	
	public synchronized int getNumeroUtentiNuovi() throws SQLException {
		
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		int numero_utenti = 0;
		
		String selectSQL = "SELECT COUNT(*) AS NumeroUtentiUltimi30Giorni "
						 + "FROM " + TABLE_Utente + " "
						 + "WHERE DataRegistrazione >= DATE_SUB(NOW(), INTERVAL 30 DAY)";
		
		try {
			connection = DriverManagerConnectionPool.getConnection();
			
			preparedStatement = connection.prepareStatement(selectSQL);
			
			ResultSet rs = preparedStatement.executeQuery();
			
			if(rs.next()) {
				numero_utenti = rs.getInt("NumeroUtentiUltimi30Giorni");
			}

		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				DriverManagerConnectionPool.releaseConnection(connection);
			}
		}
		return numero_utenti;
	}
	
	public synchronized LinkedList<UtenteBean> getUtenti() throws SQLException {
		
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		LinkedList<UtenteBean> utenti = new LinkedList<UtenteBean>();
		
		String selectSQL = "SELECT ID_Utente, Email, Tipo "
						 + "FROM " + TABLE_Utente + " "
						 + "ORDER BY DataRegistrazione DESC";
		
		try {
			connection = DriverManagerConnectionPool.getConnection();
			
			preparedStatement = connection.prepareStatement(selectSQL);
			
			ResultSet rs = preparedStatement.executeQuery();
			
			while(rs.next()) {
				UtenteBean utente = new UtenteBean();
				utente.setIdUtente(rs.getInt("ID_Utente"));
				utente.setEmailUtente(rs.getString("Email"));
				utente.setRuoloUtente(rs.getString("Tipo"));
				utenti.add(utente);
			}

		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				DriverManagerConnectionPool.releaseConnection(connection);
			}
		}
		return utenti;
	}
	
	public synchronized UtenteDettagliBean getDettagliUtente(int id_utente) throws SQLException {
		
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		PreparedStatement preparedStatement1 = null;
		UtenteDettagliBean utente = new UtenteDettagliBean();

		String selectSQL = "SELECT ID_Utente, Nome, Cognome, Email, Tipo, PrefissoTelefono, NumeroTelefono, DataRegistrazione "
						 + "FROM " + TABLE_Utente + " "
						 + "WHERE ID_Utente = ?";
		
		String selectSQL1 = "SELECT a.ID_Acquisto, a.NomeCitofono, a.CognomeCitofono, a.Paese, a.Provincia, a.Citta, a.Via, a.CAP, a.Civico, a.DataAcquisto, a.DataConsegna, a.NoteSpedizione, ad.QuantitaAcquistata, ad.PrezzoSingolo, ad.Iva, pt.ID_ProdottoTaglia, pt.NomeTaglia, p.ID_Prodotto, p.Nome, p.Marca, p.Immagine, f.NomeCliente, f.CognomeCliente, f.PaeseCliente, f.ProvinciaCliente, f.CittaCliente, f.ViaCliente, f.CAPCliente, f.CivicoCliente "
						  + "FROM " + TABLE_Acquisto + " a JOIN " + TABLE_AcquistoDettagli + " ad ON a.ID_Acquisto = ad.Acquisto "
		 		          + "JOIN " + TABLE_Fattura + " f ON a.ID_Acquisto = f.Acquisto "
		 		          + "JOIN " + TABLE_ProdottoTaglia + " pt ON ad.ProdottoTaglia = pt.ID_ProdottoTaglia "
		 		          + "JOIN " + TABLE_Prodotto + " p ON pt.Prodotto = p.ID_Prodotto "
		                  + "WHERE a.Utente = ?";
		
		try {
			connection = DriverManagerConnectionPool.getConnection();
			
			preparedStatement = connection.prepareStatement(selectSQL);
			preparedStatement.setInt(1, id_utente);
			
			preparedStatement1 = connection.prepareStatement(selectSQL1);
			preparedStatement1.setInt(1, id_utente);
			
			ResultSet rs = preparedStatement.executeQuery();
			ResultSet rs1 = preparedStatement1.executeQuery();

			if(rs.next()) {
				utente.setIdUtente(rs.getInt("ID_Utente"));
				utente.setNome(rs.getString("Nome"));
				utente.setCognome(rs.getString("Cognome"));
				utente.setEmailUtente(rs.getString("Email"));
				utente.setRuoloUtente(rs.getString("Tipo"));
				utente.setPrefissoTelefonico(rs.getInt("PrefissoTelefono"));
				utente.setNumeroTelefono(rs.getLong("NumeroTelefono"));
				utente.setDataRegistrazione(rs.getDate("DataRegistrazione").toLocalDate());
			}
			
			LinkedList<OrdineDettagliBean> ordini = new LinkedList<OrdineDettagliBean>();
			OrdineDettagliBean ordineCorrente = null;
			int ultimoIdOrdine = -1;

			while (rs1.next()) {
			    int idOrdine = rs1.getInt("ID_Acquisto");

			    if (idOrdine != ultimoIdOrdine) {
			        ordineCorrente = new OrdineDettagliBean();
			        
			        ordineCorrente.setNumeroOrdine(idOrdine);
			        ordineCorrente.setDataAcquisto(rs1.getDate("DataAcquisto").toLocalDate());
			        LocalDate dataConsegna = (rs1.getDate("DataConsegna") != null) ? rs1.getDate("DataConsegna").toLocalDate() : null;
			        ordineCorrente.setDataConsegna(dataConsegna);

			        ordineCorrente.setNomeCliente(rs1.getString("NomeCitofono"));
			        ordineCorrente.setCognomeCliente(rs1.getString("CognomeCitofono"));
			        ordineCorrente.setPaeseCliente(rs1.getString("Paese"));
			        ordineCorrente.setProvinciaCliente(rs1.getString("Provincia"));
			        ordineCorrente.setCittaCliente(rs1.getString("Citta"));
			        ordineCorrente.setViaCliente(rs1.getString("Via"));
			        ordineCorrente.setCapCliente(rs1.getString("CAP"));
			        ordineCorrente.setCivicoCliente(rs1.getString("Civico"));
			        ordineCorrente.setNoteSpedizione(rs1.getString("NoteSpedizione"));

			        ordineCorrente.setFatturaNomeCliente(rs1.getString("NomeCliente"));
			        ordineCorrente.setFatturaCognomeCliente(rs1.getString("CognomeCliente"));
			        ordineCorrente.setFatturaPaeseCliente(rs1.getString("PaeseCliente"));
			        ordineCorrente.setFatturaProvinciaCliente(rs1.getString("ProvinciaCliente"));
			        ordineCorrente.setFatturaCittaCliente(rs1.getString("CittaCliente"));
			        ordineCorrente.setFatturaViaCliente(rs1.getString("ViaCliente"));
			        ordineCorrente.setFatturaCapCliente(rs1.getString("CAPCliente"));
			        ordineCorrente.setFatturaCivicoCliente(rs1.getString("CivicoCliente"));

			        ordini.add(ordineCorrente);
			        ultimoIdOrdine = idOrdine;
			    }

			    OrdineProdottoDettagliBean prodotto = new OrdineProdottoDettagliBean();
			    prodotto.setIdProdotto(rs1.getInt("ID_Prodotto"));
			    prodotto.setIdTaglia(rs1.getInt("ID_ProdottoTaglia"));
			    prodotto.setNome(rs1.getString("Nome"));
			    prodotto.setMarca(rs1.getString("Marca"));
			    prodotto.setNomeTaglia(rs1.getString("NomeTaglia"));
			    prodotto.setImmagine(rs1.getBinaryStream("Immagine"));
			    prodotto.setQuantitaAcquistata(rs1.getInt("QuantitaAcquistata"));
			    prodotto.setPrezzoSingolo(rs1.getBigDecimal("PrezzoSingolo"));
			    prodotto.setIva(rs1.getBigDecimal("Iva"));
			    
			    int quantita = rs1.getInt("QuantitaAcquistata");
			    BigDecimal prezzoSingolo = rs1.getBigDecimal("PrezzoSingolo");
			    BigDecimal totaleProdotto = prezzoSingolo.multiply(BigDecimal.valueOf(quantita));
			    
			    ordineCorrente.setProdotto(prodotto);
			    ordineCorrente.aggiungiAlTotale(totaleProdotto);
			}
			utente.setOrdini(ordini);

		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				DriverManagerConnectionPool.releaseConnection(connection);
			}
		}
		return utente;
	}
	
	public synchronized UtenteDettagliBean getDettagliUtente(int id_utente, LocalDate data_inizio, LocalDate data_fine) throws SQLException {
		
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		PreparedStatement preparedStatement1 = null;
		UtenteDettagliBean utente = new UtenteDettagliBean();
		String where = "";
		int n_ps = 0;
		
		if(data_inizio != null && data_fine != null) {
			where = " AND a.DataAcquisto >= ? AND a.DataAcquisto <= ? ";
			n_ps = 1;
		} else {
			if(data_inizio != null && data_fine == null) {
				where = " AND a.DataAcquisto >= ? ";
				n_ps = 2;
			} else {
				where = " AND a.DataAcquisto <= ? ";
				n_ps = 3;
			}
		}

		String selectSQL = "SELECT ID_Utente, Nome, Cognome, Email, Tipo, PrefissoTelefono, NumeroTelefono, DataRegistrazione "
						 + "FROM " + TABLE_Utente + " "
						 + "WHERE ID_Utente = ?";
		
		String selectSQL1 = "SELECT a.ID_Acquisto, a.NomeCitofono, a.CognomeCitofono, a.Paese, a.Provincia, a.Citta, a.Via, a.CAP, a.Civico, a.DataAcquisto, a.DataConsegna, a.NoteSpedizione, ad.QuantitaAcquistata, ad.PrezzoSingolo, ad.Iva, pt.ID_ProdottoTaglia, pt.NomeTaglia, p.ID_Prodotto, p.Nome, p.Marca, p.Immagine, f.NomeCliente, f.CognomeCliente, f.PaeseCliente, f.ProvinciaCliente, f.CittaCliente, f.ViaCliente, f.CAPCliente, f.CivicoCliente "
						  + "FROM " + TABLE_Acquisto + " a JOIN " + TABLE_AcquistoDettagli + " ad ON a.ID_Acquisto = ad.Acquisto "
		 		          + "JOIN " + TABLE_Fattura + " f ON a.ID_Acquisto = f.Acquisto "
		 		          + "JOIN " + TABLE_ProdottoTaglia + " pt ON ad.ProdottoTaglia = pt.ID_ProdottoTaglia "
		 		          + "JOIN " + TABLE_Prodotto + " p ON pt.Prodotto = p.ID_Prodotto "
		                  + "WHERE a.Utente = ?" + where;
		
		try {
			connection = DriverManagerConnectionPool.getConnection();
			
			preparedStatement = connection.prepareStatement(selectSQL);
			preparedStatement.setInt(1, id_utente);
			
			preparedStatement1 = connection.prepareStatement(selectSQL1);
			preparedStatement1.setInt(1, id_utente);
			
			switch(n_ps) {
			case 1: preparedStatement1.setDate(2, Date.valueOf(data_inizio)); preparedStatement1.setDate(3, Date.valueOf(data_fine)); break;
			case 2: preparedStatement1.setDate(2, Date.valueOf(data_inizio)); break;
			case 3: preparedStatement1.setDate(2, Date.valueOf(data_fine)); break;
			}
			
			ResultSet rs = preparedStatement.executeQuery();
			ResultSet rs1 = preparedStatement1.executeQuery();

			if(rs.next()) {
				utente.setIdUtente(rs.getInt("ID_Utente"));
				utente.setNome(rs.getString("Nome"));
				utente.setCognome(rs.getString("Cognome"));
				utente.setEmailUtente(rs.getString("Email"));
				utente.setRuoloUtente(rs.getString("Tipo"));
				utente.setPrefissoTelefonico(rs.getInt("PrefissoTelefono"));
				utente.setNumeroTelefono(rs.getLong("NumeroTelefono"));
				utente.setDataRegistrazione(rs.getDate("DataRegistrazione").toLocalDate());
			}
			
			LinkedList<OrdineDettagliBean> ordini = new LinkedList<OrdineDettagliBean>();
			OrdineDettagliBean ordineCorrente = null;
			int ultimoIdOrdine = -1;

			while (rs1.next()) {
			    int idOrdine = rs1.getInt("ID_Acquisto");

			    if (idOrdine != ultimoIdOrdine) {
			        ordineCorrente = new OrdineDettagliBean();
			        
			        ordineCorrente.setNumeroOrdine(idOrdine);
			        ordineCorrente.setDataAcquisto(rs1.getDate("DataAcquisto").toLocalDate());
			        LocalDate dataConsegna = (rs1.getDate("DataConsegna") != null) ? rs1.getDate("DataConsegna").toLocalDate() : null;
			        ordineCorrente.setDataConsegna(dataConsegna);

			        ordineCorrente.setNomeCliente(rs1.getString("NomeCitofono"));
			        ordineCorrente.setCognomeCliente(rs1.getString("CognomeCitofono"));
			        ordineCorrente.setPaeseCliente(rs1.getString("Paese"));
			        ordineCorrente.setProvinciaCliente(rs1.getString("Provincia"));
			        ordineCorrente.setCittaCliente(rs1.getString("Citta"));
			        ordineCorrente.setViaCliente(rs1.getString("Via"));
			        ordineCorrente.setCapCliente(rs1.getString("CAP"));
			        ordineCorrente.setCivicoCliente(rs1.getString("Civico"));
			        ordineCorrente.setNoteSpedizione(rs1.getString("NoteSpedizione"));

			        ordineCorrente.setFatturaNomeCliente(rs1.getString("NomeCliente"));
			        ordineCorrente.setFatturaCognomeCliente(rs1.getString("CognomeCliente"));
			        ordineCorrente.setFatturaPaeseCliente(rs1.getString("PaeseCliente"));
			        ordineCorrente.setFatturaProvinciaCliente(rs1.getString("ProvinciaCliente"));
			        ordineCorrente.setFatturaCittaCliente(rs1.getString("CittaCliente"));
			        ordineCorrente.setFatturaViaCliente(rs1.getString("ViaCliente"));
			        ordineCorrente.setFatturaCapCliente(rs1.getString("CAPCliente"));
			        ordineCorrente.setFatturaCivicoCliente(rs1.getString("CivicoCliente"));

			        ordini.add(ordineCorrente);
			        ultimoIdOrdine = idOrdine;
			    }

			    OrdineProdottoDettagliBean prodotto = new OrdineProdottoDettagliBean();
			    prodotto.setIdProdotto(rs1.getInt("ID_Prodotto"));
			    prodotto.setIdTaglia(rs1.getInt("ID_ProdottoTaglia"));
			    prodotto.setNome(rs1.getString("Nome"));
			    prodotto.setMarca(rs1.getString("Marca"));
			    prodotto.setNomeTaglia(rs1.getString("NomeTaglia"));
			    prodotto.setImmagine(rs1.getBinaryStream("Immagine"));
			    prodotto.setQuantitaAcquistata(rs1.getInt("QuantitaAcquistata"));
			    prodotto.setPrezzoSingolo(rs1.getBigDecimal("PrezzoSingolo"));
			    prodotto.setIva(rs1.getBigDecimal("Iva"));
			    
			    int quantita = rs1.getInt("QuantitaAcquistata");
			    BigDecimal prezzoSingolo = rs1.getBigDecimal("PrezzoSingolo");
			    BigDecimal totaleProdotto = prezzoSingolo.multiply(BigDecimal.valueOf(quantita));
			    
			    ordineCorrente.setProdotto(prodotto);
			    ordineCorrente.aggiungiAlTotale(totaleProdotto);
			}
			utente.setOrdini(ordini);

		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				DriverManagerConnectionPool.releaseConnection(connection);
			}
		}
		return utente;
	}
	
	public void modificaRuolo(int id_utente, String ruolo) throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		
		String updateSQL = "UPDATE " + TABLE_Utente + " SET Tipo = ? WHERE ID_Utente = ?";
		
		try {
			connection = DriverManagerConnectionPool.getConnection();
			
			preparedStatement = connection.prepareStatement(updateSQL);
			preparedStatement.setString(1, ruolo);
			preparedStatement.setInt(2, id_utente);
			
			preparedStatement.executeUpdate();
			
			connection.commit();

		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				DriverManagerConnectionPool.releaseConnection(connection);
			}
		}
	}

}

package model.dao;

import java.security.Timestamp;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Time;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.YearMonth;
import java.util.LinkedList;

import model.beans.CartaBean;
import model.beans.FatturaBean;
import model.dao.interfacce.FatturaDaoInterfaccia;
import model.util.DriverManagerConnectionPool;


public class FatturaDao implements FatturaDaoInterfaccia {
	
	private static final String TABLE_Azienda = "Azienda";
	private static final String TABLE_Utente = "Utente";
	private static final String TABLE_Acquisto = "Acquisto";
	private static final String TABLE_AcquistoDettaglio = "Acquisto_Dettaglio";
	private static final String TABLE_Fattura = "Fattura";
	
	public FatturaBean getFatturaOrdine(int id_utente, int id_ordine) throws SQLException {
		Connection connection = null;
	    PreparedStatement preparedStatement = null;
	    FatturaBean fattura = new FatturaBean();
	    
	    String selectSQL = "SELECT f.DataEmissione, f.MetodoPagamento, f.Note, f.NomeCliente, f.CognomeCliente, f.PaeseCliente, f.ProvinciaCliente, f.CittaCliente, f.ViaCliente, f.CivicoCliente, f.CAPCliente, az.NomeAzienda, az.Paese, az.Provincia, az.Citta, az.Via, az.CAP, az.PartitaIVA "
	    				 + "FROM " + TABLE_Fattura + " f JOIN " + TABLE_Acquisto + " a ON f.Acquisto = a.ID_Acquisto JOIN " + TABLE_Azienda + " az ON f.InformazioniAzienda = az.ID_Azienda "
	    				 + "WHERE a.Utente = ? AND a.ID_Acquisto = ?";

	    try {
	        connection = DriverManagerConnectionPool.getConnection();
	        preparedStatement = connection.prepareStatement(selectSQL);
		    
		    preparedStatement.setInt(1, id_utente);
		    preparedStatement.setInt(2, id_ordine);
		    
		    ResultSet rs = preparedStatement.executeQuery();
		    
		    if(rs.next()) {
		    	fattura.setNomeAzienda(rs.getString("NomeAzienda"));
		    	fattura.setPaeseAzienda(rs.getString("Paese"));
		    	fattura.setProvinciaAzienda(rs.getString("Provincia"));
		    	fattura.setCittaAzienda(rs.getString("Citta"));
		    	fattura.setViaAzienda(rs.getString("Via"));
		    	fattura.setCapAzienda(rs.getString("CAP"));
		    	fattura.setPartivaIvaAzienda(rs.getString("PartitaIVA"));
		    	
		    	Date date = rs.getDate("DataEmissione");

	            LocalDate localDateTime = date.toLocalDate();
	            fattura.setDataEmissione(localDateTime);
		    	fattura.setMetodoPagamento(rs.getString("MetodoPagamento"));
		    	fattura.setNote(rs.getString("Note"));
		    	fattura.setNomeCliente(rs.getString("NomeCliente"));
		    	fattura.setCognomeCliente(rs.getString("CognomeCliente"));
		    	fattura.setPaeseCliente(rs.getString("PaeseCliente"));
		    	fattura.setProvinciaCliente(rs.getString("ProvinciaCliente"));
		    	fattura.setCittaCliente(rs.getString("CittaCliente"));
		    	fattura.setViaCliente(rs.getString("ViaCliente"));
		    	fattura.setCivicoCliente(rs.getString("CivicoCliente"));
		    	fattura.setCapCliente(rs.getString("CAPCliente"));
		    }

	    } finally {
	        if (preparedStatement != null) {
	            preparedStatement.close();
	        }
	        if (connection != null) {
	            DriverManagerConnectionPool.releaseConnection(connection);
	        }
	    }
	    return fattura;
	}

}

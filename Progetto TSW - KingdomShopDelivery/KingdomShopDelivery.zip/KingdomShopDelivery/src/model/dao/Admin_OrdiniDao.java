package model.dao;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.LinkedList;
import java.util.List;
import java.util.LinkedHashMap;

import model.beans.Admin_OrdineBean;
import model.beans.Admin_OrdineDettagliBean;
import model.beans.Admin_OrdineProdottoDettagliBean;
import model.beans.ConfermaOrdineBean;
import model.beans.OrdineDettagliBean;
import model.beans.OrdineProdottoDettagliBean;
import model.dao.interfacce.Admin_OrdiniDaoInterfaccia;
import model.util.DriverManagerConnectionPool;


public class Admin_OrdiniDao implements Admin_OrdiniDaoInterfaccia {
	
	private static final String TABLE_Acquisto = "Acquisto";
	private static final String TABLE_Acquisto_Dettaglio = "Acquisto_Dettaglio";
	private static final String TABLE_Prodotto = "Prodotto";
	private static final String TABLE_ProdottoTaglia = "Prodotto_Taglia";
	private static final String TABLE_Sconto = "Sconto";
	private static final String TABLE_AcquistoDettagli = "Acquisto_Dettaglio";
	private static final String TABLE_Fattura = "Fattura";
	private static final String TABLE_Indirizzo = "Indirizzo";
	
	public synchronized int getNumeroVenditeTotali() throws SQLException {
		
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		int numero_ordini = 0;
		
		String selectSQL = "SELECT COUNT(*) AS NumeroOrdini "
						 + "FROM " + TABLE_Acquisto;
		
		try {
			connection = DriverManagerConnectionPool.getConnection();
			
			preparedStatement = connection.prepareStatement(selectSQL);
			
			ResultSet rs = preparedStatement.executeQuery();
			
			if(rs.next()) {
				numero_ordini = rs.getInt("NumeroOrdini");
			}

		} finally {
			try {
				if (preparedStatement != null) {preparedStatement.close();}
			} finally {
				DriverManagerConnectionPool.releaseConnection(connection);
			}
		}
		return numero_ordini;
	}
	
	public synchronized int getNumeroVenditeNuove() throws SQLException {
		
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		int numero_ordini = 0;
		
		String selectSQL = "SELECT COUNT(*) AS NumeroOrdiniUltimi30Giorni "
						 + "FROM " + TABLE_Acquisto + " "
						 + "WHERE DataAcquisto >= DATE_SUB(NOW(), INTERVAL 30 DAY)";
		
		try {
			connection = DriverManagerConnectionPool.getConnection();
			
			preparedStatement = connection.prepareStatement(selectSQL);
			
			ResultSet rs = preparedStatement.executeQuery();
			
			if(rs.next()) {
				numero_ordini = rs.getInt("NumeroOrdiniUltimi30Giorni");
			}

		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				DriverManagerConnectionPool.releaseConnection(connection);
			}
		}
		return numero_ordini;
	}
	
	public synchronized int getNumeroProdottiVenduti() throws SQLException {
		
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		int numero_prodotti_venduti = 0;
		
		String selectSQL = "SELECT SUM(QuantitaAcquistata) AS NumeroProdottiAcquistati "
						 + "FROM " + TABLE_Acquisto_Dettaglio;
		
		try {
			connection = DriverManagerConnectionPool.getConnection();
			
			preparedStatement = connection.prepareStatement(selectSQL);
			
			ResultSet rs = preparedStatement.executeQuery();
			
			if(rs.next()) {
				numero_prodotti_venduti = rs.getInt("NumeroProdottiAcquistati");
			}

		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				DriverManagerConnectionPool.releaseConnection(connection);
			}
		}
		return numero_prodotti_venduti;
		
	}
	
	public synchronized int getNumeroProdottiVendutiRecentemente() throws SQLException {
		
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		int numero_prodotti_venduti = 0;
		
		String selectSQL = "SELECT SUM(ad.QuantitaAcquistata) AS NumeroProdottiAcquistatiUltimi30Giorni "
						 + "FROM " + TABLE_Acquisto_Dettaglio + " ad JOIN " + TABLE_Acquisto + " a ON ad.Acquisto = a.ID_Acquisto "
						 + "WHERE a.DataAcquisto >= DATE_SUB(NOW(), INTERVAL 30 DAY)";
		
		try {
			connection = DriverManagerConnectionPool.getConnection();
			
			preparedStatement = connection.prepareStatement(selectSQL);
			
			ResultSet rs = preparedStatement.executeQuery();
			
			if(rs.next()) {
				numero_prodotti_venduti = rs.getInt("NumeroProdottiAcquistatiUltimi30Giorni");
			}

		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				DriverManagerConnectionPool.releaseConnection(connection);
			}
		}
		return numero_prodotti_venduti;
	}
	
	public synchronized LinkedHashMap<Admin_OrdineBean, Integer> getOrdini() throws SQLException {
		
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		LinkedHashMap<Admin_OrdineBean, Integer> ordini = new LinkedHashMap<Admin_OrdineBean, Integer>();
		Admin_OrdineBean ordineCorrente = null;
		int ultimoIdOrdine = -1;
		
		String selectSQL = "SELECT a.ID_Acquisto, a.Utente, a.DataAcquisto, a.DataConsegna, ad.QuantitaAcquistata, ad.PrezzoSingolo, ad.Iva "
				         + "FROM Acquisto a JOIN Acquisto_dettaglio ad ON a.ID_Acquisto = ad.Acquisto "
				         + "ORDER BY a.DataAcquisto DESC, a.ID_Acquisto DESC";
		
		try {
			connection = DriverManagerConnectionPool.getConnection();
			
			preparedStatement = connection.prepareStatement(selectSQL);
			
			ResultSet rs = preparedStatement.executeQuery();
			
			while(rs.next()) {
				int idOrdine = rs.getInt("ID_Acquisto");
				int idUtente = rs.getInt("Utente");
				
				if (idOrdine != ultimoIdOrdine) {
			        ordineCorrente = new Admin_OrdineBean();
			        
			        ordineCorrente.setNumeroOrdine(idOrdine);
			        ordineCorrente.setDataAcquisto(rs.getDate("DataAcquisto").toLocalDate());
			        LocalDate dataConsegna = (rs.getDate("DataConsegna") != null) ? rs.getDate("DataConsegna").toLocalDate() : null;
			        ordineCorrente.setDataConsegna(dataConsegna);

			        ordini.put(ordineCorrente,idUtente);
			        ultimoIdOrdine = idOrdine;
			    }
				
			    int quantita = rs.getInt("QuantitaAcquistata");
			    BigDecimal prezzo_singolo = rs.getBigDecimal("PrezzoSingolo");
			    BigDecimal iva_prodotto = rs.getBigDecimal("Iva");
			    
			    BigDecimal totaleProdotto = prezzo_singolo.multiply(BigDecimal.valueOf(quantita));
			    BigDecimal iva_totale = totaleProdotto.multiply(iva_prodotto);
			    iva_totale = iva_totale.divide(new BigDecimal("100"));
			    
			    ordineCorrente.aggiungiAlTotale(totaleProdotto);
			    ordineCorrente.aggiungiAllIvaTotale(iva_totale);
			}

		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				DriverManagerConnectionPool.releaseConnection(connection);
			}
		}
		return ordini;
	}
	
public synchronized LinkedHashMap<Admin_OrdineBean, Integer> getOrdini(LocalDate data_inizio, LocalDate data_fine) throws SQLException {
		
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		LinkedHashMap<Admin_OrdineBean, Integer> ordini = new LinkedHashMap<Admin_OrdineBean, Integer>();
		Admin_OrdineBean ordineCorrente = null;
		int ultimoIdOrdine = -1;
		String where = "";
		int n_ps = 0;
		
		if(data_inizio != null && data_fine != null) {
			where = "WHERE DataAcquisto >= ? AND DataAcquisto <= ? ";
			n_ps = 1;
		} else {
			if(data_inizio != null && data_fine == null) {
				where = "WHERE DataAcquisto >= ? ";
				n_ps = 2;
			} else {
				where = "WHERE DataAcquisto <= ? ";
				n_ps = 3;
			}
		}
		
		String selectSQL = "SELECT a.ID_Acquisto, a.Utente, a.DataAcquisto, a.DataConsegna, ad.QuantitaAcquistata, ad.PrezzoSingolo, ad.Iva "
				         + "FROM Acquisto a JOIN Acquisto_dettaglio ad ON a.ID_Acquisto = ad.Acquisto "
				         + where 
				         + "ORDER BY a.DataAcquisto DESC, a.ID_Acquisto DESC";
		
		try {
			connection = DriverManagerConnectionPool.getConnection();
			
			preparedStatement = connection.prepareStatement(selectSQL);
			
			switch(n_ps) {
			case 1: preparedStatement.setDate(1, Date.valueOf(data_inizio)); preparedStatement.setDate(2, Date.valueOf(data_fine)); break;
			case 2: preparedStatement.setDate(1, Date.valueOf(data_inizio)); break;
			case 3: preparedStatement.setDate(1, Date.valueOf(data_fine)); break;
			}
			
			ResultSet rs = preparedStatement.executeQuery();
			
			while(rs.next()) {
				int idOrdine = rs.getInt("ID_Acquisto");
				int idUtente = rs.getInt("Utente");
				
				if (idOrdine != ultimoIdOrdine) {
			        ordineCorrente = new Admin_OrdineBean();
			        
			        ordineCorrente.setNumeroOrdine(idOrdine);
			        ordineCorrente.setDataAcquisto(rs.getDate("DataAcquisto").toLocalDate());
			        LocalDate dataConsegna = (rs.getDate("DataConsegna") != null) ? rs.getDate("DataConsegna").toLocalDate() : null;
			        ordineCorrente.setDataConsegna(dataConsegna);

			        ordini.put(ordineCorrente,idUtente);
			        ultimoIdOrdine = idOrdine;
			    }
				
			    int quantita = rs.getInt("QuantitaAcquistata");
			    BigDecimal prezzo_singolo = rs.getBigDecimal("PrezzoSingolo");
			    BigDecimal iva_prodotto = rs.getBigDecimal("Iva");
			    
			    BigDecimal totaleProdotto = prezzo_singolo.multiply(BigDecimal.valueOf(quantita));
			    BigDecimal iva_totale = totaleProdotto.multiply(iva_prodotto);
			    iva_totale = iva_totale.divide(new BigDecimal("100"));
			    
			    ordineCorrente.aggiungiAlTotale(totaleProdotto);
			    ordineCorrente.aggiungiAllIvaTotale(iva_totale);
			}

		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				DriverManagerConnectionPool.releaseConnection(connection);
			}
		}
		return ordini;
	}
	
	public synchronized LinkedHashMap<Admin_OrdineDettagliBean,Integer> getOrdineDettagli(int numero_ordine) throws SQLException {
		
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		Admin_OrdineDettagliBean ordine_dettagli = new Admin_OrdineDettagliBean();
		LinkedHashMap<Admin_OrdineDettagliBean,Integer> ordine = new LinkedHashMap<Admin_OrdineDettagliBean,Integer>();

		String selectSQL = "SELECT a.ID_Acquisto, a.Utente, a.NomeCitofono, a.CognomeCitofono, a.Paese, a.Provincia, a.Citta, a.Via, a.CAP, a.Civico, a.DataAcquisto, a.DataConsegna, a.NoteSpedizione, ad.QuantitaAcquistata, ad.PrezzoSingolo, ad.Iva, pt.ID_ProdottoTaglia, pt.NomeTaglia, p.ID_Prodotto, p.Nome, p.Marca, f.NomeCliente, f.CognomeCliente, f.PaeseCliente, f.ProvinciaCliente, f.CittaCliente, f.ViaCliente, f.CAPCliente, f.CivicoCliente "
						 + "FROM " + TABLE_Acquisto + " a JOIN " + TABLE_AcquistoDettagli + " ad ON a.ID_Acquisto = ad.Acquisto "
						 		   + "JOIN " + TABLE_Fattura + " f ON a.ID_Acquisto = f.Acquisto "
						 		   + "JOIN " + TABLE_ProdottoTaglia + " pt ON ad.ProdottoTaglia = pt.ID_ProdottoTaglia "
						 		   + "JOIN " + TABLE_Prodotto + " p ON pt.Prodotto = p.ID_Prodotto "
						 + "WHERE ID_Acquisto = ?";
		
		try {
			connection = DriverManagerConnectionPool.getConnection();
			
			preparedStatement = connection.prepareStatement(selectSQL);
			
			preparedStatement.setInt(1, numero_ordine);
			
			ResultSet rs = preparedStatement.executeQuery();

			if(rs.next()) {
				
				int id_cliente = rs.getInt("Utente");
                ordine_dettagli.setNumeroOrdine(rs.getInt("ID_Acquisto"));
                ordine_dettagli.setDataAcquisto(rs.getDate("DataAcquisto").toLocalDate());
                LocalDate dataConsegna = (rs.getDate("DataConsegna") != null) ? rs.getDate("DataConsegna").toLocalDate() : null;
                ordine_dettagli.setDataConsegna(dataConsegna);    
                
                ordine_dettagli.setNomeCliente(rs.getString("NomeCitofono"));
                ordine_dettagli.setCognomeCliente(rs.getString("CognomeCitofono"));
                ordine_dettagli.setPaeseCliente(rs.getString("Paese"));
                ordine_dettagli.setProvinciaCliente(rs.getString("Provincia"));
                ordine_dettagli.setCittaCliente(rs.getString("Citta"));
                ordine_dettagli.setViaCliente(rs.getString("Via"));
                ordine_dettagli.setCapCliente(rs.getString("CAP"));
                ordine_dettagli.setCivicoCliente(rs.getString("Civico"));
                ordine_dettagli.setNoteSpedizione(rs.getString("NoteSpedizione"));
                
                ordine_dettagli.setFatturaNomeCliente(rs.getString("NomeCliente"));
                ordine_dettagli.setFatturaCognomeCliente(rs.getString("CognomeCliente"));
                ordine_dettagli.setFatturaPaeseCliente(rs.getString("PaeseCliente"));
                ordine_dettagli.setFatturaProvinciaCliente(rs.getString("ProvinciaCliente"));
                ordine_dettagli.setFatturaCittaCliente(rs.getString("CittaCliente"));
                ordine_dettagli.setFatturaViaCliente(rs.getString("ViaCliente"));
                ordine_dettagli.setFatturaCapCliente(rs.getString("CAPCliente"));
                ordine_dettagli.setFatturaCivicoCliente(rs.getString("CivicoCliente"));
                
                Admin_OrdineProdottoDettagliBean prodotto1 = new Admin_OrdineProdottoDettagliBean();
	            prodotto1.setIdProdotto(rs.getInt("ID_Prodotto"));
	            prodotto1.setIdTaglia(rs.getInt("ID_ProdottoTaglia"));
	            prodotto1.setNome(rs.getString("Nome"));
	            prodotto1.setMarca(rs.getString("Marca"));
	            prodotto1.setNomeTaglia(rs.getString("NomeTaglia"));
	            prodotto1.setQuantitaAcquistata(rs.getInt("QuantitaAcquistata"));
	            prodotto1.setPrezzoSingolo(rs.getBigDecimal("PrezzoSingolo"));
	            prodotto1.setIva(rs.getBigDecimal("Iva"));
	            
	            int quantita1 = rs.getInt("QuantitaAcquistata");
	            BigDecimal prezzoSingolo1 = rs.getBigDecimal("PrezzoSingolo");
	            BigDecimal iva_prodotto1 = rs.getBigDecimal("Iva");
	            BigDecimal totaleProdotto1 = prezzoSingolo1.multiply(BigDecimal.valueOf(quantita1));

	            BigDecimal iva_totale1 = totaleProdotto1.multiply(iva_prodotto1);
			    iva_totale1 = iva_totale1.divide(new BigDecimal("100"));
	            
			    ordine_dettagli.aggiungiAlTotale(totaleProdotto1);
			    ordine_dettagli.aggiungiAllIvaTotale(iva_totale1);
			    
	            ordine_dettagli.setProdotto(prodotto1);			    
            
                while (rs.next()) {

                	Admin_OrdineProdottoDettagliBean prodotto = new Admin_OrdineProdottoDettagliBean();
    	            prodotto.setIdProdotto(rs.getInt("ID_Prodotto"));
    	            prodotto.setIdTaglia(rs.getInt("ID_ProdottoTaglia"));
    	            prodotto.setNome(rs.getString("Nome"));
    	            prodotto.setMarca(rs.getString("Marca"));
    	            prodotto.setNomeTaglia(rs.getString("NomeTaglia"));
    	            prodotto.setQuantitaAcquistata(rs.getInt("QuantitaAcquistata"));
    	            prodotto.setPrezzoSingolo(rs.getBigDecimal("PrezzoSingolo"));
    	            prodotto.setIva(rs.getBigDecimal("Iva"));
    	            
    	            int quantita = rs.getInt("QuantitaAcquistata");
    	            BigDecimal prezzoSingolo = rs.getBigDecimal("PrezzoSingolo");
    	            BigDecimal iva_prodotto = rs.getBigDecimal("Iva");
    	            BigDecimal totaleProdotto = prezzoSingolo.multiply(BigDecimal.valueOf(quantita));

    	            BigDecimal iva_totale = totaleProdotto.multiply(iva_prodotto);
    	            iva_totale = iva_totale.divide(new BigDecimal("100"));
    	            
    	            
    	            ordine_dettagli.aggiungiAlTotale(totaleProdotto);
    	            ordine_dettagli.aggiungiAllIvaTotale(iva_totale);
    	            ordine_dettagli.setProdotto(prodotto);
    	        }
                ordine.put(ordine_dettagli,id_cliente);
			}

		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				DriverManagerConnectionPool.releaseConnection(connection);
			}
		}
		return ordine;	
	}
	
}

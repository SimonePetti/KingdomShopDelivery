package model.dao;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import model.beans.ProdottoBean;
import model.beans.ProdottoDettaglioBean;
import model.beans.ProdottoInOffertaBean;
import model.beans.ProdottoTagliaBean;
import model.beans.ProdottoTagliaInOffertaBean;
import model.dao.interfacce.EventoAggiornaDB_DaoInterfaccia;
import model.dao.interfacce.ProdottoDettaglioDaoInterfaccia;
import model.util.DriverManagerConnectionPool;

public class ProdottoDettaglioDao extends ProdottoDao implements ProdottoDettaglioDaoInterfaccia {
	
	private static final String TABLE_Prodotto = "Prodotto";
	private static final String TABLE_ProdottoTaglia = "Prodotto_Taglia";
	private static final String TABLE_Sconto = "Sconto";
	
	static EventoAggiornaDB_DaoInterfaccia EventoAggiornaDB_Dao = new EventoAggiornaDB_Dao();
	
	@Override
	public ProdottoDettaglioBean doRetrieveByKey(int prodottoId) throws SQLException{
		
		Connection connection = null;
		PreparedStatement preparedStatement = null;

		ProdottoDettaglioBean prodotto = new ProdottoDettaglioBean();
		
		String selectSQL = "SELECT p.ID_Prodotto, p.Nome, p.Marca, p.Immagine, p.Descrizione, p.PrezzoMinimo, p.PrezzoMinimoEScontato, p.PrezzoInizialePrezzoMinimo, p.Iva, "
						 	+ " pt.ID_ProdottoTaglia, pt.NomeTaglia, pt.Prezzo, pt.QuantitaDisponibile, s.PercentualeSconto, s.DataInizio, s.DataFine "
						 + "FROM " + TABLE_Prodotto + " p "
						 	+ "JOIN " + TABLE_ProdottoTaglia + " pt ON p.ID_Prodotto = pt.Prodotto "
						 	+ "LEFT JOIN (SELECT p1.ID_Prodotto, s1.PercentualeSconto, s1.DataInizio, s1.DataFine "
						 		+ "FROM " + TABLE_Prodotto + "  p1 "
						 		+ "JOIN " + TABLE_Sconto + " s1 ON p1.ID_Prodotto = s1.Prodotto "
						 		+ "WHERE (s1.DataInizio <= CURDATE() AND s1.DataFine >= CURDATE() AND p1.PrezzoMinimoEScontato = FALSE) " 
						 			+ "OR (s1.DataFine < CURDATE() AND p1.PrezzoMinimoEScontato = TRUE) OR (s1.DataInizio <= CURDATE() AND s1.DataFine >= CURDATE())) AS s ON p.ID_Prodotto = s.ID_Prodotto "
						 + "WHERE p.Cancellato = FALSE AND p.ID_Prodotto = ?";

		try {
			connection = DriverManagerConnectionPool.getConnection();
			preparedStatement = connection.prepareStatement(selectSQL);
			preparedStatement.setInt(1, prodottoId);

			ResultSet rs = preparedStatement.executeQuery();
			
			if(rs.next()) {
	            
				if(rs.getDate("DataFine") == null) {
					
					prodotto = this.creaProdottoDettagliBean(rs, new BigDecimal(-1));
					
	        	} else {
	        		Date dataInizio = rs.getDate("DataInizio");
	        		Date dataFine = rs.getDate("DataFine");
                    Date oggi = new Date(System.currentTimeMillis());
                    
	        		if(((dataInizio.before(oggi) || dataInizio.equals(oggi)) && (dataFine.after(oggi) || dataFine.equals(oggi))) && rs.getBoolean("PrezzoMinimoEScontato") == false) {
	        			BigDecimal percentualeScontoAggiornata = EventoAggiornaDB_Dao.getPercentualeScontoAggiornata(rs.getInt("ID_Prodotto"));
	        			prodotto = this.creaProdottoDettagliBean(rs, percentualeScontoAggiornata);
	        		} else {
	        			if(dataFine.before(oggi) && rs.getBoolean("PrezzoMinimoEScontato") == true ) {
	        				EventoAggiornaDB_Dao.eliminaScontoProdotto(rs.getInt("ID_Prodotto"));
	        				prodotto = this.creaProdottoDettagliBean(rs, new BigDecimal(-1));
		        		} else {
		        			prodotto = this.creaProdottoDettagliBean(rs, new BigDecimal(0));
		        		}
	        		}
	        	}
			}
		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				DriverManagerConnectionPool.releaseConnection(connection);
			}
		}
	return prodotto;
	}
	
	private ProdottoDettaglioBean creaProdottoDettagliBean(ResultSet rs, BigDecimal percentuale_sconto) throws SQLException {
		
		ProdottoDettaglioBean prodotto = new ProdottoDettaglioBean();
		
		prodotto.setId(rs.getInt("ID_Prodotto"));
		prodotto.setNome(rs.getString("Nome"));
		prodotto.setMarca(rs.getString("Marca"));
		byte[] Immagine = rs.getBytes("Immagine");
        if(Immagine != null) {
        	prodotto.setImageFromByteArray(Immagine);
        }
        prodotto.setDescrizione(rs.getString("Descrizione"));
        prodotto.setIva(rs.getBigDecimal("Iva"));
        
        BigDecimal prezzo_iniziale = percentuale_sconto.equals(new BigDecimal(-1)) ? new BigDecimal(0) : rs.getBigDecimal("PrezzoInizialePrezzoMinimo");
        
        do {
        	if(rs.getBigDecimal("PrezzoInizialePrezzoMinimo") == null || prezzo_iniziale.equals(new BigDecimal(0))) {
        		ProdottoTagliaBean prodottoTaglia = this.creaProdottoTagliaBean(rs);
        		prodotto.setTaglie(prodottoTaglia);
        	} else {
        		ProdottoTagliaInOffertaBean prodottoTaglia = this.creaProdottoTagliaInOffertaBean(rs, percentuale_sconto);
        		prodotto.setTaglie(prodottoTaglia);
        	}
        } while(rs.next());
        return prodotto;
	}
	
	private ProdottoTagliaBean creaProdottoTagliaBean(ResultSet rs) throws SQLException {
		ProdottoTagliaBean prodotto = new ProdottoTagliaBean();
    	prodotto.setIdTaglia(rs.getInt("ID_ProdottoTaglia"));
    	prodotto.setNomeTaglia(rs.getString("NomeTaglia"));
    	prodotto.setPrezzoTaglia(rs.getBigDecimal("Prezzo"));
    	prodotto.setQuantitaDisponibile(rs.getInt("QuantitaDisponibile")); 
    	
    	return prodotto;
	}
	
	private ProdottoTagliaInOffertaBean creaProdottoTagliaInOffertaBean(ResultSet rs, BigDecimal percentuale_sconto) throws SQLException {
		ProdottoTagliaInOffertaBean prodotto = new ProdottoTagliaInOffertaBean();
		BigDecimal sconto = percentuale_sconto.equals(new BigDecimal(0)) ? rs.getBigDecimal("PercentualeSconto") : percentuale_sconto;
    	prodotto.setIdTaglia(rs.getInt("ID_ProdottoTaglia"));
    	prodotto.setNomeTaglia(rs.getString("NomeTaglia"));
    	prodotto.setPrezzoTaglia(rs.getBigDecimal("Prezzo"));
    	prodotto.setQuantitaDisponibile(rs.getInt("QuantitaDisponibile")); 
    	prodotto.setPercentualeSconto(sconto);
    	
    	return prodotto;
	}

}
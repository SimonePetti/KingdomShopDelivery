package model.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.ResultSet;

import model.dao.interfacce.LoginDaoInterfaccia;
import model.util.DriverManagerConnectionPool;


public class LoginDao implements LoginDaoInterfaccia {
	
	private static final String TABLE_Utente = "Utente";
	
	@Override
	public synchronized int ControllaCredenziali(String email, String password) throws SQLException {
		
		Connection connection = null;
	    PreparedStatement preparedStatement = null;
	    int idUtenteTrovato = -1;
	    
	    String selectSQL = "SELECT ID_Utente "
	    		         + "FROM " + TABLE_Utente + " "
	    		         + "WHERE Email = ? AND Password = ?";
	    
	    try {
	        connection = DriverManagerConnectionPool.getConnection();
	        preparedStatement = connection.prepareStatement(selectSQL);
	        
	        preparedStatement.setString(1, email);
	        preparedStatement.setString(2, password);
	        
	        ResultSet rs = preparedStatement.executeQuery();
	        
	        if(rs.next()) {
	        	idUtenteTrovato = rs.getInt("ID_Utente");
	        }

	    } finally {
	        if (preparedStatement != null) {
	            preparedStatement.close();
	        }
	        if (connection != null) {
	            DriverManagerConnectionPool.releaseConnection(connection);
	        }
	    }
	    return idUtenteTrovato;		         
	}

	public synchronized String getRuoloUtente(int id_utente) throws SQLException {
		
		Connection connection = null;
	    PreparedStatement preparedStatement = null;
	    String ruoloUtente = "utente";
	    
	    String selectSQL = "SELECT Tipo "
	    		         + "FROM " + TABLE_Utente + " "
	    		         + "WHERE ID_Utente = ?";
	    
	    try {
	        connection = DriverManagerConnectionPool.getConnection();
	        preparedStatement = connection.prepareStatement(selectSQL);
	        
	        preparedStatement.setInt(1, id_utente);
	        
	        ResultSet rs = preparedStatement.executeQuery();
	        
	        if(rs.next()) {
	        	ruoloUtente = rs.getString("Tipo");
	        }

	    } finally {
	        if (preparedStatement != null) {
	            preparedStatement.close();
	        }
	        if (connection != null) {
	            DriverManagerConnectionPool.releaseConnection(connection);
	        }
	    }
	    return ruoloUtente;		
	}
	
}

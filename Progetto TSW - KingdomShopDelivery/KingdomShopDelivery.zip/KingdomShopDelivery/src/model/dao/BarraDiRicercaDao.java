package model.dao;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;

import model.beans.OrdineBean;
import model.beans.OrdineProdottoBean;
import model.beans.ProdottoBean;
import model.beans.ProdottoInOffertaBean;
import model.dao.interfacce.BarraDiRicercaDaoInterfaccia;
import model.dao.interfacce.EventoAggiornaDB_DaoInterfaccia;
import model.util.DriverManagerConnectionPool;


public class BarraDiRicercaDao implements BarraDiRicercaDaoInterfaccia {
	
	private static final String TABLE_Acquisto = "Acquisto";
	private static final String TABLE_Acquisto_Dettaglio = "Acquisto_Dettaglio";
	private static final String TABLE_Prodotto = "Prodotto";
	private static final String TABLE_ProdottoTaglia = "Prodotto_Taglia";
	private static final String TABLE_Sconto = "Sconto";
	private static final String TABLE_AcquistoDettagli = "Acquisto_Dettaglio";
	private static final String TABLE_Fattura = "Fattura";
	
	static EventoAggiornaDB_DaoInterfaccia EventoAggiornaDB_Dao = new EventoAggiornaDB_Dao();
	
	public synchronized List<String> getSuggerimenti(String query) throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
        List<String> risultati = new ArrayList<String>();

		String selectSQL = "SELECT Nome "
						 + "FROM " + TABLE_Prodotto + " "
						 + "WHERE Nome LIKE ? AND Cancellato = FALSE";
		
		try {
			connection = DriverManagerConnectionPool.getConnection();
			
			preparedStatement = connection.prepareStatement(selectSQL);
			
			preparedStatement.setString(1, "%" + query + "%");
			
			ResultSet rs = preparedStatement.executeQuery();

	        while (rs.next()) {
	            risultati.add(rs.getString("Nome"));
	        }

		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				DriverManagerConnectionPool.releaseConnection(connection);
			}
		}
		return risultati;
	}
	
	public synchronized Collection<ProdottoBean> getProdottiSuggeriti(String query) throws SQLException {
		Connection connection = null;
	    PreparedStatement preparedStatement = null;
	    
	    Collection<ProdottoBean> prodotti = new LinkedList<ProdottoBean>();
	    
	    String selectSQL = "SELECT p.ID_Prodotto, p.Nome, p.Marca, p.Immagine, p.PrezzoMinimo, p.PrezzoMinimoEScontato, p.PrezzoInizialePrezzoMinimo, s.PercentualeSconto, s.DataInizio, s.DataFine "
				 + "FROM " + TABLE_Prodotto + " p LEFT JOIN "
				 + "(SELECT p1.ID_Prodotto, s1.PercentualeSconto, s1.DataInizio, s1.DataFine "
				 	+ "FROM " + TABLE_Prodotto + " p1 "
				 	+ "JOIN " + TABLE_Sconto + " s1 ON p1.ID_Prodotto = s1.Prodotto "
				 	+ "WHERE (s1.DataInizio <= CURDATE() AND s1.DataFine >= CURDATE() AND p1.PrezzoMinimoEScontato = FALSE) " 
				 		+ "OR (s1.DataFine < CURDATE() AND p1.PrezzoMinimoEScontato = TRUE) OR (s1.DataInizio <= CURDATE() AND s1.DataFine >= CURDATE())) AS s ON p.ID_Prodotto = s.ID_Prodotto "
				 + "WHERE p.Cancellato = FALSE AND p.Nome LIKE ?";
	    
	    try {
	        connection = DriverManagerConnectionPool.getConnection();
	        preparedStatement = connection.prepareStatement(selectSQL);
	        
	        preparedStatement.setString(1, "%" + query + "%");
	        
	        ResultSet rs = preparedStatement.executeQuery();
	        
	        while (rs.next()) {
        	  	
	        	if(rs.getDate("DataFine") == null) {
	        		
	        		ProdottoBean bean;
		        	Boolean SceltaBean = rs.getBoolean("PrezzoMinimoEScontato");
	        		
	        		if(SceltaBean) {
	        			ProdottoInOffertaBean prodottoInOfferta = this.creaProdottoInOffertaBean(rs);
		        		bean = prodottoInOfferta;
		        	} else {
		        		bean = this.creaProdottoBean(rs);
		        	}
		            prodotti.add(bean);
		            
	        	} else {
	        		Date dataInizio = rs.getDate("DataInizio");
	        		Date dataFine = rs.getDate("DataFine");
                    Date oggi = new Date(System.currentTimeMillis());
                    
	        		if(((dataInizio.before(oggi) || dataInizio.equals(oggi)) && (dataFine.after(oggi) || dataFine.equals(oggi))) && rs.getBoolean("PrezzoMinimoEScontato") == false) {
	        			ProdottoInOffertaBean prodottoAggiornato = EventoAggiornaDB_Dao.getProdottoInOffertaBeanAggiornato(rs.getInt("ID_Prodotto"));
	        			prodotti.add((ProdottoBean) prodottoAggiornato);
	        		} else {
	        			if(dataFine.before(oggi) && rs.getBoolean("PrezzoMinimoEScontato") == true ) {
		        			ProdottoBean prodottoAggiornato = (ProdottoBean) EventoAggiornaDB_Dao.getProdottoBeanAggiornato(rs.getInt("ID_Prodotto"));
		        			prodotti.add(prodottoAggiornato);
		        		} else {
		        			ProdottoBean bean;
				        	Boolean SceltaBean = rs.getBoolean("PrezzoMinimoEScontato");
			        		
			        		if(SceltaBean) {
			        			ProdottoInOffertaBean prodottoInOfferta = this.creaProdottoInOffertaBean(rs);
				        		bean = prodottoInOfferta;
				        	} else {
				        		bean = this.creaProdottoBean(rs);
				        	}
				            prodotti.add(bean);
		        		}
	        		}
	        	}
	        }
	    } finally {
	        if (preparedStatement != null) {
	            preparedStatement.close();
	        }
	        if (connection != null) {
	            DriverManagerConnectionPool.releaseConnection(connection);
	        }
	    }  
	    return prodotti;
	}
	
	private ProdottoBean creaProdottoBean(ResultSet rs) throws SQLException {
		
		ProdottoBean prodotto = new ProdottoBean();
		
		prodotto.setId(rs.getInt("ID_prodotto"));
        prodotto.setNome(rs.getString("Nome"));
        prodotto.setMarca(rs.getString("Marca"));
        byte[] Immagine = rs.getBytes("Immagine");
        if(Immagine != null) {
        	prodotto.setImageFromByteArray(Immagine);
        }
        prodotto.setPrezzoMinimo(rs.getBigDecimal("PrezzoMinimo"));
        
        return prodotto;
	}
	
	private ProdottoInOffertaBean creaProdottoInOffertaBean(ResultSet rs) throws SQLException {
		
		ProdottoInOffertaBean prodotto = new ProdottoInOffertaBean();
		
		prodotto.setId(rs.getInt("ID_prodotto"));
        prodotto.setNome(rs.getString("Nome"));
        prodotto.setMarca(rs.getString("Marca"));
        byte[] Immagine = rs.getBytes("Immagine");
        if(Immagine != null) {
        	prodotto.setImageFromByteArray(Immagine);
        }
        prodotto.setPrezzoMinimo(rs.getBigDecimal("PrezzoMinimo"));
        prodotto.setPrezzoIniziale(rs.getBigDecimal("PrezzoInizialePrezzoMinimo"));
        prodotto.setPercentualeSconto(rs.getBigDecimal("PercentualeSconto"));
        
        return prodotto;
	}

}

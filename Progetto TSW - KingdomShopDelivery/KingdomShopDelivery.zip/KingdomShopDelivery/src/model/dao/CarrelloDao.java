package model.dao;

import model.beans.CarrelloBean;
import model.beans.CarrelloProdottoBean;
import model.beans.CarrelloProdottoInOffertaBean;
import model.beans.ProdottoBean;
import model.beans.ProdottoInOffertaBean;
import model.beans.WishListBean;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.*;

import model.dao.interfacce.CarrelloDaoInterfaccia;
import model.dao.interfacce.EventoAggiornaDB_DaoInterfaccia;
import model.util.DriverManagerConnectionPool;


public class CarrelloDao implements CarrelloDaoInterfaccia {
	
	private static final String TABLE_Prodotto = "Prodotto";
	private static final String TABLE_ProdottoTaglia = "Prodotto_Taglia";
	private static final String TABLE_Sconto = "Sconto";
	private static final String TABLE_Carrello = "Carrello";
	
	static EventoAggiornaDB_DaoInterfaccia EventoAggiornaDB_Dao = new EventoAggiornaDB_Dao();
	
	public synchronized void doSave(int id_taglia, int id_utente, int quantita) throws SQLException {

		Connection connection = null;
		PreparedStatement preparedStatement = null;
		PreparedStatement lq = null;
		int quantitaDisponibile = 0;
	
		String selectSQL = "SELECT pt.QuantitaDisponibile FROM Prodotto_Taglia pt WHERE ID_ProdottoTaglia = ?"; 
		
		String updateSQL = "INSERT INTO " + TABLE_Carrello + " (Utente, ProdottoTaglia, Quantita) VALUES(?, ?, ?)";

		try {
			connection = DriverManagerConnectionPool.getConnection();
			
			lq = connection.prepareStatement(selectSQL);
			lq.setInt(1, id_taglia);
			
			ResultSet rs = lq.executeQuery();
			
			if(rs.next()) {
				quantitaDisponibile = rs.getInt("QuantitaDisponibile");
			}
			
			if(quantitaDisponibile == 0) {quantitaDisponibile = 1;}
			
			if(quantita > quantitaDisponibile) {
				quantita = quantitaDisponibile;
			}
			
			preparedStatement = connection.prepareStatement(updateSQL);
			
			preparedStatement.setInt(1, id_utente);
			preparedStatement.setInt(2, id_taglia);
			preparedStatement.setInt(3, quantita);

			preparedStatement.executeUpdate();
			connection.commit();

		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				DriverManagerConnectionPool.releaseConnection(connection);
			}
		}	
	}
	
	public synchronized void doDelete(int id_taglia, int id_utente) throws SQLException {

				Connection connection = null;
				PreparedStatement preparedStatement = null;

				String insertSQL = "DELETE FROM " + TABLE_Carrello + " WHERE Utente = ? AND  ProdottoTaglia = ?";

				try {
					connection = DriverManagerConnectionPool.getConnection();
					preparedStatement = connection.prepareStatement(insertSQL);
					
					preparedStatement.setInt(1, id_utente);
					preparedStatement.setInt(2, id_taglia);

					preparedStatement.executeUpdate();
					connection.commit();

				} finally {
					try {
						if (preparedStatement != null)
							preparedStatement.close();
					} finally {
						DriverManagerConnectionPool.releaseConnection(connection);
					}
				}	
	}
	
	public synchronized CarrelloBean getProdotti(int numeroProdotti, int id_utente) throws SQLException {
		
		Connection connection = null;
	    PreparedStatement preparedStatement = null;
		
		CarrelloBean carrello = new CarrelloBean();

		String selectSQL = "SELECT p.ID_Prodotto, p.Nome, p.Marca, p.Immagine, p.Iva, p.PrezzoMinimo, p.PrezzoMinimoEScontato, p.PrezzoInizialePrezzoMinimo, pt.ID_ProdottoTaglia, pt.NomeTaglia, pt.QuantitaDisponibile, pt.Prezzo, s.PercentualeSconto, s.DataInizio, s.DataFine, c.Quantita "
					     + "FROM " + TABLE_Carrello + " c "
					     	+ "JOIN " + TABLE_ProdottoTaglia + " pt ON c.ProdottoTaglia = pt.ID_ProdottoTaglia JOIN "
					     	+ TABLE_Prodotto + " p ON pt.Prodotto = p.ID_Prodotto LEFT JOIN "
					     		+ "(SELECT p1.ID_Prodotto, s1.PercentualeSconto, s1.DataInizio, s1.DataFine "
					     			+ "FROM " + TABLE_Prodotto + " p1 "
					     			+ "JOIN " + TABLE_Sconto + " s1 ON p1.ID_Prodotto = s1.Prodotto "
					     			+ "WHERE (s1.DataInizio <= CURDATE() AND s1.DataFine >= CURDATE() AND p1.PrezzoMinimoEScontato = FALSE) " 
					     				+ "OR (s1.DataFine < CURDATE() AND p1.PrezzoMinimoEScontato = TRUE) OR (s1.DataInizio <= CURDATE() AND s1.DataFine >= CURDATE())) AS s ON p.ID_Prodotto = s.ID_Prodotto "
					     + "WHERE p.Cancellato = FALSE AND c.Utente = ? "
					     + "ORDER BY c.DataInserimentoCarrello DESC";
		
		if(numeroProdotti >= 0) {
			selectSQL +=  " LIMIT " + numeroProdotti;
		}

		try {
			connection = DriverManagerConnectionPool.getConnection();
			preparedStatement = connection.prepareStatement(selectSQL);
			
			preparedStatement.setInt(1, id_utente);
   
			ResultSet rs = preparedStatement.executeQuery();
			
			while (rs.next()) {
        	  	
	        	if(rs.getDate("DataFine") == null) {
	        		
	        		CarrelloProdottoBean bean;
		        	Boolean SceltaBean = rs.getBoolean("PrezzoMinimoEScontato");
	        		
	        		if(SceltaBean) {
	        			CarrelloProdottoInOffertaBean prodottoInOfferta = this.creaCarrelloProdottoInOffertaBean(rs);
		        		bean = prodottoInOfferta;
		        	} else {
		        		bean = this.creaCarrelloProdottoBean(rs);
		        	}
	        		carrello.setProdottoLast(bean, rs.getInt("Quantita"));
		            
	        	} else {
	        		Date dataInizio = rs.getDate("DataInizio");
	        		Date dataFine = rs.getDate("DataFine");
                    Date oggi = new Date(System.currentTimeMillis());
                    
	        		if(((dataInizio.before(oggi) || dataInizio.equals(oggi)) && (dataFine.after(oggi) || dataFine.equals(oggi))) && rs.getBoolean("PrezzoMinimoEScontato") == false) {
	        			CarrelloProdottoInOffertaBean prodottoAggiornato = EventoAggiornaDB_Dao.getCarrelloProdottoInOffertaBeanAggiornato(rs.getInt("ID_Prodotto"));
	        			carrello.setProdottoLast((CarrelloProdottoBean) prodottoAggiornato, rs.getInt("Quantita"));
	        		} else {
	        			if(dataFine.before(oggi) && rs.getBoolean("PrezzoMinimoEScontato") == true ) {
		        			CarrelloProdottoBean prodottoAggiornato = EventoAggiornaDB_Dao.getCarrelloProdottoBeanAggiornato(rs.getInt("ID_Prodotto"));
		        			carrello.setProdottoLast(prodottoAggiornato, rs.getInt("Quantita"));
		        		} else {
		        			CarrelloProdottoBean bean;
				        	Boolean SceltaBean = rs.getBoolean("PrezzoMinimoEScontato");
			        		
			        		if(SceltaBean) {
			        			CarrelloProdottoInOffertaBean prodottoInOfferta = this.creaCarrelloProdottoInOffertaBean(rs);
				        		bean = prodottoInOfferta;
				        	} else {
				        		bean = this.creaCarrelloProdottoBean(rs);
				        	}
			        		carrello.setProdottoLast(bean, rs.getInt("Quantita"));
		        		}
	        		}
	        	}
	        }
		} finally {
			if (preparedStatement != null) {
				preparedStatement.close();
			}
			if (connection != null) {
				DriverManagerConnectionPool.releaseConnection(connection);
			}
		}
		return carrello;
	}
	
	public synchronized CarrelloBean getProdotti(int id_utente) throws SQLException {
		CarrelloBean carrello = getProdotti(-1, id_utente);
	    return carrello;
	}
	
	public synchronized CarrelloBean getProdottiGuest(int numeroProdotti, LinkedHashMap<List<Integer>, Integer> prodottiGuest) throws SQLException {
		
		Connection connection = null;
	    PreparedStatement preparedStatement = null;
		CarrelloBean carrello = new CarrelloBean();
		
		StringBuilder queryBuilder = new StringBuilder ("SELECT p.ID_Prodotto, p.Nome, p.Marca, p.Immagine, p.Iva, p.PrezzoMinimo, p.PrezzoMinimoEScontato, p.PrezzoInizialePrezzoMinimo, pt.ID_ProdottoTaglia, pt.NomeTaglia, pt.QuantitaDisponibile, pt.Prezzo, s.PercentualeSconto, s.DataInizio, s.DataFine "
			     	+ "FROM " + TABLE_ProdottoTaglia + " pt JOIN "
			     	+ TABLE_Prodotto + " p ON pt.Prodotto = p.ID_Prodotto LEFT JOIN "
			     		+ "(SELECT p1.ID_Prodotto, s1.PercentualeSconto, s1.DataInizio, s1.DataFine "
			     			+ "FROM " + TABLE_Prodotto + " p1 "
			     			+ "JOIN " + TABLE_Sconto + " s1 ON p1.ID_Prodotto = s1.Prodotto "
			     			+ "WHERE (s1.DataInizio <= CURDATE() AND s1.DataFine >= CURDATE() AND p1.PrezzoMinimoEScontato = FALSE) " 
			     				+ "OR (s1.DataFine < CURDATE() AND p1.PrezzoMinimoEScontato = TRUE) OR (s1.DataInizio <= CURDATE() AND s1.DataFine >= CURDATE())) AS s ON p.ID_Prodotto = s.ID_Prodotto "
			     + "WHERE p.Cancellato = FALSE ");

		Iterator<Map.Entry<List<Integer>, Integer>> iteratore = prodottiGuest.entrySet().iterator();
		
		if(iteratore.hasNext()) {
			
			List<Integer> Lista = iteratore.next().getKey();

			queryBuilder.append(" AND (p.ID_Prodotto = " + Lista.get(0) + " AND pt.ID_ProdottoTaglia = " + Lista.get(1) + ")");

			while (iteratore.hasNext()) {
				Lista = iteratore.next().getKey();
				queryBuilder.append(" OR " + "(p.ID_Prodotto = " + Lista.get(0) + " AND pt.ID_ProdottoTaglia = " + Lista.get(1) + ")");
			}
		}
		
		String selectSQL = queryBuilder.toString();
		
		if(numeroProdotti >= 0) {
			selectSQL +=  " LIMIT " + numeroProdotti;
		}

		try {
			connection = DriverManagerConnectionPool.getConnection();
			preparedStatement = connection.prepareStatement(selectSQL);
   
			ResultSet rs = preparedStatement.executeQuery();
			
			while (rs.next()) {
        	  	
	        	if(rs.getDate("DataFine") == null) {
	        		
	        		CarrelloProdottoBean bean;
		        	Boolean SceltaBean = rs.getBoolean("PrezzoMinimoEScontato");
	        		
	        		if(SceltaBean) {
	        			CarrelloProdottoInOffertaBean prodottoInOfferta = this.creaCarrelloProdottoInOffertaBean(rs);
		        		bean = prodottoInOfferta;
		        	} else {
		        		bean = this.creaCarrelloProdottoBean(rs);
		        	}
	        		carrello.setProdottoLast(bean, -1);
		            
	        	} else {
	        		Date dataInizio = rs.getDate("DataInizio");
	        		Date dataFine = rs.getDate("DataFine");
                    Date oggi = new Date(System.currentTimeMillis());
                    
	        		if(((dataInizio.before(oggi) || dataInizio.equals(oggi)) && (dataFine.after(oggi) || dataFine.equals(oggi))) && rs.getBoolean("PrezzoMinimoEScontato") == false) {
	        			CarrelloProdottoInOffertaBean prodottoAggiornato = EventoAggiornaDB_Dao.getCarrelloProdottoInOffertaBeanAggiornato(rs.getInt("ID_Prodotto"));
	        			carrello.setProdottoLast((CarrelloProdottoBean) prodottoAggiornato, -1);
	        		} else {
	        			if(dataFine.before(oggi) && rs.getBoolean("PrezzoMinimoEScontato") == true ) {
		        			CarrelloProdottoBean prodottoAggiornato = EventoAggiornaDB_Dao.getCarrelloProdottoBeanAggiornato(rs.getInt("ID_Prodotto"));
		        			carrello.setProdottoLast(prodottoAggiornato, -1);
		        		} else {
		        			CarrelloProdottoBean bean;
				        	Boolean SceltaBean = rs.getBoolean("PrezzoMinimoEScontato");
			        		
			        		if(SceltaBean) {
			        			CarrelloProdottoInOffertaBean prodottoInOfferta = this.creaCarrelloProdottoInOffertaBean(rs);
				        		bean = prodottoInOfferta;
				        	} else {
				        		bean = this.creaCarrelloProdottoBean(rs);
				        	}
			        		carrello.setProdottoLast(bean, -1);
		        		}
	        		}
	        	}
	        }
		} finally {
			if (preparedStatement != null) {
				preparedStatement.close();
			}
			if (connection != null) {
				DriverManagerConnectionPool.releaseConnection(connection);
			}
		}
		return carrello;
	}
	
	public synchronized CarrelloBean getProdottiGuest(LinkedHashMap<List<Integer>,Integer> prodottiGuest) throws SQLException {
		CarrelloBean carrello = getProdottiGuest(-1, prodottiGuest);
	    return carrello;
	}
	
	public synchronized int getQuantitaDisponibileTaglia(int id_taglia) throws SQLException {
		
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		int quantitaDisponibile = 0;
		
		String selectSQL = "SELECT QuantitaDisponibile FROM " + TABLE_ProdottoTaglia + " WHERE ID_ProdottoTaglia = ?";

		try {
			connection = DriverManagerConnectionPool.getConnection();
			
			preparedStatement = connection.prepareStatement(selectSQL);
			preparedStatement.setInt(1, id_taglia);
			
			ResultSet rs = preparedStatement.executeQuery();
			
			if(rs.next()) {
				quantitaDisponibile = rs.getInt("QuantitaDisponibile");
			}

		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				DriverManagerConnectionPool.releaseConnection(connection);
			}
		}
		return quantitaDisponibile;
	}
	
	public synchronized Boolean isIn(int id_prodotto, int id_taglia) throws SQLException {

		Connection connection = null;
		PreparedStatement preparedStatement = null;
		
		Boolean prodotto_trovato = false;

		String selectSQL = "SELECT p.ID_Prodotto "
						 + "FROM " + TABLE_Prodotto + " p JOIN " + TABLE_ProdottoTaglia + " pt ON p.ID_Prodotto = pt.Prodotto "
						 + "WHERE p.Cancellato = FALSE AND p.ID_Prodotto = ? AND pt.ID_ProdottoTaglia = ?";

		try {
			connection = DriverManagerConnectionPool.getConnection();
			preparedStatement = connection.prepareStatement(selectSQL);
			preparedStatement.setInt(1, id_prodotto);
			preparedStatement.setInt(2, id_taglia);

			ResultSet rs = preparedStatement.executeQuery();
			
			if(rs.next()) {
				prodotto_trovato = true;
			} else {
				prodotto_trovato = false;
			}

		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				DriverManagerConnectionPool.releaseConnection(connection);
			}
		}
	return prodotto_trovato;
	}
	
	public synchronized Boolean isInCarrello(int id_taglia, int id_utente) throws SQLException {
		
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		
		Boolean prodotto_giapresente = false;

		String selectSQL = "SELECT ProdottoTaglia "
						 + "FROM " + TABLE_Carrello + " "
						 + "WHERE ProdottoTaglia = ? AND Utente = ?";

		try {
			connection = DriverManagerConnectionPool.getConnection();
			preparedStatement = connection.prepareStatement(selectSQL);
			preparedStatement.setInt(1, id_taglia);
			
			preparedStatement.setInt(2, id_utente);
			
			ResultSet rs = preparedStatement.executeQuery();
			
			if(rs.next()) {
				prodotto_giapresente = true;
			} else {
				prodotto_giapresente = false;
			}

		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				DriverManagerConnectionPool.releaseConnection(connection);
			}
		}
	return prodotto_giapresente;
	}
	
	public synchronized void incrementaDiUno(int id_taglia, int id_utente) throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		
		String updateSQL = "UPDATE Carrello c "
						 + "SET Quantita = Quantita + 1 "
						 + "WHERE c.ProdottoTaglia = ? AND c.Utente = ? AND Quantita < 10 AND "
						 	+ "EXISTS (SELECT pt.ID_ProdottoTaglia "
						 		+ "FROM Prodotto_Taglia pt "
						 		+ "WHERE pt.ID_ProdottoTaglia = c.ProdottoTaglia AND pt.QuantitaDisponibile > Quantita)";

		try {
			connection = DriverManagerConnectionPool.getConnection();
			preparedStatement = connection.prepareStatement(updateSQL);
			preparedStatement.setInt(1, id_taglia);
			
			preparedStatement.setInt(2, id_utente);
			
			preparedStatement.executeUpdate();
			connection.commit();

		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				DriverManagerConnectionPool.releaseConnection(connection);
			}
		}
	}
	
	public synchronized void aumentaQuantita(int id_taglia, int id_utente, int quantita) throws SQLException {
		
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		PreparedStatement lq = null;
		int quantitaDisponibile = 0;
		
		String selectSQL = "SELECT pt.QuantitaDisponibile FROM Prodotto_Taglia pt WHERE ID_ProdottoTaglia = ?";
		
		String updateSQL = "UPDATE Carrello "
						 + "SET Quantita = ? "
						 + "WHERE ProdottoTaglia = ? AND Utente = ?";

		try {
			connection = DriverManagerConnectionPool.getConnection();
			
			lq = connection.prepareStatement(selectSQL);
			lq.setInt(1, id_taglia);
			
			ResultSet rs = lq.executeQuery();
			
			if(rs.next()) {
				quantitaDisponibile = rs.getInt("QuantitaDisponibile");
			}
			
			if(quantitaDisponibile == 0) {quantitaDisponibile = 1;}
			
			if(quantita > quantitaDisponibile) {
				quantita = quantitaDisponibile;
			}
			
			preparedStatement = connection.prepareStatement(updateSQL);
			
			preparedStatement.setInt(1, quantita);
			preparedStatement.setInt(2, id_taglia);
			
			preparedStatement.setInt(3, id_utente);
			
			preparedStatement.executeUpdate();
			connection.commit();

		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				DriverManagerConnectionPool.releaseConnection(connection);
			}
		}
	}
	
	public synchronized void modificaQuantitaCarrello(int id_taglia, int id_utente, int quantita) throws SQLException {
		
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		
		String updateSQL = "UPDATE Carrello "
						 + "SET Quantita = ? "
						 + "WHERE ProdottoTaglia = ? AND Utente = ?";

		try {
			connection = DriverManagerConnectionPool.getConnection();
			
			preparedStatement = connection.prepareStatement(updateSQL);
			
			preparedStatement.setInt(1, quantita);
			preparedStatement.setInt(2, id_taglia);
			
			preparedStatement.setInt(3, id_utente);
			
			preparedStatement.executeUpdate();
			connection.commit();

		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				DriverManagerConnectionPool.releaseConnection(connection);
			}
		}
	}
	
	public int getNumeroProdottiDisponibili(int id_utente) throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		int numero = 0;
		
		String selectSQL = "SELECT COUNT(c.ProdottoTaglia) AS NumeroProdottiDisponibili "
						 + "FROM " + TABLE_Carrello + " c "
						 	+ "JOIN " + TABLE_ProdottoTaglia + " pt ON c.ProdottoTaglia = pt.ID_ProdottoTaglia "
						 + "WHERE c.Utente = ? AND ((c.Quantita = 0 AND pt.QuantitaDisponibile > 0) OR pt.QuantitaDisponibile > 0)";
		
		try {
			connection = DriverManagerConnectionPool.getConnection();
			
			preparedStatement = connection.prepareStatement(selectSQL);
			
			preparedStatement.setInt(1, id_utente);
			
			ResultSet rs = preparedStatement.executeQuery();
			
			if(rs.next()) {
				numero = rs.getInt("NumeroProdottiDisponibili");
			}

		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				DriverManagerConnectionPool.releaseConnection(connection);
			}
		}
		return numero;
	}
	
	
	private CarrelloProdottoBean creaCarrelloProdottoBean(ResultSet rs) throws SQLException {
		
		CarrelloProdottoBean prodotto = new CarrelloProdottoBean();
		
		prodotto.setIdProdotto(rs.getInt("ID_prodotto"));
        prodotto.setNomeProdotto(rs.getString("Nome"));
        prodotto.setMarcaProdotto(rs.getString("Marca"));
        byte[] Immagine = rs.getBytes("Immagine");
        if(Immagine != null) {
        	prodotto.setImageFromByteArray(Immagine);
        }
        prodotto.setIva(rs.getBigDecimal("Iva"));
		prodotto.setIdTaglia(rs.getInt("ID_ProdottoTaglia"));
		prodotto.setNomeTaglia(rs.getString("NomeTaglia"));
		prodotto.setPrezzoTaglia(rs.getBigDecimal("Prezzo"));
		prodotto.setQuantitaDisponibileTaglia(rs.getInt("QuantitaDisponibile"));
        
        return prodotto;
	}
	
	private CarrelloProdottoInOffertaBean creaCarrelloProdottoInOffertaBean(ResultSet rs) throws SQLException {
		
		CarrelloProdottoInOffertaBean prodotto = new CarrelloProdottoInOffertaBean();
		
		prodotto.setIdProdotto(rs.getInt("ID_prodotto"));
        prodotto.setNomeProdotto(rs.getString("Nome"));
        prodotto.setMarcaProdotto(rs.getString("Marca"));
        byte[] Immagine = rs.getBytes("Immagine");
        if(Immagine != null) {
        	prodotto.setImageFromByteArray(Immagine);
        }
        prodotto.setIva(rs.getBigDecimal("Iva"));
		prodotto.setIdTaglia(rs.getInt("ID_ProdottoTaglia"));
		prodotto.setNomeTaglia(rs.getString("NomeTaglia"));
		prodotto.setPrezzoIniziale(rs.getBigDecimal("Prezzo"));
		prodotto.setPercentualeSconto(rs.getBigDecimal("PercentualeSconto"));
		prodotto.setPrezzoTaglia(prodotto.getPrezzoScontato());
		prodotto.setQuantitaDisponibileTaglia(rs.getInt("QuantitaDisponibile"));
        
        return prodotto;
	}
	
}

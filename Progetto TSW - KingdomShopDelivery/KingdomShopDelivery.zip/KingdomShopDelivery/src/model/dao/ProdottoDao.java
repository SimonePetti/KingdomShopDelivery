package model.dao;

import model.dao.interfacce.ProdottoDaoInterfaccia;
import model.beans.ProdottoBean;
import model.beans.ProdottoInOffertaBean;
import model.dao.interfacce.EventoAggiornaDB_DaoInterfaccia;
import model.util.DriverManagerConnectionPool;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collection;
import java.util.LinkedList;


public class ProdottoDao implements ProdottoDaoInterfaccia {
	
	private static final String TABLE_Prodotto = "Prodotto";
	private static final String TABLE_ProdottoTaglia = "Prodotto_Taglia";
	private static final String TABLE_Sconto = "Sconto";
	
	static EventoAggiornaDB_DaoInterfaccia EventoAggiornaDB_Dao = new EventoAggiornaDB_Dao();

	@Override
	public synchronized Collection<ProdottoBean> doRetrieveAll(int numeroProdotti, String ordine) throws SQLException {
		
		Connection connection = null;
	    PreparedStatement preparedStatement = null;
	    
	    Collection<ProdottoBean> prodotti = new LinkedList<ProdottoBean>();
 
	    String selectSQL = "SELECT p.ID_Prodotto, p.Nome, p.Marca, p.Immagine, p.PrezzoMinimo, p.PrezzoMinimoEScontato, p.PrezzoInizialePrezzoMinimo, s.PercentualeSconto, s.DataInizio, s.DataFine "
	    				 + "FROM " + TABLE_Prodotto + " p LEFT JOIN "
	    				 + "(SELECT p1.ID_Prodotto, s1.PercentualeSconto, s1.DataInizio, s1.DataFine "
	    				 	+ "FROM " + TABLE_Prodotto + " p1 "
	    				 	+ "JOIN " + TABLE_Sconto + " s1 ON p1.ID_Prodotto = s1.Prodotto "
	    				 	+ "WHERE (s1.DataInizio <= CURDATE() AND s1.DataFine >= CURDATE() AND p1.PrezzoMinimoEScontato = FALSE) " 
	    				 		+ "OR (s1.DataFine < CURDATE() AND p1.PrezzoMinimoEScontato = TRUE) OR (s1.DataInizio <= CURDATE() AND s1.DataFine >= CURDATE())) AS s ON p.ID_Prodotto = s.ID_Prodotto "
	    				 + "WHERE p.Cancellato = FALSE";
	    
	    if (ordine != null && !ordine.isEmpty()) {
	        selectSQL += " ORDER BY " + ordine;
	    }
	    
	    if(numeroProdotti >= 0) {
	    selectSQL +=  " LIMIT " + numeroProdotti;
	    }
	    
	    try {
	        connection = DriverManagerConnectionPool.getConnection();
	        preparedStatement = connection.prepareStatement(selectSQL);
	        
	        ResultSet rs = preparedStatement.executeQuery();
	        
	        while (rs.next()) {
	        	  	
	        	if(rs.getDate("DataFine") == null) {
	        		
	        		ProdottoBean bean;
		        	Boolean SceltaBean = rs.getBoolean("PrezzoMinimoEScontato");
	        		
	        		if(SceltaBean) {
	        			ProdottoInOffertaBean prodottoInOfferta = this.creaProdottoInOffertaBean(rs);
		        		bean = prodottoInOfferta;
		        	} else {
		        		bean = this.creaProdottoBean(rs);
		        	}
		            prodotti.add(bean);
		            
	        	} else {
	        		Date dataInizio = rs.getDate("DataInizio");
	        		Date dataFine = rs.getDate("DataFine");
                    Date oggi = new Date(System.currentTimeMillis());
                    
	        		if(((dataInizio.before(oggi) || dataInizio.equals(oggi)) && (dataFine.after(oggi) || dataFine.equals(oggi))) && rs.getBoolean("PrezzoMinimoEScontato") == false) {
	        			ProdottoInOffertaBean prodottoAggiornato = EventoAggiornaDB_Dao.getProdottoInOffertaBeanAggiornato(rs.getInt("ID_Prodotto"));
	        			prodotti.add((ProdottoBean) prodottoAggiornato);
	        		} else {
	        			if(dataFine.before(oggi) && rs.getBoolean("PrezzoMinimoEScontato") == true ) {
		        			ProdottoBean prodottoAggiornato = (ProdottoBean) EventoAggiornaDB_Dao.getProdottoBeanAggiornato(rs.getInt("ID_Prodotto"));
		        			prodotti.add(prodottoAggiornato);
		        		} else {
		        			ProdottoBean bean;
				        	Boolean SceltaBean = rs.getBoolean("PrezzoMinimoEScontato");
			        		
			        		if(SceltaBean) {
			        			ProdottoInOffertaBean prodottoInOfferta = this.creaProdottoInOffertaBean(rs);
				        		bean = prodottoInOfferta;
				        	} else {
				        		bean = this.creaProdottoBean(rs);
				        	}
				            prodotti.add(bean);
		        		}
	        		}
	        	}
	        }
	    } finally {
	        if (preparedStatement != null) {
	            preparedStatement.close();
	        }
	        if (connection != null) {
	            DriverManagerConnectionPool.releaseConnection(connection);
	        }
	    }  
	    return prodotti;
	}
	
	@Override
	public synchronized Collection<ProdottoBean> doRetrieveAll(String ordine) throws SQLException {
		Collection<ProdottoBean> prodotti = doRetrieveAll(-1, ordine);
	    return prodotti;
	}
	
	@Override
	public synchronized Collection<ProdottoBean> getProdotti(int numeroProdotti) throws SQLException{
		Connection connection = null;
	    PreparedStatement preparedStatement = null;
	    
	    Collection<ProdottoBean> prodotti = new LinkedList<ProdottoBean>();
	    
	    String selectSQL = "SELECT p.ID_Prodotto, p.Nome, p.Marca, p.Immagine, p.PrezzoMinimo, p.PrezzoMinimoEScontato, p.PrezzoInizialePrezzoMinimo, s.PercentualeSconto, s.DataInizio, s.DataFine "
				 + "FROM " + TABLE_Prodotto + " p LEFT JOIN "
				 + "(SELECT p1.ID_Prodotto, s1.PercentualeSconto, s1.DataInizio, s1.DataFine "
				 	+ "FROM " + TABLE_Prodotto + " p1 "
				 	+ "JOIN " + TABLE_Sconto + " s1 ON p1.ID_Prodotto = s1.Prodotto "
				 	+ "WHERE (s1.DataInizio <= CURDATE() AND s1.DataFine >= CURDATE() AND p1.PrezzoMinimoEScontato = FALSE) " 
				 		+ "OR (s1.DataFine < CURDATE() AND p1.PrezzoMinimoEScontato = TRUE) OR (s1.DataInizio <= CURDATE() AND s1.DataFine >= CURDATE())) AS s ON p.ID_Prodotto = s.ID_Prodotto "
				 + "WHERE p.Cancellato = FALSE";
	    
	    if(numeroProdotti >= 0) {
	    selectSQL +=  " LIMIT " + numeroProdotti;
	    }
	    
	    try {
	        connection = DriverManagerConnectionPool.getConnection();
	        preparedStatement = connection.prepareStatement(selectSQL);
	        
	        ResultSet rs = preparedStatement.executeQuery();

	        while (rs.next()) {
        	  	
	        	if(rs.getDate("DataFine") == null) {
	        		
	        		ProdottoBean bean;
		        	Boolean SceltaBean = rs.getBoolean("PrezzoMinimoEScontato");
	        		
	        		if(SceltaBean) {
	        			ProdottoInOffertaBean prodottoInOfferta = this.creaProdottoInOffertaBean(rs);
		        		bean = prodottoInOfferta;
		        	} else {
		        		bean = this.creaProdottoBean(rs);
		        	}
		            prodotti.add(bean);
		            
	        	} else {
	        		Date dataInizio = rs.getDate("DataInizio");
	        		Date dataFine = rs.getDate("DataFine");
                    Date oggi = new Date(System.currentTimeMillis());
                    
	        		if(((dataInizio.before(oggi) || dataInizio.equals(oggi)) && (dataFine.after(oggi) || dataFine.equals(oggi))) && rs.getBoolean("PrezzoMinimoEScontato") == false) {
	        			ProdottoInOffertaBean prodottoAggiornato = EventoAggiornaDB_Dao.getProdottoInOffertaBeanAggiornato(rs.getInt("ID_Prodotto"));
	        			prodotti.add((ProdottoBean) prodottoAggiornato);
	        		} else {
	        			if(dataFine.before(oggi) && rs.getBoolean("PrezzoMinimoEScontato") == true ) {
		        			ProdottoBean prodottoAggiornato = (ProdottoBean) EventoAggiornaDB_Dao.getProdottoBeanAggiornato(rs.getInt("ID_Prodotto"));
		        			prodotti.add(prodottoAggiornato);
		        		} else {
		        			ProdottoBean bean;
				        	Boolean SceltaBean = rs.getBoolean("PrezzoMinimoEScontato");
			        		
			        		if(SceltaBean) {
			        			ProdottoInOffertaBean prodottoInOfferta = this.creaProdottoInOffertaBean(rs);
				        		bean = prodottoInOfferta;
				        	} else {
				        		bean = this.creaProdottoBean(rs);
				        	}
				            prodotti.add(bean);
		        		}
	        		}
	        	}
	        }
	    } finally {
	        if (preparedStatement != null) {
	            preparedStatement.close();
	        }
	        if (connection != null) {
	            DriverManagerConnectionPool.releaseConnection(connection);
	        }
	    }  
	    return prodotti;
	}
	
	@Override
	public synchronized Collection<ProdottoBean> getProdotti() throws SQLException {
		Collection<ProdottoBean> prodotti = getProdotti(-1);
	    return prodotti;
    }
	
	@Override
	public synchronized Collection<ProdottoBean> getProdottiPiuVenduti(int numeroProdotti) throws SQLException {
		Connection connection = null;
	    PreparedStatement preparedStatement = null;
		
		Collection<ProdottoBean> prodotti = new LinkedList<ProdottoBean>();
		
		String selectSQL = "SELECT p.ID_Prodotto, p.Nome, p.Marca, p.Immagine, p.PrezzoMinimo, p.PrezzoMinimoEScontato, p.PrezzoInizialePrezzoMinimo, s.PercentualeSconto, s.DataInizio, s.DataFine "
				 		 + "FROM " + TABLE_Prodotto + " p LEFT JOIN "
				 		 + "(SELECT p1.ID_Prodotto, s1.PercentualeSconto, s1.DataInizio, s1.DataFine "
				 		 	+ "FROM " + TABLE_Prodotto + " p1 "
				 		 		+ "JOIN " + TABLE_Sconto + " s1 ON p1.ID_Prodotto = s1.Prodotto "
				 		 	+ "WHERE (s1.DataInizio <= CURDATE() AND s1.DataFine >= CURDATE() AND p1.PrezzoMinimoEScontato = FALSE) " 
				 		 		+ "OR (s1.DataFine < CURDATE() AND p1.PrezzoMinimoEScontato = TRUE) OR (s1.DataInizio <= CURDATE() AND s1.DataFine >= CURDATE())) AS s ON p.ID_Prodotto = s.ID_Prodotto "
				 		 		+ "JOIN (SELECT pt2.Prodotto, SUM(ad.QuantitaAcquistata) AS QuantitaVenduta "
				 		 		+ "FROM Acquisto_Dettaglio ad JOIN "
				 		 			+ TABLE_ProdottoTaglia + " pt2 ON ad.ProdottoTaglia = pt2.ID_ProdottoTaglia "
				 		 		+ "GROUP BY pt2.Prodotto) ta ON p.ID_Prodotto = ta.Prodotto "
				 		 + "WHERE p.Cancellato = 0 "
				 		 + "ORDER BY QuantitaVenduta DESC";
		

		if(numeroProdotti >= 0) {
			selectSQL +=  " LIMIT " + numeroProdotti;
		}

		try {
			connection = DriverManagerConnectionPool.getConnection();
			preparedStatement = connection.prepareStatement(selectSQL);
   
			ResultSet rs = preparedStatement.executeQuery();
   
			while (rs.next()) {
        	  	
	        	if(rs.getDate("DataFine") == null) {
	        		
	        		ProdottoBean bean;
		        	Boolean SceltaBean = rs.getBoolean("PrezzoMinimoEScontato");
	        		
	        		if(SceltaBean) {
	        			ProdottoInOffertaBean prodottoInOfferta = this.creaProdottoInOffertaBean(rs);
		        		bean = prodottoInOfferta;
		        	} else {
		        		bean = this.creaProdottoBean(rs);
		        	}
		            prodotti.add(bean);
		            
	        	} else {
	        		Date dataInizio = rs.getDate("DataInizio");
	        		Date dataFine = rs.getDate("DataFine");
                    Date oggi = new Date(System.currentTimeMillis());
                    
	        		if(((dataInizio.before(oggi) || dataInizio.equals(oggi)) && (dataFine.after(oggi) || dataFine.equals(oggi))) && rs.getBoolean("PrezzoMinimoEScontato") == false) {
	        			ProdottoInOffertaBean prodottoAggiornato = EventoAggiornaDB_Dao.getProdottoInOffertaBeanAggiornato(rs.getInt("ID_Prodotto"));
	        			prodotti.add((ProdottoBean) prodottoAggiornato);
	        		} else {
	        			if(dataFine.before(oggi) && rs.getBoolean("PrezzoMinimoEScontato") == true ) {
		        			ProdottoBean prodottoAggiornato = (ProdottoBean) EventoAggiornaDB_Dao.getProdottoBeanAggiornato(rs.getInt("ID_Prodotto"));
		        			prodotti.add(prodottoAggiornato);
		        		} else {
		        			ProdottoBean bean;
				        	Boolean SceltaBean = rs.getBoolean("PrezzoMinimoEScontato");
			        		
			        		if(SceltaBean) {
			        			ProdottoInOffertaBean prodottoInOfferta = this.creaProdottoInOffertaBean(rs);
				        		bean = prodottoInOfferta;
				        	} else {
				        		bean = this.creaProdottoBean(rs);
				        	}
				            prodotti.add(bean);
		        		}
	        		}
	        	}
	        }
		} finally {
			if (preparedStatement != null) {
				preparedStatement.close();
			}
			if (connection != null) {
				DriverManagerConnectionPool.releaseConnection(connection);
			}
		}
		return prodotti;
	}
	
	@Override
	public synchronized Collection<ProdottoBean> getUltimiArrivi(int numeroProdotti) throws SQLException {
		Connection connection = null;
	    PreparedStatement preparedStatement = null;
	    
	    Collection<ProdottoBean> prodotti = new LinkedList<ProdottoBean>();
	    
	    String selectSQL = "SELECT p.ID_Prodotto, p.Nome, p.Marca, p.Immagine, p.PrezzoMinimo, p.PrezzoMinimoEScontato, p.PrezzoInizialePrezzoMinimo, s.PercentualeSconto, s.DataInizio, s.DataFine "
				 + "FROM " + TABLE_Prodotto + " p LEFT JOIN "
				 + "(SELECT p1.ID_Prodotto, s1.PercentualeSconto, s1.DataInizio, s1.DataFine "
				 	+ "FROM " + TABLE_Prodotto + " p1 "
				 	+ "JOIN " + TABLE_Sconto + " s1 ON p1.ID_Prodotto = s1.Prodotto "
				 	+ "WHERE (s1.DataInizio <= CURDATE() AND s1.DataFine >= CURDATE() AND p1.PrezzoMinimoEScontato = FALSE) " 
				 		+ "OR (s1.DataFine < CURDATE() AND p1.PrezzoMinimoEScontato = TRUE) OR (s1.DataInizio <= CURDATE() AND s1.DataFine >= CURDATE())) AS s ON p.ID_Prodotto = s.ID_Prodotto "
				 + "WHERE p.Cancellato = FALSE AND p.DataInserimento >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)";
	    
	    if(numeroProdotti >= 0) {
	    selectSQL +=  " LIMIT " + numeroProdotti;
	    }
	    
	    try {
	        connection = DriverManagerConnectionPool.getConnection();
	        preparedStatement = connection.prepareStatement(selectSQL);
	        
	        ResultSet rs = preparedStatement.executeQuery();
	        
	        while (rs.next()) {
        	  	
	        	if(rs.getDate("DataFine") == null) {
	        		
	        		ProdottoBean bean;
		        	Boolean SceltaBean = rs.getBoolean("PrezzoMinimoEScontato");
	        		
	        		if(SceltaBean) {
	        			ProdottoInOffertaBean prodottoInOfferta = this.creaProdottoInOffertaBean(rs);
		        		bean = prodottoInOfferta;
		        	} else {
		        		bean = this.creaProdottoBean(rs);
		        	}
		            prodotti.add(bean);
		            
	        	} else {
	        		Date dataInizio = rs.getDate("DataInizio");
	        		Date dataFine = rs.getDate("DataFine");
                    Date oggi = new Date(System.currentTimeMillis());
                    
	        		if(((dataInizio.before(oggi) || dataInizio.equals(oggi)) && (dataFine.after(oggi) || dataFine.equals(oggi))) && rs.getBoolean("PrezzoMinimoEScontato") == false) {
	        			ProdottoInOffertaBean prodottoAggiornato = EventoAggiornaDB_Dao.getProdottoInOffertaBeanAggiornato(rs.getInt("ID_Prodotto"));
	        			prodotti.add((ProdottoBean) prodottoAggiornato);
	        		} else {
	        			if(dataFine.before(oggi) && rs.getBoolean("PrezzoMinimoEScontato") == true ) {
		        			ProdottoBean prodottoAggiornato = (ProdottoBean) EventoAggiornaDB_Dao.getProdottoBeanAggiornato(rs.getInt("ID_Prodotto"));
		        			prodotti.add(prodottoAggiornato);
		        		} else {
		        			ProdottoBean bean;
				        	Boolean SceltaBean = rs.getBoolean("PrezzoMinimoEScontato");
			        		
			        		if(SceltaBean) {
			        			ProdottoInOffertaBean prodottoInOfferta = this.creaProdottoInOffertaBean(rs);
				        		bean = prodottoInOfferta;
				        	} else {
				        		bean = this.creaProdottoBean(rs);
				        	}
				            prodotti.add(bean);
		        		}
	        		}
	        	}
	        }
	    } finally {
	        if (preparedStatement != null) {
	            preparedStatement.close();
	        }
	        if (connection != null) {
	            DriverManagerConnectionPool.releaseConnection(connection);
	        }
	    }  
	    return prodotti;
	}
	
	public LinkedList<ProdottoBean> getProdottiCategoria(String Categoria, String SottoCategoria) throws SQLException {
		Connection connection = null;
	    PreparedStatement preparedStatement = null;
	    String condizione_sottocategoria = SottoCategoria.equals("") ? "" : " AND SottoCategoria = ?";
	    
	    LinkedList<ProdottoBean> prodotti = new LinkedList<ProdottoBean>();
	    
	    String selectSQL = "SELECT p.ID_Prodotto, p.Nome, p.Marca, p.Immagine, p.PrezzoMinimo, p.PrezzoMinimoEScontato, p.PrezzoInizialePrezzoMinimo, s.PercentualeSconto, s.DataInizio, s.DataFine "
				 + "FROM " + TABLE_Prodotto + " p LEFT JOIN "
				 + "(SELECT p1.ID_Prodotto, s1.PercentualeSconto, s1.DataInizio, s1.DataFine "
				 	+ "FROM " + TABLE_Prodotto + " p1 "
				 	+ "JOIN " + TABLE_Sconto + " s1 ON p1.ID_Prodotto = s1.Prodotto "
				 	+ "WHERE (s1.DataInizio <= CURDATE() AND s1.DataFine >= CURDATE() AND p1.PrezzoMinimoEScontato = FALSE) " 
				 		+ "OR (s1.DataFine < CURDATE() AND p1.PrezzoMinimoEScontato = TRUE) OR (s1.DataInizio <= CURDATE() AND s1.DataFine >= CURDATE())) AS s ON p.ID_Prodotto = s.ID_Prodotto "
				 + "WHERE p.Cancellato = FALSE AND Categoria = ?" + condizione_sottocategoria;
	    
	    try {
	        connection = DriverManagerConnectionPool.getConnection();
	        preparedStatement = connection.prepareStatement(selectSQL);
	        if(condizione_sottocategoria.equals("")) {
	        	preparedStatement.setString(1,Categoria);
	        } else {
	        	preparedStatement.setString(1,Categoria);
	        	preparedStatement.setString(2, SottoCategoria);
	        }
	        
	        ResultSet rs = preparedStatement.executeQuery();

	        while (rs.next()) {
        	  	
	        	if(rs.getDate("DataFine") == null) {
	        		
	        		ProdottoBean bean;
		        	Boolean SceltaBean = rs.getBoolean("PrezzoMinimoEScontato");
	        		
	        		if(SceltaBean) {
	        			ProdottoInOffertaBean prodottoInOfferta = this.creaProdottoInOffertaBean(rs);
		        		bean = prodottoInOfferta;
		        	} else {
		        		bean = this.creaProdottoBean(rs);
		        	}
		            prodotti.add(bean);
		            
	        	} else {
	        		Date dataInizio = rs.getDate("DataInizio");
	        		Date dataFine = rs.getDate("DataFine");
                    Date oggi = new Date(System.currentTimeMillis());
                    
	        		if(((dataInizio.before(oggi) || dataInizio.equals(oggi)) && (dataFine.after(oggi) || dataFine.equals(oggi))) && rs.getBoolean("PrezzoMinimoEScontato") == false) {
	        			ProdottoInOffertaBean prodottoAggiornato = EventoAggiornaDB_Dao.getProdottoInOffertaBeanAggiornato(rs.getInt("ID_Prodotto"));
	        			prodotti.add((ProdottoBean) prodottoAggiornato);
	        		} else {
	        			if(dataFine.before(oggi) && rs.getBoolean("PrezzoMinimoEScontato") == true ) {
		        			ProdottoBean prodottoAggiornato = (ProdottoBean) EventoAggiornaDB_Dao.getProdottoBeanAggiornato(rs.getInt("ID_Prodotto"));
		        			prodotti.add(prodottoAggiornato);
		        		} else {
		        			ProdottoBean bean;
				        	Boolean SceltaBean = rs.getBoolean("PrezzoMinimoEScontato");
			        		
			        		if(SceltaBean) {
			        			ProdottoInOffertaBean prodottoInOfferta = this.creaProdottoInOffertaBean(rs);
				        		bean = prodottoInOfferta;
				        	} else {
				        		bean = this.creaProdottoBean(rs);
				        	}
				            prodotti.add(bean);
		        		}
	        		}
	        	}
	        }
	    } finally {
	        if (preparedStatement != null) {
	            preparedStatement.close();
	        }
	        if (connection != null) {
	            DriverManagerConnectionPool.releaseConnection(connection);
	        }
	    }  
	    return prodotti;
	}

	
	private ProdottoBean creaProdottoBean(ResultSet rs) throws SQLException {
	
		ProdottoBean prodotto = new ProdottoBean();
		
		prodotto.setId(rs.getInt("ID_prodotto"));
        prodotto.setNome(rs.getString("Nome"));
        prodotto.setMarca(rs.getString("Marca"));
        byte[] Immagine = rs.getBytes("Immagine");
        if(Immagine != null) {
        	prodotto.setImageFromByteArray(Immagine);
        }
        prodotto.setPrezzoMinimo(rs.getBigDecimal("PrezzoMinimo"));
        
        return prodotto;
	}
	
	private ProdottoInOffertaBean creaProdottoInOffertaBean(ResultSet rs) throws SQLException {
		
		ProdottoInOffertaBean prodotto = new ProdottoInOffertaBean();
		
		prodotto.setId(rs.getInt("ID_prodotto"));
        prodotto.setNome(rs.getString("Nome"));
        prodotto.setMarca(rs.getString("Marca"));
        byte[] Immagine = rs.getBytes("Immagine");
        if(Immagine != null) {
        	prodotto.setImageFromByteArray(Immagine);
        }
        prodotto.setPrezzoMinimo(rs.getBigDecimal("PrezzoMinimo"));
        prodotto.setPrezzoIniziale(rs.getBigDecimal("PrezzoInizialePrezzoMinimo"));
        prodotto.setPercentualeSconto(rs.getBigDecimal("PercentualeSconto"));
        
        return prodotto;
	}
	
}
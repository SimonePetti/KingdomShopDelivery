package model.dao;

import model.dao.interfacce.ProdottoInOffertaDaoInterfaccia;
import model.beans.ProdottoBean;
import model.beans.ProdottoInOffertaBean;

import java.util.List;
import java.util.ArrayList;

import model.util.DriverManagerConnectionPool;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


public class ProdottoInOffertaDao extends ProdottoDao implements ProdottoInOffertaDaoInterfaccia {
	
	private static final String TABLE_Prodotto = "Prodotto";
	private static final String TABLE_ProdottoTaglia = "Prodotto_Taglia";
	private static final String TABLE_Sconto = "Sconto";
	
	@Override
	public synchronized List<ProdottoInOffertaBean> getProdottiInOfferta(int numeroProdotti) throws SQLException {
		Connection connection = null;
	    PreparedStatement preparedStatement = null;
	    List<ProdottoInOffertaBean> prodotti = new ArrayList<>();
	    
	    String selectSQL = "SELECT p.ID_Prodotto, p.Nome, p.Marca, p.Immagine, p.PrezzoMinimo, p.PrezzoMinimoEScontato, p.PrezzoInizialePrezzoMinimo, s.PercentualeSconto, s.DataInizio, s.DataFine "
				 + "FROM " + TABLE_Prodotto + " p JOIN "
				 + "(SELECT p1.ID_Prodotto, s1.PercentualeSconto, s1.DataInizio, s1.DataFine "
				 	+ "FROM " + TABLE_Prodotto + " p1 "
				 	+ "JOIN " + TABLE_Sconto + " s1 ON p1.ID_Prodotto = s1.Prodotto "
				 	+ "WHERE (s1.DataInizio <= CURDATE() AND s1.DataFine >= CURDATE() AND p1.PrezzoMinimoEScontato = FALSE) " 
				 		+ "OR (s1.DataFine < CURDATE() AND p1.PrezzoMinimoEScontato = TRUE) OR (s1.DataInizio <= CURDATE() AND s1.DataFine >= CURDATE())) AS s ON p.ID_Prodotto = s.ID_Prodotto "
				 + "WHERE p.Cancellato = FALSE";

	    if(numeroProdotti >= 0) {
	    selectSQL +=  " LIMIT " + numeroProdotti;
	    }
	    
	    try {
	        connection = DriverManagerConnectionPool.getConnection();
	        preparedStatement = connection.prepareStatement(selectSQL);
	        
	        ResultSet rs = preparedStatement.executeQuery();
	        
	        while (rs.next()) {
        	  	
	        	if(rs.getDate("DataFine") == null) {
		            
	        	} else {
	        		Date dataInizio = rs.getDate("DataInizio");
	        		Date dataFine = rs.getDate("DataFine");
                    Date oggi = new Date(System.currentTimeMillis());
                    
	        		if(((dataInizio.before(oggi) || dataInizio.equals(oggi)) && (dataFine.after(oggi) || dataFine.equals(oggi))) && rs.getBoolean("PrezzoMinimoEScontato") == false) {
	        			ProdottoInOffertaBean prodottoAggiornato = EventoAggiornaDB_Dao.getProdottoInOffertaBeanAggiornato(rs.getInt("ID_Prodotto"));
	        			prodotti.add(prodottoAggiornato);
	        		} else {
	        			if(dataFine.before(oggi) && rs.getBoolean("PrezzoMinimoEScontato") == true ) {
		        			EventoAggiornaDB_Dao.eliminaScontoProdotto(rs.getInt("ID_Prodotto"));
		        		} else {
			        		ProdottoInOffertaBean prodottoInOfferta = this.creaProdottoInOffertaBean(rs);
				            prodotti.add(prodottoInOfferta);
		        		}
	        		}
	        	}
	        }
	    } finally {
	        if (preparedStatement != null) {
	            preparedStatement.close();
	        }
	        if (connection != null) {
	            DriverManagerConnectionPool.releaseConnection(connection);
	        }
	    }
	    return prodotti;
    }
	
	@Override
	public synchronized List<ProdottoInOffertaBean> getProdottiInOfferta() throws SQLException {
	    List<ProdottoInOffertaBean> prodotti = getProdottiInOfferta(-1);
	    return prodotti;
    }
	
	private ProdottoInOffertaBean creaProdottoInOffertaBean(ResultSet rs) throws SQLException {
		
		ProdottoInOffertaBean prodotto = new ProdottoInOffertaBean();
		
		prodotto.setId(rs.getInt("ID_prodotto"));
        prodotto.setNome(rs.getString("Nome"));
        prodotto.setMarca(rs.getString("Marca"));
        byte[] Immagine = rs.getBytes("Immagine");
        if(Immagine != null) {
        	prodotto.setImageFromByteArray(Immagine);
        }
        prodotto.setPrezzoMinimo(rs.getBigDecimal("PrezzoMinimo"));
        prodotto.setPrezzoIniziale(rs.getBigDecimal("PrezzoInizialePrezzoMinimo"));
        prodotto.setPercentualeSconto(rs.getBigDecimal("PercentualeSconto"));
        
        return prodotto;
	}
	
}
package model.dao;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.LinkedList;

import model.beans.IndirizzoBean;
import model.beans.OrdineDettagliBean;
import model.beans.OrdineProdottoDettagliBean;
import model.dao.interfacce.IndirizzoDaoInterfaccia;
import model.util.DriverManagerConnectionPool;


public class IndirizzoDao implements IndirizzoDaoInterfaccia {
	
	private static final String TABLE_Indirizzo = "Indirizzo";
	private static final String TABLE_Utente_IndirizzoCompleto = "Utente_IndirizzoCompleto";
	
	public synchronized LinkedList<IndirizzoBean> getIndirizzi(int id_utente) throws SQLException {
		
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		LinkedList<IndirizzoBean> indirizzi = new LinkedList<IndirizzoBean>();

		String selectSQL = "SELECT ID_Indirizzo, Paese, Provincia, Citta, Via, CAP, Civico, Nome, Cognome, Tipo "
						 + "FROM " + TABLE_Indirizzo + " "
						 + "WHERE Utente = ? "
						 + "ORDER BY DataInserimento DESC";
		
		try {
			connection = DriverManagerConnectionPool.getConnection();
			
			preparedStatement = connection.prepareStatement(selectSQL);
			
			preparedStatement.setInt(1, id_utente);
			
			ResultSet rs = preparedStatement.executeQuery();

			while(rs.next()) {
				
				IndirizzoBean indirizzo = new IndirizzoBean();
				
				indirizzo.setIdIndirizzo(rs.getInt("ID_Indirizzo"));
				indirizzo.setNome(rs.getString("Nome"));
                indirizzo.setCognome(rs.getString("Cognome"));
                indirizzo.setPaese(rs.getString("Paese"));
                indirizzo.setProvincia(rs.getString("Provincia"));
                indirizzo.setCitta(rs.getString("Citta"));
                indirizzo.setVia(rs.getString("Via"));
                indirizzo.setCap(rs.getString("CAP"));
                indirizzo.setCivico(rs.getString("Civico"));
                indirizzo.setTipo(rs.getString("Tipo"));
                
                indirizzi.add(indirizzo);
			}

		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				DriverManagerConnectionPool.releaseConnection(connection);
			}
		}
		return indirizzi;	
	}
	
	public synchronized void getIndirizzi(int id_utente, LinkedList<IndirizzoBean> indirizzi_spedizione, LinkedList<IndirizzoBean> indirizzi_fatturazione) throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;

		String selectSQL = "SELECT ID_Indirizzo, Paese, Provincia, Citta, Via, CAP, Civico, Nome, Cognome, Tipo "
						 + "FROM " + TABLE_Indirizzo + " "
						 + "WHERE Utente = ? "
						 + "ORDER BY DataInserimento DESC";
		
		try {
			connection = DriverManagerConnectionPool.getConnection();
			
			preparedStatement = connection.prepareStatement(selectSQL);
			
			preparedStatement.setInt(1, id_utente);
			
			ResultSet rs = preparedStatement.executeQuery();

			while(rs.next()) {
				
				Boolean is_Spedizione = false;
				Boolean is_Fatturazione = false;
				
				switch(rs.getString("Tipo")) {
					case "Spedizione" : is_Spedizione = true; break;
					case "Fatturazione" : is_Fatturazione = true; break;
					case "Spedizione-Fatturazione" : is_Spedizione = true; is_Fatturazione = true; break;
				}
                
                if(is_Spedizione) {
                	
                	IndirizzoBean indirizzo_spedizione = new IndirizzoBean();
    				
    				indirizzo_spedizione.setIdIndirizzo(rs.getInt("ID_Indirizzo"));
    				indirizzo_spedizione.setNome(rs.getString("Nome"));
                    indirizzo_spedizione.setCognome(rs.getString("Cognome"));
                    indirizzo_spedizione.setPaese(rs.getString("Paese"));
                    indirizzo_spedizione.setProvincia(rs.getString("Provincia"));
                    indirizzo_spedizione.setCitta(rs.getString("Citta"));
                    indirizzo_spedizione.setVia(rs.getString("Via"));
                    indirizzo_spedizione.setCap(rs.getString("CAP"));
                    indirizzo_spedizione.setCivico(rs.getString("Civico"));
                    indirizzo_spedizione.setTipo("Spedizione");
                    
                    indirizzi_spedizione.add(indirizzo_spedizione);
                } 
                
                if(is_Fatturazione) {
                	IndirizzoBean indirizzo_fatturazione = new IndirizzoBean();
    				
    				indirizzo_fatturazione.setIdIndirizzo(rs.getInt("ID_Indirizzo"));
    				indirizzo_fatturazione.setNome(rs.getString("Nome"));
                    indirizzo_fatturazione.setCognome(rs.getString("Cognome"));
                    indirizzo_fatturazione.setPaese(rs.getString("Paese"));
                    indirizzo_fatturazione.setProvincia(rs.getString("Provincia"));
                    indirizzo_fatturazione.setCitta(rs.getString("Citta"));
                    indirizzo_fatturazione.setVia(rs.getString("Via"));
                    indirizzo_fatturazione.setCap(rs.getString("CAP"));
                    indirizzo_fatturazione.setCivico(rs.getString("Civico"));
                    indirizzo_fatturazione.setTipo("Fatturazione");
                    
                    indirizzi_fatturazione.add(indirizzo_fatturazione);
                }
			}

		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				DriverManagerConnectionPool.releaseConnection(connection);
			}
		}
	}
	
	
	public synchronized String aggiungiIndirizzo(int id_utente, IndirizzoBean indirizzo) throws SQLException {
		
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		String messaggioRedirect;
		
		String selectSQL = "SELECT Tipo "
	   			  				   + "FROM " + TABLE_Indirizzo + " "
	                               + "WHERE Utente = ? AND LOWER(Paese) = LOWER(?) AND LOWER(Provincia) = LOWER(?) AND LOWER(Citta) = LOWER(?) AND LOWER(Via) = LOWER(?) AND CAP = ? AND Civico = ? AND LOWER(Nome) = LOWER(?) AND LOWER(Cognome) = LOWER(?)";
		
		try {
			connection = DriverManagerConnectionPool.getConnection();
			
			preparedStatement = connection.prepareStatement(selectSQL);
			
			preparedStatement.setInt(1, id_utente);
			preparedStatement.setString(2, indirizzo.getPaese());
            preparedStatement.setString(3, indirizzo.getProvincia());
            preparedStatement.setString(4, indirizzo.getCitta());
            preparedStatement.setString(5, indirizzo.getVia());
            preparedStatement.setString(6, indirizzo.getCap());
            preparedStatement.setString(7, indirizzo.getCivico());
            preparedStatement.setString(8, indirizzo.getNome());
            preparedStatement.setString(9, indirizzo.getCognome());
			
			ResultSet rs = preparedStatement.executeQuery();
			
			if(rs.next()) {
				//L'indirizzo esiste
				String tipo_attuale = rs.getString("Tipo");
				String tipo_da_aggiungere = indirizzo.getTipo();
				
				if(tipo_attuale.equals(tipo_da_aggiungere) || tipo_attuale.equals("Spedizione-Fatturazione")) {
					messaggioRedirect="?inserimento=giaPresente";
				} else {
					
					PreparedStatement preparedStatement1 = null;
					
					String updateSQL = "UPDATE " + TABLE_Indirizzo + " "
									 + "SET Tipo = 'Spedizione-Fatturazione' "
							         + "WHERE Utente = ? AND LOWER(Paese) = LOWER(?) AND LOWER(Provincia) = LOWER(?) AND LOWER(Citta) = LOWER(?) AND LOWER(Via) = LOWER(?) AND CAP = ? AND Civico = ? AND LOWER(Nome) = LOWER(?) AND LOWER(Cognome) = LOWER(?)";
					preparedStatement1 = connection.prepareStatement(updateSQL);
					
					preparedStatement1.setInt(1, id_utente);
					preparedStatement1.setString(2, indirizzo.getPaese());
		            preparedStatement1.setString(3, indirizzo.getProvincia());
		            preparedStatement1.setString(4, indirizzo.getCitta());
		            preparedStatement1.setString(5, indirizzo.getVia());
		            preparedStatement1.setString(6, indirizzo.getCap());
		            preparedStatement1.setString(7, indirizzo.getCivico());
		            preparedStatement1.setString(8, indirizzo.getNome());
		            preparedStatement1.setString(9, indirizzo.getCognome());
		            
		            preparedStatement1.executeUpdate();
		            
		            connection.commit();
		            messaggioRedirect="?inserimento=successo";
				}
				
			} else {
				
				PreparedStatement preparedStatement2 = null;
				
				String insertSQL = "INSERT INTO " + TABLE_Indirizzo + "(Utente,Paese,Provincia,Citta,Via,CAP,Civico,Nome,Cognome,Tipo) VALUES(?,?,?,?,?,?,?,?,?,?)";
				
				preparedStatement2 = connection.prepareStatement(insertSQL);
				
				preparedStatement2.setInt(1, id_utente);
				preparedStatement2.setString(2, indirizzo.getPaese());
	            preparedStatement2.setString(3, indirizzo.getProvincia());
	            preparedStatement2.setString(4, indirizzo.getCitta());
	            preparedStatement2.setString(5, indirizzo.getVia());
	            preparedStatement2.setString(6, indirizzo.getCap());
	            preparedStatement2.setString(7, indirizzo.getCivico());
	            preparedStatement2.setString(8, indirizzo.getNome());
	            preparedStatement2.setString(9, indirizzo.getCognome());
	            preparedStatement2.setString(10, indirizzo.getTipo());
				
	            preparedStatement2.executeUpdate();				
				
				connection.commit();
				messaggioRedirect="?inserimento=successo";
			}

		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				DriverManagerConnectionPool.releaseConnection(connection);
			}
		}
		return messaggioRedirect;
	}
	
	public synchronized String modificaIndirizzo(int id_utente, IndirizzoBean indirizzo, int id_indirizzo) throws SQLException {
		
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		String messaggioRedirect;
		
		String selectSQL = "SELECT * FROM " + TABLE_Indirizzo + " WHERE Utente = ? AND ID_Indirizzo = ?";
		
		
		try {
			connection = DriverManagerConnectionPool.getConnection();
			
			preparedStatement = connection.prepareStatement(selectSQL);
			
			preparedStatement.setInt(1, id_utente);
			preparedStatement.setInt(2, id_indirizzo);
			
			ResultSet rs = preparedStatement.executeQuery();
			
			if(rs.next()) {
				//L'indirizzo esiste
				
				PreparedStatement preparedStatement1 = null;
				
				String selectSQL1 = "SELECT ID_Indirizzo, Tipo "
		  				         + "FROM " + TABLE_Indirizzo + " "
                                 + "WHERE Utente = ? AND ID_Indirizzo <> ? AND LOWER(Paese) = LOWER(?) AND LOWER(Provincia) = LOWER(?) AND LOWER(Citta) = LOWER(?) AND LOWER(Via) = LOWER(?) AND CAP = ? AND Civico = ? AND LOWER(Nome) = LOWER(?) AND LOWER(Cognome) = LOWER(?)";

				preparedStatement1 = connection.prepareStatement(selectSQL1);
				
				preparedStatement1.setInt(1, id_utente);
				preparedStatement1.setInt(2, id_indirizzo);
				preparedStatement1.setString(3, indirizzo.getPaese());
	            preparedStatement1.setString(4, indirizzo.getProvincia());
	            preparedStatement1.setString(5, indirizzo.getCitta());
	            preparedStatement1.setString(6, indirizzo.getVia());
	            preparedStatement1.setString(7, indirizzo.getCap());
	            preparedStatement1.setString(8, indirizzo.getCivico());
	            preparedStatement1.setString(9, indirizzo.getNome());
	            preparedStatement1.setString(10, indirizzo.getCognome());
	            
	            ResultSet rs1 = preparedStatement1.executeQuery();
	            
	            int id_indirizzo_da_aggiornare = id_indirizzo;
	            String tipo_nuovo = indirizzo.getTipo();
	            messaggioRedirect = "?modifica=successo";
	            
	            if(rs1.next()) {

	            	id_indirizzo_da_aggiornare = rs1.getInt("ID_Indirizzo");
	            	String tipo_gia_esistente = rs1.getString("Tipo");
	            	
	            	if(tipo_gia_esistente.equals(indirizzo.getTipo()) || tipo_gia_esistente.equals("Spedizione-Fatturazione")) {
						messaggioRedirect="?modifica=indirizzoGiaPresente";
						return messaggioRedirect;
					} else {
						tipo_nuovo = "Spedizione-Fatturazione";
					}
	            }
				
	            PreparedStatement preparedStatement2 = null;
	            
				String updateSQL = "UPDATE " + TABLE_Indirizzo + " "
						 		 + "SET Paese = ?, Provincia = ?, Citta = ?, Via = ?, CAP = ?, Civico = ?, Nome = ?, Cognome = ?, Tipo = ? "
				                 + "WHERE Utente = ? AND ID_Indirizzo = ?";
					
				preparedStatement2 = connection.prepareStatement(updateSQL);
					
				preparedStatement2.setString(1, indirizzo.getPaese());
	            preparedStatement2.setString(2, indirizzo.getProvincia());
	            preparedStatement2.setString(3, indirizzo.getCitta());
	            preparedStatement2.setString(4, indirizzo.getVia());
	            preparedStatement2.setString(5, indirizzo.getCap());
	            preparedStatement2.setString(6, indirizzo.getCivico());
	            preparedStatement2.setString(7, indirizzo.getNome());
	            preparedStatement2.setString(8, indirizzo.getCognome());
	            preparedStatement2.setString(9, tipo_nuovo);
				preparedStatement2.setInt(10, id_utente);
				preparedStatement2.setInt(11, id_indirizzo_da_aggiornare);
		            
		        preparedStatement2.executeUpdate();
		        
		        if(id_indirizzo != id_indirizzo_da_aggiornare) {
		        	PreparedStatement preparedStatement3 = null;
		        	
		        	String deleteSQL = "DELETE FROM " + TABLE_Indirizzo + " WHERE ID_Indirizzo = ?";
		        	
		        	preparedStatement3 = connection.prepareStatement(deleteSQL);
		        	
		        	preparedStatement3.setInt(1, id_indirizzo);
		        	
		        	preparedStatement3.executeUpdate();
		        } 
		        connection.commit();
				
			} else {
				messaggioRedirect="?modifica=indirizzoAssente";
			}

		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				DriverManagerConnectionPool.releaseConnection(connection);
			}
		}
		return messaggioRedirect;
	}
	
	public synchronized String eliminaIndirizzo(int id_utente, int id_indirizzo) throws SQLException {
		
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		String messaggioRedirect = "";

		String deleteSQL = "DELETE FROM " + TABLE_Indirizzo + " WHERE Utente = ? AND ID_Indirizzo = ?";
		
		try {
			connection = DriverManagerConnectionPool.getConnection();
			
			preparedStatement = connection.prepareStatement(deleteSQL);
			
			preparedStatement.setInt(1, id_utente);
			preparedStatement.setInt(2, id_indirizzo);
			
			preparedStatement.executeUpdate();
			messaggioRedirect = "?eliminazione=successo";

		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				DriverManagerConnectionPool.releaseConnection(connection);
			}
		}
		return messaggioRedirect;
	}

}

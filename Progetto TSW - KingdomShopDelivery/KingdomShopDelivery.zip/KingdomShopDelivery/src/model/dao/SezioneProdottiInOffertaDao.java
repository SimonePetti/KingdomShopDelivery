package model.dao;

import model.dao.interfacce.SezioneProdottiInOffertaDaoInterfaccia;

public class SezioneProdottiInOffertaDao extends ProdottoInOffertaDao implements SezioneProdottiInOffertaDaoInterfaccia {
		
}

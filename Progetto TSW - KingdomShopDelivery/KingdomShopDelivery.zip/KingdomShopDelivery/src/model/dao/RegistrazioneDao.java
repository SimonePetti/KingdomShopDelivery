package model.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import model.beans.ProdottoInOffertaBean;
import model.dao.interfacce.RegistrazioneDaoInterfaccia;
import model.util.DriverManagerConnectionPool;

public class RegistrazioneDao implements RegistrazioneDaoInterfaccia {

	private static final String TABLE_Utente = "Utente";
	
	@Override
	public synchronized Boolean doSave(String nome, String cognome, String email, String password, int prefissoTelefono, long numeroTelefono) throws SQLException {
		Connection connection = null;
	    PreparedStatement preparedStatement = null;
	    Boolean insertSuccesso = false;
	    
	    String insertSQL = "INSERT INTO " + TABLE_Utente + "(Nome,Cognome,Email,Password,Tipo,PrefissoTelefono,NumeroTelefono) " 
	    				 + "VALUES(?,?,?,?,'utente',?,?)";
	
	    try {
	        connection = DriverManagerConnectionPool.getConnection();
	        preparedStatement = connection.prepareStatement(insertSQL);
	        
	        preparedStatement.setString(1, nome);
	        preparedStatement.setString(2, cognome);
	        preparedStatement.setString(3, email);
	        preparedStatement.setString(4, password);
	        preparedStatement.setInt(5, prefissoTelefono);
	        preparedStatement.setLong(6, numeroTelefono);
	        
	        preparedStatement.executeUpdate();
	        
	        connection.commit();
	        
	        insertSuccesso = true;
	        
	    } finally {
	        if (preparedStatement != null) {
	            preparedStatement.close();
	        }
	        if (connection != null) {
	            DriverManagerConnectionPool.releaseConnection(connection);
	        }
	    }
	    return insertSuccesso;
	}
	
	
	@Override
	public synchronized Boolean ControllaEmail(String email) throws SQLException {
		
		Connection connection = null;
	    PreparedStatement preparedStatement = null;
	    Boolean emailPresente = true;
	    
	    String selectSQL = "SELECT Email "
	    				 + "FROM " + TABLE_Utente + " "
	    				 + "WHERE Email = ?"; 
	    
	    try {
	        connection = DriverManagerConnectionPool.getConnection();
	        preparedStatement = connection.prepareStatement(selectSQL);
	        
	        preparedStatement.setString(1, email);
	        
	        ResultSet rs = preparedStatement.executeQuery();
	        
	        if(rs.next()) {
	        	emailPresente = true;
	        } else {
	        	emailPresente = false;
	        }
	        
	    } finally {
	        if (preparedStatement != null) {
	            preparedStatement.close();
	        }
	        if (connection != null) {
	            DriverManagerConnectionPool.releaseConnection(connection);
	        }
	    }
	    return emailPresente;    
	}
	
}

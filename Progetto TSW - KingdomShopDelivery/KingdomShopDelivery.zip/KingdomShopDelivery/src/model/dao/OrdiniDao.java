package model.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.LinkedList;
import java.io.InputStream;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.Date;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;

import model.dao.interfacce.OrdiniDaoInterfaccia;
import model.dao.OrdiniDao;
import model.beans.Admin_ProdottoDaAggiungereBean;
import model.beans.Admin_ProdottoDaModificareBean;
import model.beans.Admin_ProdottoTagliaDaModificareBean;
import model.beans.ConfermaOrdineBean;
import model.beans.OrdineBean;
import model.beans.OrdineDettagliBean;
import model.beans.OrdineProdottoBean;
import model.beans.OrdineProdottoDettagliBean;
import model.beans.ProdottoBean;
import model.beans.ProdottoInOffertaBean;
import model.dao.interfacce.OrdiniDaoInterfaccia;
import model.util.DriverManagerConnectionPool;

public class OrdiniDao implements OrdiniDaoInterfaccia {

	private static final String TABLE_Prodotto = "Prodotto";
	private static final String TABLE_ProdottoTaglia = "Prodotto_Taglia";
	private static final String TABLE_Sconto = "Sconto";
	private static final String TABLE_Acquisto = "Acquisto";
	private static final String TABLE_AcquistoDettagli = "Acquisto_Dettaglio";
	private static final String TABLE_Fattura = "Fattura";
	private static final String TABLE_Indirizzo = "Indirizzo";
	private static final String TABLE_Carrello = "Carrello";
	
	public synchronized LinkedList<OrdineBean> getOrdini(int id_utente) throws SQLException {
			
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		HashMap<Integer, OrdineBean> ordiniMap = new HashMap<>();
        LinkedList<OrdineBean> ordiniList = new LinkedList<>();

		String selectSQL = "SELECT a.ID_Acquisto, a.DataAcquisto, a.DataConsegna, pt.ID_ProdottoTaglia, p.ID_Prodotto, ad.QuantitaAcquistata, ad.PrezzoSingolo, p.Nome, p.Marca, pt.NomeTaglia, p.Immagine "
						 + "FROM " + TABLE_Acquisto + " a JOIN " + TABLE_AcquistoDettagli + " ad ON a.ID_Acquisto = ad.Acquisto "
						 		   + "JOIN " + TABLE_ProdottoTaglia + " pt ON ad.ProdottoTaglia = pt.ID_ProdottoTaglia "
						 		   + "JOIN " + TABLE_Prodotto + " p ON pt.Prodotto = p.ID_Prodotto "
						 + "WHERE a.Utente = ? "
						 + "ORDER BY a.DataAcquisto DESC";
		
		try {
			connection = DriverManagerConnectionPool.getConnection();
			
			preparedStatement = connection.prepareStatement(selectSQL);
			
			preparedStatement.setInt(1, id_utente);
			
			ResultSet rs = preparedStatement.executeQuery();

	        while (rs.next()) {
	            int idAcquisto = rs.getInt("ID_Acquisto");

	            OrdineBean ordine;
	            if (ordiniMap.containsKey(idAcquisto)) {
	                ordine = ordiniMap.get(idAcquisto);
	            } else {
	                ordine = new OrdineBean();
	                ordine.setNumeroOrdine(idAcquisto);
	                ordine.setDataAcquisto(rs.getDate("DataAcquisto").toLocalDate());
	                LocalDate dataConsegna = (rs.getDate("DataConsegna") != null) ? rs.getDate("DataConsegna").toLocalDate() : null;
	                ordine.setDataConsegna(dataConsegna);
	                ordiniMap.put(idAcquisto, ordine);
	                ordiniList.add(ordine);
	            }

	            OrdineProdottoBean prodotto = new OrdineProdottoBean();
	            prodotto.setIdProdotto(rs.getInt("ID_Prodotto"));
	            prodotto.setIdTaglia(rs.getInt("ID_ProdottoTaglia"));
	            prodotto.setNome(rs.getString("Nome"));
	            prodotto.setMarca(rs.getString("Marca"));
	            prodotto.setNomeTaglia(rs.getString("NomeTaglia"));
	            prodotto.setImmagine(rs.getBinaryStream("Immagine"));
	            
	            int quantita = rs.getInt("QuantitaAcquistata");
	            BigDecimal prezzoSingolo = rs.getBigDecimal("PrezzoSingolo");
	            BigDecimal totaleProdotto = prezzoSingolo.multiply(BigDecimal.valueOf(quantita));

	            ordine.setProdotto(prodotto);
	            ordine.aggiungiAlTotale(totaleProdotto);
	        }

		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				DriverManagerConnectionPool.releaseConnection(connection);
			}
		}
		return ordiniList;
	}
	
	public Boolean isIn(int id_utente, int numero_ordine) throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		
		Boolean ordine_trovato = false;

		String selectSQL = "SELECT ID_Acquisto "
						 + "FROM " + TABLE_Acquisto + " "
						 + "WHERE ID_Acquisto = ? AND Utente = ?";
		
		String selectSQL1 = "SELECT * FROM " + TABLE_Acquisto + "";

		try {
			connection = DriverManagerConnectionPool.getConnection();
			preparedStatement = connection.prepareStatement(selectSQL);
			preparedStatement.setInt(1, numero_ordine);
			preparedStatement.setInt(2, id_utente);

			ResultSet rs = preparedStatement.executeQuery();
			
			if(rs.next()) {
				ordine_trovato = true;
			} else {
				ordine_trovato = false;
			}
			
			PreparedStatement p2 = connection.prepareStatement(selectSQL1);
			
			ResultSet rs1 = p2.executeQuery();

		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				DriverManagerConnectionPool.releaseConnection(connection);
			}
		}
	return ordine_trovato;
	}
	
	public synchronized OrdineDettagliBean getDettagliOrdine(int numero_ordine) throws SQLException {
		
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		OrdineDettagliBean ordine_dettagli = new OrdineDettagliBean();
		
		String selectSQL = "SELECT a.ID_Acquisto, a.NomeCitofono, a.CognomeCitofono, a.Paese, a.Provincia, a.Citta, a.Via, a.CAP, a.Civico, a.DataAcquisto, a.DataConsegna, a.NoteSpedizione, ad.QuantitaAcquistata, ad.PrezzoSingolo, ad.Iva, pt.ID_ProdottoTaglia, pt.NomeTaglia, p.ID_Prodotto, p.Nome, p.Marca, p.Immagine, f.NomeCliente, f.CognomeCliente, f.PaeseCliente, f.ProvinciaCliente, f.CittaCliente, f.ViaCliente, f.CAPCliente, f.CivicoCliente "
						 + "FROM " + TABLE_Acquisto + " a JOIN " + TABLE_AcquistoDettagli + " ad ON a.ID_Acquisto = ad.Acquisto "
						 		   + "JOIN " + TABLE_Fattura + " f ON a.ID_Acquisto = f.Acquisto "
						 		   + "JOIN " + TABLE_ProdottoTaglia + " pt ON ad.ProdottoTaglia = pt.ID_ProdottoTaglia "
						 		   + "JOIN " + TABLE_Prodotto + " p ON pt.Prodotto = p.ID_Prodotto "
						 + "WHERE a.ID_Acquisto = ?";
		
		try {
			connection = DriverManagerConnectionPool.getConnection();
			
			preparedStatement = connection.prepareStatement(selectSQL);
			
			preparedStatement.setInt(1, numero_ordine);
			
			ResultSet rs = preparedStatement.executeQuery();
			
			if(rs.next()) {
				
                ordine_dettagli.setNumeroOrdine(rs.getInt("ID_Acquisto"));
                Date dataAcquistoDate = rs.getDate("DataAcquisto");
                if (dataAcquistoDate != null) {
                    LocalDate dataAcquisto = dataAcquistoDate.toLocalDate();
                    ordine_dettagli.setDataAcquisto(dataAcquisto);
                } else {
                    ordine_dettagli.setDataAcquisto(null);
                }
                LocalDate dataConsegna = (rs.getDate("DataConsegna") != null) ? rs.getDate("DataConsegna").toLocalDate() : null;
                ordine_dettagli.setDataConsegna(dataConsegna);
                
                ordine_dettagli.setNomeCliente(rs.getString("NomeCitofono"));
                ordine_dettagli.setCognomeCliente(rs.getString("CognomeCitofono"));
                ordine_dettagli.setPaeseCliente(rs.getString("Paese"));
                ordine_dettagli.setProvinciaCliente(rs.getString("Provincia"));
                ordine_dettagli.setCittaCliente(rs.getString("Citta"));
                ordine_dettagli.setViaCliente(rs.getString("Via"));
                ordine_dettagli.setCapCliente(rs.getString("CAP"));
                ordine_dettagli.setCivicoCliente(rs.getString("Civico"));
                ordine_dettagli.setNoteSpedizione(rs.getString("NoteSpedizione"));
                
                ordine_dettagli.setFatturaNomeCliente(rs.getString("NomeCliente"));
                ordine_dettagli.setFatturaCognomeCliente(rs.getString("CognomeCliente"));
                ordine_dettagli.setFatturaPaeseCliente(rs.getString("PaeseCliente"));
                ordine_dettagli.setFatturaProvinciaCliente(rs.getString("ProvinciaCliente"));
                ordine_dettagli.setFatturaCittaCliente(rs.getString("CittaCliente"));
                ordine_dettagli.setFatturaViaCliente(rs.getString("ViaCliente"));
                ordine_dettagli.setFatturaCapCliente(rs.getString("CAPCliente"));
                ordine_dettagli.setFatturaCivicoCliente(rs.getString("CivicoCliente"));
                
                OrdineProdottoDettagliBean prodotto1 = new OrdineProdottoDettagliBean();
	            prodotto1.setIdProdotto(rs.getInt("ID_Prodotto"));
	            prodotto1.setIdTaglia(rs.getInt("ID_ProdottoTaglia"));
	            prodotto1.setNome(rs.getString("Nome"));
	            prodotto1.setMarca(rs.getString("Marca"));
	            prodotto1.setNomeTaglia(rs.getString("NomeTaglia"));
	            prodotto1.setImmagine(rs.getBinaryStream("Immagine"));
	            prodotto1.setQuantitaAcquistata(rs.getInt("QuantitaAcquistata"));
	            prodotto1.setPrezzoSingolo(rs.getBigDecimal("PrezzoSingolo"));
	            prodotto1.setIva(rs.getBigDecimal("Iva"));
	            
	            int quantita1 = rs.getInt("QuantitaAcquistata");
	            BigDecimal prezzoSingolo1 = rs.getBigDecimal("PrezzoSingolo");
	            BigDecimal totaleProdotto1 = prezzoSingolo1.multiply(BigDecimal.valueOf(quantita1));

	            ordine_dettagli.setProdotto(prodotto1);
	            ordine_dettagli.aggiungiAlTotale(totaleProdotto1);
            
                while (rs.next()) {

    	            OrdineProdottoDettagliBean prodotto = new OrdineProdottoDettagliBean();
    	            prodotto.setIdProdotto(rs.getInt("ID_Prodotto"));
    	            prodotto.setIdTaglia(rs.getInt("ID_ProdottoTaglia"));
    	            prodotto.setNome(rs.getString("Nome"));
    	            prodotto.setMarca(rs.getString("Marca"));
    	            prodotto.setNomeTaglia(rs.getString("NomeTaglia"));
    	            prodotto.setImmagine(rs.getBinaryStream("Immagine"));
    	            prodotto.setQuantitaAcquistata(rs.getInt("QuantitaAcquistata"));
    	            prodotto.setPrezzoSingolo(rs.getBigDecimal("PrezzoSingolo"));
    	            prodotto.setIva(rs.getBigDecimal("Iva"));
    	            
    	            int quantita = rs.getInt("QuantitaAcquistata");
    	            BigDecimal prezzoSingolo = rs.getBigDecimal("PrezzoSingolo");
    	            BigDecimal totaleProdotto = prezzoSingolo.multiply(BigDecimal.valueOf(quantita));

    	            ordine_dettagli.setProdotto(prodotto);
    	            ordine_dettagli.aggiungiAlTotale(totaleProdotto);
    	        }
			}

		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				DriverManagerConnectionPool.releaseConnection(connection);
			}
		}
		return ordine_dettagli;	
	}
	
	public synchronized void finalizzaAcquisto(int id_utente, ConfermaOrdineBean ordine) throws SQLException {
		Connection connection = null;
		PreparedStatement p = null;
		ResultSet resultSet = null;
		long generatedKey = -1;
		
		String insertSQL = "INSERT INTO " + TABLE_Acquisto + " (Utente,NomeCitofono,CognomeCitofono,Paese,Provincia,Citta,Via,CAP,Civico,NoteSpedizione) VALUES(?,?,?,?,?,?,?,?,?,?)";
		
		String selectSQL = "SELECT * FROM " + TABLE_Indirizzo + " WHERE ID_Indirizzo = ? AND Utente = ?";
		
		String selectSQL1 = "SELECT * FROM " + TABLE_Indirizzo + " WHERE ID_Indirizzo = ? AND Utente = ?";
		
		try {
			connection = DriverManagerConnectionPool.getConnection();
			
			p = connection.prepareStatement(selectSQL);
			p.setInt(1, ordine.getIdIndirizzoSpedizione());
			p.setInt(2, id_utente);
			
			ResultSet rs = p.executeQuery();
			
			String nome_is = "";
			String cognome_is = "";
			String paese_is = "";
			String provincia_is = "";
			String citta_is = "";
			String via_is = "";
			String cap_is = "";
			String civico_is = "";
			
			
			while(rs.next()) {
				nome_is = rs.getString("Nome");
				cognome_is = rs.getString("Cognome");
				paese_is = rs.getString("Paese");
				provincia_is = rs.getString("Provincia");
				citta_is = rs.getString("Citta");
				via_is = rs.getString("Via");
				civico_is = rs.getString("Civico");
				cap_is = rs.getString("CAP");
			}
			
			PreparedStatement p1 = null;
			
			p1 = connection.prepareStatement(selectSQL1);
			p1.setInt(1, ordine.getIdIndirizzoSpedizione());
			p1.setInt(2, id_utente);

			ResultSet rs1 = p1.executeQuery();
			
			String nome_if = "";
			String cognome_if = "";
			String paese_if = "";
			String provincia_if = "";
			String citta_if = "";
			String via_if = "";
			String cap_if = "";
			String civico_if = "";
			
			
			while(rs1.next()) {
				nome_if = rs1.getString("Nome");
				cognome_if = rs1.getString("Cognome");
				paese_if = rs1.getString("Paese");
				provincia_if = rs1.getString("Provincia");
				citta_if = rs1.getString("Citta");
				via_if = rs1.getString("Via");
				civico_if = rs1.getString("Civico");
				cap_if = rs1.getString("CAP");
			}
			
			PreparedStatement p2 = null;

			p2 = connection.prepareStatement(insertSQL, Statement.RETURN_GENERATED_KEYS);
			
			p2.setInt(1,id_utente);
			p2.setString(2, nome_is);
			p2.setString(3, cognome_is);
			p2.setString(4, paese_is);
			p2.setString(5, provincia_is);
			p2.setString(6, citta_is);
			p2.setString(7, via_is);
			p2.setString(8, cap_is);
			p2.setString(9, civico_is);
			p2.setString(10, ordine.getNoteSpedizione());

	        int affectedRows = p2.executeUpdate();

            if (affectedRows > 0) {
                resultSet = p2.getGeneratedKeys();
                if (resultSet.next()) {
                    generatedKey = resultSet.getLong(1);
                }
            }
            
            PreparedStatement p3 = null;
            
            String selectSQL2 = "SELECT * FROM Carrello WHERE Utente = ?";
            
            p3 = connection.prepareStatement(selectSQL2);
            p3.setInt(1, id_utente);
            
            ResultSet rs2 = p3.executeQuery();
            
            String insertSQL1 = "INSERT INTO " + TABLE_AcquistoDettagli + " (Acquisto,ProdottoTaglia,QuantitaAcquistata,PrezzoSingolo,Iva) VALUES(?,?,?,?,?)";
            
            while(rs2.next()) {
        
            	int id_taglia = rs2.getInt("ProdottoTaglia");
            	int quantita = rs2.getInt("Quantita");
            	
            	BigDecimal prezzo = this.getPrezzoTaglia(id_taglia);
            	BigDecimal iva = this.getIvaTaglia(id_taglia);
            	
            	PreparedStatement it = connection.prepareStatement(insertSQL1);
            	
            	it.setLong(1, generatedKey);
            	it.setInt(2, id_taglia);
            	it.setInt(3, quantita);
            	it.setBigDecimal(4, prezzo);
            	it.setBigDecimal(5, iva);

            	it.executeUpdate();
            }
            
            String selectSQL3 = "SELECT * FROM Azienda " + " WHERE InformazioniValide = TRUE";
            
            PreparedStatement p4 = connection.prepareStatement(selectSQL3);

            ResultSet rsAzienda = p4.executeQuery();
            
            int id_informazioni_azienda = -1;
            
            if(rsAzienda.next()) {
            	id_informazioni_azienda = rsAzienda.getInt("ID_Azienda");
            }
            
            String insertSQL2 = "INSERT INTO " + TABLE_Fattura + " (Acquisto,MetodoPagamento,Note,InformazioniAzienda,NomeCliente,CognomeCliente,PaeseCliente,ProvinciaCliente,CittaCliente,ViaCliente,CivicoCliente,CAPCliente, DataEmissione) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,CURRENT_TIMESTAMP())";
            
            PreparedStatement p5 = connection.prepareStatement(insertSQL2);
            
            p5.setLong(1, generatedKey);
            p5.setString(2, ordine.getTipoPagamento());
            p5.setString(3, ordine.getNoteSpedizione());
            p5.setInt(4, id_informazioni_azienda);
            p5.setString(5, nome_if);
            p5.setString(6, cognome_if);
            p5.setString(7, paese_if);
            p5.setString(8, provincia_if);
            p5.setString(9, citta_if);
            p5.setString(10, via_if);
            p5.setString(11, civico_if);
            p5.setString(12, cap_if);
           
            p5.executeUpdate();
            
            String deleteSQL = "DELETE FROM " + TABLE_Carrello + " WHERE Utente = ?";
            PreparedStatement p6 = connection.prepareStatement(deleteSQL);
            p6.setInt(1, id_utente);
            
            p6.executeUpdate();
            
            connection.commit();
            
		} finally {
			try {
				if (p != null)
					p.close();
			} finally {
				DriverManagerConnectionPool.releaseConnection(connection);
			}
		}
	}
	
	private BigDecimal getPrezzoTaglia(int id_taglia) throws SQLException {
		
		Connection connection = null;
	    PreparedStatement preparedStatement = null;
	    PreparedStatement p1 = null;
 
	    String selectSQL1 = "SELECT * FROM " + TABLE_ProdottoTaglia + " WHERE ID_ProdottoTaglia = ?";
	    
	    
	    String selectSQL = "SELECT * "
	    				+ "FROM " + TABLE_Prodotto + " p JOIN " + TABLE_Sconto + " s ON p.ID_Prodotto = s.Prodotto WHERE p.ID_Prodotto = ?";
	    
	    BigDecimal prezzo_singolo = null;
	    
	    try {
	        connection = DriverManagerConnectionPool.getConnection();
	        
	        p1 = connection.prepareStatement(selectSQL1);
	        p1.setInt(1,id_taglia);
	        int id_prodotto = -1;
	        
	        ResultSet rs1 = p1.executeQuery();
	        
	        if(rs1.next()) {
	        	id_prodotto = rs1.getInt("Prodotto");
	        	prezzo_singolo = rs1.getBigDecimal("Prezzo");
	        }
	        
	        
	        preparedStatement = connection.prepareStatement(selectSQL);
	        preparedStatement.setInt(1, id_prodotto);
	        ResultSet rs = preparedStatement.executeQuery();
	        
	        if(rs.next()) {
	        	BigDecimal ps = rs.getBigDecimal("PercentualeSconto");
	        	prezzo_singolo = prezzo_singolo.subtract(prezzo_singolo.multiply(ps.divide(new BigDecimal("100")))).setScale(2,RoundingMode.HALF_UP);
	        }
	        
	    } finally {
	        if (preparedStatement != null) {
	            preparedStatement.close();
	        }
	        if (connection != null) {
	            DriverManagerConnectionPool.releaseConnection(connection);
	        }
	    }    
	   return prezzo_singolo;  
	}
	
	private BigDecimal getIvaTaglia(int id_taglia) throws SQLException {
		
		Connection connection = null;
	    PreparedStatement preparedStatement = null;
	    PreparedStatement p1 = null;
	    
	    
	    String selectSQL = "SELECT * "
	    				+ "FROM " + TABLE_Prodotto + " p JOIN " + TABLE_ProdottoTaglia + " pt ON p.ID_Prodotto = pt.Prodotto WHERE pt.ID_ProdottoTaglia = ?";
	    
	    BigDecimal iva = null;
	    
	    try {
	        connection = DriverManagerConnectionPool.getConnection();
	        
	        p1 = connection.prepareStatement(selectSQL);
	        p1.setInt(1,id_taglia);
	        
	        ResultSet rs1 = p1.executeQuery();
	        
	        if(rs1.next()) {
	        	iva = rs1.getBigDecimal("Iva");
	        }
	    } finally {
	        if (preparedStatement != null) {
	            preparedStatement.close();
	        }
	        if (connection != null) {
	            DriverManagerConnectionPool.releaseConnection(connection);
	        }
	    }    
	   return iva;  
	}

}

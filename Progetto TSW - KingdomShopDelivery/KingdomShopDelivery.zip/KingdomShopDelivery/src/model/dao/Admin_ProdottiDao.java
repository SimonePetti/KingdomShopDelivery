package model.dao;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;
import java.time.LocalDate;
import java.util.LinkedList;

import model.beans.Admin_ProdottoDaModificareBean;
import model.beans.Admin_ProdottoTagliaDaAggiungereBean;
import model.beans.Admin_ProdottoTagliaDaModificareBean;
import model.beans.Admin_ProdottoBean;
import model.beans.Admin_ProdottoDaAggiungereBean;
import model.dao.interfacce.Admin_ProdottiDaoInterfaccia;
import model.dao.interfacce.EventoAggiornaDB_DaoInterfaccia;
import model.util.DriverManagerConnectionPool;


public class Admin_ProdottiDao implements Admin_ProdottiDaoInterfaccia {
	
	private static final String TABLE_Prodotto = "Prodotto";
	private static final String TABLE_ProdottoTaglia = "Prodotto_Taglia";
	private static final String TABLE_Sconto = "Sconto";
	
	static EventoAggiornaDB_DaoInterfaccia EventoAggiornaDB_Dao = new EventoAggiornaDB_Dao();
	
	public synchronized int getNumeroProdotti() throws SQLException {

		Connection connection = null;
		PreparedStatement preparedStatement = null;
		int numero_prodotti = 0;
		
		String selectSQL = "SELECT COUNT(*) AS NumeroProdotti "
						 + "FROM " + TABLE_Prodotto + " WHERE Cancellato = FALSE";
		
		try {
			connection = DriverManagerConnectionPool.getConnection();
			
			preparedStatement = connection.prepareStatement(selectSQL);
			
			ResultSet rs = preparedStatement.executeQuery();
			
			if(rs.next()) {
				numero_prodotti = rs.getInt("NumeroProdotti");
			}

		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				DriverManagerConnectionPool.releaseConnection(connection);
			}
		}
		return numero_prodotti;
	}
	
	public synchronized LinkedList<Admin_ProdottoBean> getProdotti() throws SQLException {

		Connection connection = null;
				PreparedStatement preparedStatement = null;
				LinkedList<Admin_ProdottoBean> prodotti = new LinkedList<Admin_ProdottoBean>();
				
				String selectSQL = "SELECT ID_Prodotto, Nome, Marca, Immagine "
								 + "FROM " + TABLE_Prodotto + " WHERE Cancellato = FALSE";
				
				try {
					connection = DriverManagerConnectionPool.getConnection();
					
					preparedStatement = connection.prepareStatement(selectSQL);
					
					ResultSet rs = preparedStatement.executeQuery();
					
					while(rs.next()) {
						Admin_ProdottoBean prodotto = new Admin_ProdottoBean();
						
						prodotto.setId(rs.getInt("ID_Prodotto"));
						prodotto.setNome(rs.getString("Nome"));
						prodotto.setMarca(rs.getString("Marca"));
						byte[] Immagine = rs.getBytes("Immagine");
			            if(Immagine != null) {
			            	prodotto.setImageFromByteArray(Immagine);
			            }
			            prodotti.add(prodotto);
					}

				} finally {
					try {
						if (preparedStatement != null)
							preparedStatement.close();
					} finally {
						DriverManagerConnectionPool.releaseConnection(connection);
					}
				}
				return prodotti;
	}
	
	public synchronized void eliminaProdotto(int id_prodotto) throws SQLException {
				Connection connection = null;
				PreparedStatement preparedStatement = null;
				PreparedStatement preparedStatement1 = null;
				
				String updateSQL = "UPDATE " + TABLE_Prodotto + " "
								 + "SET Cancellato = true "
								 + "WHERE ID_Prodotto = ?";
				
				String deleteSQL = "DELETE FROM " + TABLE_Sconto + " WHERE Prodotto = ?";
				
				try {
					connection = DriverManagerConnectionPool.getConnection();
					
					preparedStatement = connection.prepareStatement(updateSQL);
					preparedStatement.setInt(1, id_prodotto);
					preparedStatement.executeUpdate();
					
					preparedStatement1 = connection.prepareStatement(deleteSQL);
					preparedStatement1.setInt(1, id_prodotto);
					preparedStatement1.executeUpdate();
					
					connection.commit();
					
				} finally {
					try {
						if (preparedStatement != null)
							preparedStatement.close();
					} finally {
						DriverManagerConnectionPool.releaseConnection(connection);
					}
				}
	}
	
	public Admin_ProdottoDaModificareBean RecuperaProdottoDaModificare(int id_prodotto) throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		Admin_ProdottoDaModificareBean prodotto = new Admin_ProdottoDaModificareBean();
		
		 String selectSQL = "SELECT p.ID_Prodotto, p.Nome, p.Marca, p.Descrizione, p.Categoria, p.SottoCategoria, p.Iva, p.Immagine, p.PrezzoMinimo, p.PrezzoMinimoEScontato, p.PrezzoInizialePrezzoMinimo, pt.ID_ProdottoTaglia, pt.NomeTaglia, pt.Prezzo, pt.QuantitaDisponibile, s.PercentualeSconto, s.DataInizio, s.DataFine "
				 + "FROM " + TABLE_Prodotto + " p JOIN " + TABLE_ProdottoTaglia + " pt ON p.ID_Prodotto = pt.Prodotto "
				 + "LEFT JOIN (SELECT p1.ID_Prodotto, s1.PercentualeSconto, s1.DataInizio, s1.DataFine "
				 	+ "FROM " + TABLE_Prodotto + " p1 "
				 	+ "JOIN " + TABLE_Sconto + " s1 ON p1.ID_Prodotto = s1.Prodotto "
				 	+ "WHERE (s1.DataInizio <= CURDATE() AND s1.DataFine >= CURDATE() AND p1.PrezzoMinimoEScontato = FALSE) " 
				 		+ "OR (s1.DataFine < CURDATE() AND p1.PrezzoMinimoEScontato = TRUE) OR (s1.DataInizio <= CURDATE() AND s1.DataFine >= CURDATE()) OR (s1.DataInizio > CURDATE())) AS s ON p.ID_Prodotto = s.ID_Prodotto "
				 + "WHERE p.Cancellato = FALSE AND p.ID_Prodotto = ?";
		
		try {
			connection = DriverManagerConnectionPool.getConnection();
			
			preparedStatement = connection.prepareStatement(selectSQL);
			
			preparedStatement.setInt(1, id_prodotto);
			
			ResultSet rs = preparedStatement.executeQuery();
			
			if(rs.next()) {
				
				BigDecimal percentualeSconto = rs.getBigDecimal("PercentualeSconto");
	            if(rs.wasNull()) {percentualeSconto = null;}
	            Date data = rs.getDate("DataInizio");
	            LocalDate dataInizio = null;
	            LocalDate dataFine = null;
	            if(data != null) { dataInizio = rs.getDate("DataInizio").toLocalDate();}
	            data = rs.getDate("DataFine");
	            if(data != null) { dataFine = rs.getDate("DataFine").toLocalDate();}
				
				if(rs.getDate("DataFine") != null) {
	        		LocalDate dataInizioControllare = rs.getDate("DataInizio").toLocalDate();
	        		LocalDate dataFineControllare = rs.getDate("DataFine").toLocalDate();
	        		LocalDate oggi = LocalDate.now();

	        		if (((dataInizioControllare.isBefore(oggi) || dataInizioControllare.equals(oggi)) && (dataFineControllare.isAfter(oggi) || dataFineControllare.equals(oggi))) && !rs.getBoolean("PrezzoMinimoEScontato")) {
	        		    percentualeSconto = EventoAggiornaDB_Dao.getPercentualeScontoAggiornata(rs.getInt("ID_Prodotto"));
	        		    dataInizio = EventoAggiornaDB_Dao.getDataInizioAggiornata(rs.getInt("ID_Prodotto"));
	        		    dataFine = EventoAggiornaDB_Dao.getDataFineAggiornata(rs.getInt("ID_Prodotto"));
	        		} else {
	        		    if (dataFineControllare.isBefore(oggi) && rs.getBoolean("PrezzoMinimoEScontato")) {
	        		        EventoAggiornaDB_Dao.eliminaScontoProdotto(rs.getInt("ID_Prodotto"));
	        		        percentualeSconto = null;
	        		        dataInizio = null;
	        		        dataFine = null;
	        		    }
	        		}        		
	        	}
				
				prodotto.setIdProdotto(rs.getInt("ID_Prodotto"));
				prodotto.setNomeProdotto(rs.getString("Nome"));
				prodotto.setMarca(rs.getString("Marca"));
				prodotto.setDescrizione(rs.getString("Descrizione"));
				prodotto.setCategoria(rs.getString("Categoria"));
				prodotto.setSottoCategoria(rs.getString("SottoCategoria"));
				prodotto.setIva(rs.getBigDecimal("Iva"));
				byte[] Immagine = rs.getBytes("Immagine");
	            if(Immagine != null) {
	            	prodotto.setImageFromByteArray(Immagine);
	            }
	            prodotto.setPercentualeSconto(percentualeSconto);
	            prodotto.setDataInizio(dataInizio);
	            prodotto.setDataFine(dataFine);
	            
	            Admin_ProdottoTagliaDaModificareBean taglia = new Admin_ProdottoTagliaDaModificareBean();
	            taglia.setIdTaglia(rs.getInt("ID_ProdottoTaglia"));
	            taglia.setNomeTaglia(rs.getString("NomeTaglia"));
	            taglia.setPrezzoTaglia(rs.getBigDecimal("Prezzo"));
	            taglia.setQuantitaDisponibile(rs.getInt("QuantitaDisponibile"));
	            prodotto.aggiungiTaglia(taglia);
				
				while(rs.next()) {
					Admin_ProdottoTagliaDaModificareBean taglia1 = new Admin_ProdottoTagliaDaModificareBean();
		            taglia1.setIdTaglia(rs.getInt("ID_ProdottoTaglia"));
		            taglia1.setNomeTaglia(rs.getString("NomeTaglia"));
		            taglia1.setPrezzoTaglia(rs.getBigDecimal("Prezzo"));
		            taglia1.setQuantitaDisponibile(rs.getInt("QuantitaDisponibile"));
		            prodotto.aggiungiTaglia(taglia1);
				}
			}

		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				DriverManagerConnectionPool.releaseConnection(connection);
			}
		}
		return prodotto;
	}
	
	public void updateProdotto(Admin_ProdottoDaModificareBean prodotto, String imagePath, String nome_taglia, BigDecimal prezzo_taglia, int quantita_taglia) throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		
		String updateSQL;
	    if (prodotto.getImmagine() != null) {
	        updateSQL = "UPDATE " + TABLE_Prodotto + " SET Nome = ?, Marca = ?, Descrizione = ?, Categoria = ?, SottoCategoria = ?, IVA = ?, Immagine = load_file(?), WHERE ID_Prodotto = ? AND Cancellato = FALSE";
	    } else {
	        updateSQL = "UPDATE " + TABLE_Prodotto + " SET Nome = ?, Marca = ?, Descrizione = ?, Categoria = ?, SottoCategoria = ?, IVA = ? WHERE ID_Prodotto = ?";
	    }

		try {
			connection = DriverManagerConnectionPool.getConnection();
			
			preparedStatement = connection.prepareStatement(updateSQL);
			
			preparedStatement.setString(1, prodotto.getNomeProdotto());
	        preparedStatement.setString(2, prodotto.getMarca());
	        preparedStatement.setString(3, prodotto.getDescrizione());
	        preparedStatement.setString(4, prodotto.getCategoria());
	        preparedStatement.setString(5, prodotto.getSottoCategoria());
	        preparedStatement.setBigDecimal(6, prodotto.getIva());
	        
	        if (prodotto.getImmagine() != null) {
	            preparedStatement.setString(7, imagePath);
	            preparedStatement.setInt(8, prodotto.getIdProdotto());
	        } else {
	            preparedStatement.setInt(7, prodotto.getIdProdotto());
	        }
            preparedStatement.executeUpdate();
            
            if(prodotto.getPercentualeSconto() != null) {
            	
            	String selectSQL = "SELECT * FROM " + TABLE_Sconto + " WHERE Prodotto = ?";
            	
            	PreparedStatement ps1 = connection.prepareStatement(selectSQL);
            	
            	ps1.setInt(1, prodotto.getIdProdotto());
            	
            	ResultSet rs = ps1.executeQuery();

            	if(rs.next()) {
            		
            		String updateSQL1 = "UPDATE " + TABLE_Sconto + " "
            						  + "SET PercentualeSconto = ?, DataInizio = ?, DataFine = ? "
            						  + "WHERE Prodotto = ?";
            		
            		PreparedStatement ps2 = connection.prepareStatement(updateSQL1);
            		
            		Date sqlDataInizio = Date.valueOf(prodotto.getDataInizio());
            		Date sqlDataFine = Date.valueOf(prodotto.getDataFine()).before(sqlDataInizio) ? sqlDataInizio : Date.valueOf(prodotto.getDataFine());
            		
            		ps2.setBigDecimal(1, prodotto.getPercentualeSconto());
            		ps2.setDate(2, sqlDataInizio);
            		ps2.setDate(3, sqlDataFine);
            		ps2.setInt(4, prodotto.getIdProdotto());
            		
            		ps2.executeUpdate();
            		
            	} else {
            		String insertSQL = "INSERT INTO " + TABLE_Sconto + " (Prodotto, PercentualeSconto, DataInizio, DataFine) VALUES (?,?,?,?)";
  		
            		PreparedStatement ps2 = connection.prepareStatement(insertSQL);
  		
            		ps2.setInt(1, prodotto.getIdProdotto());
  					ps2.setBigDecimal(2, prodotto.getPercentualeSconto());
  					Date sqlDataInizio = Date.valueOf(prodotto.getDataInizio());
  					ps2.setDate(3, sqlDataInizio);
  					Date sqlDataFine = Date.valueOf(prodotto.getDataFine());
  					ps2.setDate(4, sqlDataFine);
  					
  					ps2.executeUpdate();
            	}
            }
            
            if(nome_taglia != null && !nome_taglia.trim().isEmpty()) {
            	String insertSQL1 = "INSERT INTO " + TABLE_ProdottoTaglia + " (Prodotto,NomeTaglia,Prezzo,QuantitaDisponibile) VALUES(?,?,?,?)";
            	
            	PreparedStatement ps3 = connection.prepareStatement(insertSQL1);
            	
            	ps3.setInt(1, prodotto.getIdProdotto());
            	ps3.setString(2, nome_taglia);
            	ps3.setBigDecimal(3, prezzo_taglia);
            	ps3.setInt(4, quantita_taglia);
            	
            	ps3.executeUpdate();
            }
            
            connection.commit();

		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				DriverManagerConnectionPool.releaseConnection(connection);
			}
		}
	}
	
	public void updateTaglia(Admin_ProdottoTagliaDaModificareBean taglia) throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		
		String updateSQL = "UPDATE " + TABLE_ProdottoTaglia + " "
						 + "SET NomeTaglia = ?, Prezzo = ?, QuantitaDisponibile = ? "
						 + "WHERE ID_ProdottoTaglia = ?";
		
		try {
			connection = DriverManagerConnectionPool.getConnection();
			
			preparedStatement = connection.prepareStatement(updateSQL);
			
			preparedStatement.setString(1, taglia.getNomeTaglia());
            preparedStatement.setBigDecimal(2, taglia.getPrezzoTaglia());
            preparedStatement.setInt(3, taglia.getQuantitaDisponibile());
            preparedStatement.setInt(4, taglia.getIdTaglia());
            preparedStatement.executeUpdate();

		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				DriverManagerConnectionPool.releaseConnection(connection);
			}
		}
	}
	
	public void inserisciProdotto(Admin_ProdottoDaAggiungereBean prodotto, String imagePath, Admin_ProdottoTagliaDaAggiungereBean taglia) throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		long generatedKey = -1;
		
		String updateSQL = "INSERT INTO " + TABLE_Prodotto + " (Nome,Marca,Descrizione,Categoria,SottoCategoria,IVA,Immagine,PrezzoMinimo) VALUES(?,?,?,?,?,?,load_file(?),?)";

		try {
			connection = DriverManagerConnectionPool.getConnection();
			
			preparedStatement = connection.prepareStatement(updateSQL, Statement.RETURN_GENERATED_KEYS);
			
			preparedStatement.setString(1, prodotto.getNomeProdotto());
	        preparedStatement.setString(2, prodotto.getMarca());
	        preparedStatement.setString(3, prodotto.getDescrizione());
	        preparedStatement.setString(4, prodotto.getCategoria());
	        preparedStatement.setString(5, prodotto.getCategoria().equals("Armatura") ? prodotto.getSottoCategoria() : null);
	        preparedStatement.setBigDecimal(6, prodotto.getIva());
	        preparedStatement.setString(7, imagePath);
	        preparedStatement.setBigDecimal(8, taglia.getPrezzoTaglia());

	        int affectedRows = preparedStatement.executeUpdate();
	        
            if (affectedRows > 0) {
                resultSet = preparedStatement.getGeneratedKeys();
                if (resultSet.next()) {
                    generatedKey = resultSet.getLong(1);
                }
            }
            
            if(prodotto.getPercentualeSconto() != null) {
            	
            	String insertSQL = "INSERT INTO " + TABLE_Sconto + " (Prodotto, PercentualeSconto, DataInizio, DataFine) VALUES (?,?,?,?)";
            	
            	PreparedStatement ps2 = connection.prepareStatement(insertSQL);
  		
            	ps2.setLong(1, generatedKey);
  				ps2.setBigDecimal(2, prodotto.getPercentualeSconto());
  				Date sqlDataInizio = Date.valueOf(prodotto.getDataInizio());
  				ps2.setDate(3, sqlDataInizio);
  				Date sqlDataFine = Date.valueOf(prodotto.getDataFine());
  				ps2.setDate(4, sqlDataFine);
  					
  				ps2.executeUpdate();
            }
            
            String insertSQL1 = "INSERT INTO " + TABLE_ProdottoTaglia + " (Prodotto,NomeTaglia,Prezzo,QuantitaDisponibile) VALUES(?,?,?,?)";
            	
            PreparedStatement ps3 = connection.prepareStatement(insertSQL1);
            	
            ps3.setLong(1, generatedKey);
            ps3.setString(2, taglia.getNomeTaglia());      	
            ps3.setBigDecimal(3, taglia.getPrezzoTaglia());
            ps3.setInt(4, taglia.getQuantitaDisponibile());
            	
            ps3.executeUpdate();
            
            connection.commit();

		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				DriverManagerConnectionPool.releaseConnection(connection);
			}
		}
	}
	
}

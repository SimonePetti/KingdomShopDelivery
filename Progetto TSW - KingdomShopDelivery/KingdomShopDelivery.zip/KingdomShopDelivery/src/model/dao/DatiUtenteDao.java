package model.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;

import model.beans.DatiPersonaliBean;
import model.dao.interfacce.DatiUtenteDaoInterfaccia;
import model.util.DriverManagerConnectionPool;


public class DatiUtenteDao implements DatiUtenteDaoInterfaccia {
	
	private static final String TABLE_Utente = "Utente";
	
	public synchronized DatiPersonaliBean getDatiPersonali(int id_utente) throws SQLException {
		
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		DatiPersonaliBean utente = new DatiPersonaliBean();
		
		String selectSQL = "SELECT ID_Utente, Nome, Cognome, Email, PrefissoTelefono, NumeroTelefono, DataRegistrazione "
						 + "FROM " + TABLE_Utente + " "
						 + "WHERE ID_Utente = ? ";
		
		try {
			connection = DriverManagerConnectionPool.getConnection();
			
			preparedStatement = connection.prepareStatement(selectSQL);
			
			preparedStatement.setInt(1, id_utente);
			
			ResultSet rs = preparedStatement.executeQuery();
			
			if(rs.next()) {
				utente.setIdUtente(rs.getInt("ID_Utente"));
				utente.setNome(rs.getString("Nome"));
				utente.setCognome(rs.getString("Cognome"));
				utente.setEmail(rs.getString("Email"));
				utente.setPrefissoTelefonico(rs.getInt("PrefissoTelefono"));
				utente.setNumeroTelefono(rs.getLong("NumeroTelefono"));
				utente.setDataRegistrazione(rs.getDate("DataRegistrazione").toLocalDate());
			}

		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				DriverManagerConnectionPool.releaseConnection(connection);
			}
		}
		return utente;
	}
	
	public synchronized String modificaDati(int id_utente, String nome, String cognome, int prefisso_telefonico, long numero_telefono) throws SQLException {
		
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		String stato_operazione = "";
		
		String updateSQL = "UPDATE Utente "
				         + "SET Nome = ?, Cognome = ?, PrefissoTelefono = ?, NumeroTelefono = ? "
				         + "WHERE ID_Utente = ?";
		
		try {
			connection = DriverManagerConnectionPool.getConnection();
			
			preparedStatement = connection.prepareStatement(updateSQL);
			
			preparedStatement.setString(1, nome);
			preparedStatement.setString(2, cognome);
			preparedStatement.setInt(3, prefisso_telefonico);
			preparedStatement.setLong(4, numero_telefono);
			preparedStatement.setInt(5, id_utente);
			
			preparedStatement.executeUpdate();
			connection.commit();
			stato_operazione = "successo";

		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				DriverManagerConnectionPool.releaseConnection(connection);
			}
		}
		return stato_operazione;
	}
	
	public synchronized String modificaEmail(int id_utente, String email_attuale, String email_nuova, String password) throws SQLException {
		
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		String stato_operazione = "";
		
		String updateSQL = "UPDATE Utente "
				         + "SET Email = ? "
				         + "WHERE ID_Utente = ? AND Email = ? AND Password = ?";
		
		try {
			connection = DriverManagerConnectionPool.getConnection();
			
			preparedStatement = connection.prepareStatement(updateSQL);
			
			preparedStatement.setString(1, email_nuova);
			preparedStatement.setInt(2, id_utente);
			preparedStatement.setString(3, email_attuale);
			preparedStatement.setString(4, password);
			
			preparedStatement.executeUpdate();
			connection.commit();
			stato_operazione = "successo";

		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				DriverManagerConnectionPool.releaseConnection(connection);
			}
		}
		return stato_operazione;
	}
	
	public String modificaPassword(int id_utente, String email, String password_attuale, String password_nuova) throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		String stato_operazione = "";
		
		String updateSQL = "UPDATE Utente "
				         + "SET Password = ? "
				         + "WHERE ID_Utente = ? AND Email = ? AND Password = ?";
		
		try {
			connection = DriverManagerConnectionPool.getConnection();
			
			preparedStatement = connection.prepareStatement(updateSQL);
			
			preparedStatement.setString(1, password_nuova);
			preparedStatement.setInt(2, id_utente);
			preparedStatement.setString(3, email);
			preparedStatement.setString(4, password_attuale);
			
			preparedStatement.executeUpdate();
			connection.commit();
			stato_operazione = "successo";

		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				DriverManagerConnectionPool.releaseConnection(connection);
			}
		}
		return stato_operazione;
	}
	
}

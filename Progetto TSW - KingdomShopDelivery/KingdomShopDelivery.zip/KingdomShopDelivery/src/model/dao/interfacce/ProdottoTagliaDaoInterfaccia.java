package model.dao.interfacce;

public interface ProdottoTagliaDaoInterfaccia {

}

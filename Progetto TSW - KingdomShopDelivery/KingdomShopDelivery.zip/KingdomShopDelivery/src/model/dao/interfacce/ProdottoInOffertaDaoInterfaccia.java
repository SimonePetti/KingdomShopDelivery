package model.dao.interfacce;

import java.sql.SQLException;
import java.util.List;

import model.beans.ProdottoInOffertaBean;

public interface ProdottoInOffertaDaoInterfaccia extends ProdottoDaoInterfaccia {
	
	public List<ProdottoInOffertaBean> getProdottiInOfferta(int numeroProdotti) throws SQLException;
	
	public List<ProdottoInOffertaBean> getProdottiInOfferta() throws SQLException;
}

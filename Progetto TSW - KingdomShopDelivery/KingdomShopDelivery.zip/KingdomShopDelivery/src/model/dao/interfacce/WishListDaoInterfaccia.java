package model.dao.interfacce;

import model.beans.WishListBean;
import java.util.LinkedList;

import java.sql.SQLException;
import java.util.Collection;

public interface WishListDaoInterfaccia {

	public void doSave(int id_prodotto, int id_utente) throws SQLException;
	
	public void doDelete(int id_prodotto, int id_utente) throws SQLException;
	
	public WishListBean getProdotti(int numeroProdotti, int id_utente) throws SQLException;
	
	public WishListBean getProdotti(int id_utente) throws SQLException;
	
	public WishListBean getProdottiGuest(int numeroProdotti, LinkedList<Integer> prodottiGuest) throws SQLException;
	
	public WishListBean getProdottiGuest(LinkedList<Integer> prodottiGuest) throws SQLException;
	
	public Boolean isIn(int id_prodotto) throws SQLException;
	
	public Boolean isIn(int id_prodotto, int id_utente) throws SQLException;
}

package model.dao.interfacce;

import model.beans.ProdottoBean;

import java.sql.SQLException;
import java.util.Collection;
import java.util.LinkedList;

public interface ProdottoDaoInterfaccia {
	
	public Collection<ProdottoBean> doRetrieveAll(int numeroProdotti, String ordine) throws SQLException;
	
	public Collection<ProdottoBean> doRetrieveAll(String ordine) throws SQLException;
	
	public Collection<ProdottoBean> getProdotti(int numeroProdotti) throws SQLException;
	
	public Collection<ProdottoBean> getProdotti() throws SQLException;
	
	public Collection<ProdottoBean> getProdottiPiuVenduti(int numeroProdotti) throws SQLException;
	
	public Collection<ProdottoBean> getUltimiArrivi(int numeroProdotti) throws SQLException;
	
	public LinkedList<ProdottoBean> getProdottiCategoria(String Categoria, String SottoCategoria) throws SQLException;
}
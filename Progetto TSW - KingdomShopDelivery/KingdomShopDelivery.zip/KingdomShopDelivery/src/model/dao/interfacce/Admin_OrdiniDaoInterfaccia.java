package model.dao.interfacce;

import java.sql.SQLException;
import java.time.LocalDate;
import java.util.LinkedHashMap;

import model.beans.Admin_OrdineBean;
import model.beans.Admin_OrdineDettagliBean;
import model.beans.ConfermaOrdineBean;

public interface Admin_OrdiniDaoInterfaccia {
	
	public int getNumeroVenditeTotali() throws SQLException;
	
	public int getNumeroVenditeNuove() throws SQLException;
	
	public int getNumeroProdottiVenduti() throws SQLException;
	
	public int getNumeroProdottiVendutiRecentemente() throws SQLException;
	
	public LinkedHashMap<Admin_OrdineBean, Integer> getOrdini() throws SQLException;
	
	public LinkedHashMap<Admin_OrdineBean, Integer> getOrdini(LocalDate data_inizio, LocalDate data_fine) throws SQLException;
	
	public LinkedHashMap<Admin_OrdineDettagliBean,Integer> getOrdineDettagli(int numero_ordine) throws SQLException;

}

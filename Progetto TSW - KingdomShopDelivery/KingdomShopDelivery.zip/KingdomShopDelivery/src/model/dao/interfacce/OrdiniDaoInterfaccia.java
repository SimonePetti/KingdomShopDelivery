package model.dao.interfacce;

import java.sql.SQLException;
import java.util.LinkedList;

import model.beans.ConfermaOrdineBean;
import model.beans.OrdineBean;
import model.beans.OrdineDettagliBean;

public interface OrdiniDaoInterfaccia {

	public LinkedList<OrdineBean> getOrdini(int id_utente) throws SQLException;
	
	public Boolean isIn(int id_utente, int numero_ordine) throws SQLException; 
	
	public OrdineDettagliBean getDettagliOrdine(int numero_ordine) throws SQLException;
	
	public void finalizzaAcquisto(int id_utente, ConfermaOrdineBean ordine) throws SQLException;
	
}

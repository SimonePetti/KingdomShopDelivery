package model.dao.interfacce;

import java.sql.SQLException;

public interface RegistrazioneDaoInterfaccia {
	
	public Boolean doSave(String nome, String cognome, String email, String password, int prefissoTelefono, long numeroTelefono) throws SQLException;
	
	public Boolean ControllaEmail(String email) throws SQLException;

}

package model.dao.interfacce;

import java.sql.SQLException;
import java.util.Collection;
import java.util.LinkedList;
import java.util.List;

import model.beans.OrdineBean;
import model.beans.ProdottoBean;

public interface BarraDiRicercaDaoInterfaccia {
	
	public List<String> getSuggerimenti(String query) throws SQLException;
	
	public Collection<ProdottoBean> getProdottiSuggeriti(String query) throws SQLException;

}

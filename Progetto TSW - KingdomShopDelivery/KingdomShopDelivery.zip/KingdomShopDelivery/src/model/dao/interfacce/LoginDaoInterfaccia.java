package model.dao.interfacce;

import java.sql.SQLException;

public interface LoginDaoInterfaccia {
	
	public int ControllaCredenziali(String email, String password) throws SQLException;
	
	public String getRuoloUtente(int id_utente) throws SQLException;
}

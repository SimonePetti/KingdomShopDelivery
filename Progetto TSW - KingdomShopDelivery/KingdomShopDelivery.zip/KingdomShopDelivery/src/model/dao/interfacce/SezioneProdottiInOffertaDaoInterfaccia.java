package model.dao.interfacce;

public interface SezioneProdottiInOffertaDaoInterfaccia extends ProdottoInOffertaDaoInterfaccia { //Potresti anche fare che ogni sezione della Home ha il Dao Sezione... cosi utilizziamo lo stesso dao pi� volte

}

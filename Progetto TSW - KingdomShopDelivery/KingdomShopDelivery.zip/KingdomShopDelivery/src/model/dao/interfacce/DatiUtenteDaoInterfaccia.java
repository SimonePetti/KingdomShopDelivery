package model.dao.interfacce;

import java.sql.SQLException;

import model.beans.DatiPersonaliBean;

public interface DatiUtenteDaoInterfaccia {
	
	public DatiPersonaliBean getDatiPersonali(int id_utente) throws SQLException;
	
	public String modificaDati(int id_utente, String nome, String cognome, int prefisso_telefonico, long numero_telefono) throws SQLException;
	
	public String modificaEmail(int id_utente, String email_attuale, String email_nuova, String password) throws SQLException;
	
	public String modificaPassword(int id_utente, String email, String password_attuale, String password_nuova) throws SQLException;
	
}

package model.dao.interfacce;

import java.sql.SQLException;

import model.beans.FatturaBean;

public interface FatturaDaoInterfaccia {
	
	public FatturaBean getFatturaOrdine(int id_utente, int id_ordine) throws SQLException;

}

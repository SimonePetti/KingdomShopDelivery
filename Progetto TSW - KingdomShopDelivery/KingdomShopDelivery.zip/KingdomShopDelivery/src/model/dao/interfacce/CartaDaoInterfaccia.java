package model.dao.interfacce;

import java.sql.SQLException;
import java.time.YearMonth;
import java.util.LinkedList;

import model.beans.CartaBean;

public interface CartaDaoInterfaccia {
	
	public LinkedList<CartaBean> getCarte(int id_utente) throws SQLException;
	
	public String aggiungiCarta(int id_utente, CartaBean carta, int cvv) throws SQLException;
	
	public String modificaCarta(int id_utente, int id_carta, String nome_completo, YearMonth data_scadenza) throws SQLException;
	
	public String eliminaCarta(int id_utente, int id_carta) throws SQLException;
	
}

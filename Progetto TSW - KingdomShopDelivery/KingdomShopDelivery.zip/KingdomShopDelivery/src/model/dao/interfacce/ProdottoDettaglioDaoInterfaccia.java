package model.dao.interfacce;

import model.beans.ProdottoDettaglioBean;

import java.sql.SQLException;

public interface ProdottoDettaglioDaoInterfaccia extends ProdottoDaoInterfaccia {
	
	public ProdottoDettaglioBean doRetrieveByKey(int id_prodotto) throws SQLException;

}

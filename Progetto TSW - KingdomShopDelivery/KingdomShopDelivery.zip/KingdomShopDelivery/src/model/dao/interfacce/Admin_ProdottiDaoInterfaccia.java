package model.dao.interfacce;

import model.beans.Admin_ProdottoBean;
import model.beans.Admin_ProdottoDaAggiungereBean;
import model.beans.Admin_ProdottoDaModificareBean;
import model.beans.Admin_ProdottoTagliaDaAggiungereBean;
import model.beans.Admin_ProdottoTagliaDaModificareBean;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.LinkedList;

public interface Admin_ProdottiDaoInterfaccia {
	
	public int getNumeroProdotti() throws SQLException;
	
	public LinkedList<Admin_ProdottoBean> getProdotti() throws SQLException;
	
	public void eliminaProdotto(int id_prodotto) throws SQLException;
	
	public Admin_ProdottoDaModificareBean RecuperaProdottoDaModificare(int id_prodotto) throws SQLException;

	public void updateProdotto(Admin_ProdottoDaModificareBean prodotto, String fileName, String imagePath, BigDecimal prezzo_taglia, int quantita_taglia) throws SQLException;
	
	public void updateTaglia(Admin_ProdottoTagliaDaModificareBean taglia) throws SQLException;
	
	public void inserisciProdotto(Admin_ProdottoDaAggiungereBean prodotto, String imagePath, Admin_ProdottoTagliaDaAggiungereBean taglia) throws SQLException;
	
}

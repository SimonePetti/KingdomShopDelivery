package model.dao.interfacce;

import model.beans.IndirizzoBean;

import java.sql.SQLException;

import java.util.LinkedList;

public interface IndirizzoDaoInterfaccia {
	
	public LinkedList<IndirizzoBean> getIndirizzi(int id_utente) throws SQLException;

	public void getIndirizzi(int id_utente, LinkedList<IndirizzoBean> indirizziSpedizione, LinkedList<IndirizzoBean> indirizziFatturazione) throws SQLException;
	
	public String aggiungiIndirizzo(int id_utente, IndirizzoBean indirizzo) throws SQLException;
	
	public String modificaIndirizzo(int id_utente, IndirizzoBean indirizzo, int id_indirizzo) throws SQLException;
	
	public String eliminaIndirizzo(int id_utente, int id_indirizzo) throws SQLException;
}

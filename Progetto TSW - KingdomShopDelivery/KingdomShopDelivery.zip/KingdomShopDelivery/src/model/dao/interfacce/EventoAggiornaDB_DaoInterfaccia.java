package model.dao.interfacce;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.time.LocalDate;

import model.beans.CarrelloProdottoBean;
import model.beans.CarrelloProdottoInOffertaBean;
import model.beans.ProdottoBean;
import model.beans.ProdottoInOffertaBean;

public interface EventoAggiornaDB_DaoInterfaccia {
	
	public void aggiornaScontoProdotto(int id_prodotto) throws SQLException;
	
	public void eliminaScontoProdotto(int id_prodotto) throws SQLException;
	
	public void eliminaScontoScadutoProdotto(int id_prodotto) throws SQLException;
	
	public void aggiornaPrezzoMinimoProdotto(int id_prodotto) throws SQLException;
		
	public ProdottoInOffertaBean getProdottoInOffertaBeanAggiornato(int id_prodotto) throws SQLException;
	
	public ProdottoBean getProdottoBeanAggiornato(int id_prodotto) throws SQLException;
	
	public BigDecimal getPercentualeScontoAggiornata(int id_prodotto) throws SQLException;
	
	public CarrelloProdottoInOffertaBean getCarrelloProdottoInOffertaBeanAggiornato(int id_prodotto) throws SQLException;
	
	public CarrelloProdottoBean getCarrelloProdottoBeanAggiornato(int id_prodotto) throws SQLException;
	
	public LocalDate getDataInizioAggiornata(int id_prodotto) throws SQLException;
	
	public LocalDate getDataFineAggiornata(int id_prodotto) throws SQLException;

}

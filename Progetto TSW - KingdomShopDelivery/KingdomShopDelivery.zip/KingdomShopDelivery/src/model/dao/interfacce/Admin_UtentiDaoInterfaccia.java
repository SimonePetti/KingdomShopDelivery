package model.dao.interfacce;

import java.sql.SQLException;
import java.time.LocalDate;

import model.beans.UtenteBean;

import java.util.LinkedList;

import model.beans.UtenteDettagliBean;

public interface Admin_UtentiDaoInterfaccia {
	
	public int getNumeroUtentiTotali() throws SQLException;
	
	public int getNumeroUtentiNuovi() throws SQLException;
	
	public LinkedList<UtenteBean> getUtenti() throws SQLException;
	
	public UtenteDettagliBean getDettagliUtente(int id_utente) throws SQLException;
	
	public UtenteDettagliBean getDettagliUtente(int id_utente, LocalDate data_inizio, LocalDate data_fine) throws SQLException;
	
	public void modificaRuolo(int id_utente, String ruolo) throws SQLException;

}

package model.dao.interfacce;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.LinkedHashMap;
import java.util.ArrayList;
import java.util.List;

import model.beans.CarrelloBean;

public interface CarrelloDaoInterfaccia {
	
	public void doSave(int id_taglia, int id_utente, int quantita) throws SQLException;
	
	public void doDelete(int id_prodotto, int id_utente) throws SQLException;
	
	public CarrelloBean getProdotti(int numeroProdotti, int id_utente) throws SQLException; 
	
	public CarrelloBean getProdotti(int id_utente) throws SQLException;
	
	public CarrelloBean getProdottiGuest(int numeroProdotti, LinkedHashMap<List<Integer>, Integer> prodottiGuest) throws SQLException;
	
	public CarrelloBean getProdottiGuest(LinkedHashMap<List<Integer>, Integer> prodottiGuest) throws SQLException;
	
	public int getQuantitaDisponibileTaglia(int id_taglia) throws SQLException;
	
	public Boolean isIn(int id_prodotto, int id_taglia) throws SQLException;
	
	public Boolean isInCarrello(int id_taglia, int id_utente) throws SQLException;
	
	public void incrementaDiUno(int id_taglia, int id_utente) throws SQLException;
	
	public void aumentaQuantita(int id_taglia, int id_utente, int quantita) throws SQLException;
	
	public void modificaQuantitaCarrello(int id_taglia, int id_utente, int quantita) throws SQLException;
	
	public int getNumeroProdottiDisponibili(int id_utente) throws SQLException;
	
}

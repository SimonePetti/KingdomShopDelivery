package model.dao;

import model.dao.interfacce.ProdottoTagliaDaoInterfaccia;

public class ProdottoTagliaDao implements ProdottoTagliaDaoInterfaccia {

}

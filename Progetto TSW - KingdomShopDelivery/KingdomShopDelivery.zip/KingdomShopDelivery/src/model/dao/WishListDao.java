package model.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.LinkedList;

import model.beans.WishListBean;
import model.beans.ProdottoBean;
import model.beans.ProdottoInOffertaBean;
import model.dao.interfacce.EventoAggiornaDB_DaoInterfaccia;
import model.dao.interfacce.WishListDaoInterfaccia;
import model.util.DriverManagerConnectionPool;
import java.sql.ResultSet;

public class WishListDao implements WishListDaoInterfaccia {
	
	private static final String TABLE_Prodotto = "Prodotto";
	private static final String TABLE_Sconto = "Sconto";
	private static final String TABLE_WishList = "WishList";
	
	static EventoAggiornaDB_DaoInterfaccia EventoAggiornaDB_Dao = new EventoAggiornaDB_Dao();
	
	@Override
	public synchronized void doSave(int id_prodotto, int id_utente) throws SQLException {

		Connection connection = null;
		PreparedStatement preparedStatement = null;

		String updateSQL = "INSERT INTO " + TABLE_WishList + " (Utente, Prodotto) VALUES(?, ?)";

		try {
			connection = DriverManagerConnectionPool.getConnection();
			preparedStatement = connection.prepareStatement(updateSQL);
	
			preparedStatement.setInt(1, id_utente);
			preparedStatement.setInt(2, id_prodotto);

			preparedStatement.executeUpdate();
			connection.commit();

		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				DriverManagerConnectionPool.releaseConnection(connection);
			}
		}	
	}
	
	@Override
	public synchronized void doDelete(int id_prodotto, int id_utente) throws SQLException {

		Connection connection = null;
		PreparedStatement preparedStatement = null;

		String insertSQL = "DELETE FROM " + TABLE_WishList + " WHERE Utente = ? AND  Prodotto = ?";

		try {
			connection = DriverManagerConnectionPool.getConnection();
			preparedStatement = connection.prepareStatement(insertSQL);
					
			preparedStatement.setInt(1, id_utente);
			preparedStatement.setInt(2, id_prodotto);

			preparedStatement.executeUpdate();
			connection.commit();

		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				DriverManagerConnectionPool.releaseConnection(connection);
			}
		}	
	}
	
	@Override
	public synchronized WishListBean getProdotti(int numeroProdotti, int id_utente) throws SQLException {
		
		Connection connection = null;
	    PreparedStatement preparedStatement = null;
		
		WishListBean wishList = new WishListBean();
		
		String selectSQL = "SELECT p.ID_Prodotto, p.Nome, p.Marca, p.Immagine, p.PrezzoMinimo, p.PrezzoMinimoEScontato, p.PrezzoInizialePrezzoMinimo, s.PercentualeSconto, s.DataInizio, s.DataFine "
				 + "FROM " + TABLE_Prodotto + " p " 
				 	+ "JOIN " + TABLE_WishList + " w ON p.ID_Prodotto = w.Prodotto LEFT JOIN "
				 	+ "(SELECT p1.ID_Prodotto, s1.PercentualeSconto, s1.DataInizio, s1.DataFine "
				 	+ "FROM " + TABLE_Prodotto + " p1 "
				 	+ "JOIN " + TABLE_Sconto + " s1 ON p1.ID_Prodotto = s1.Prodotto "
				 	+ "WHERE (s1.DataInizio <= CURDATE() AND s1.DataFine >= CURDATE() AND p1.PrezzoMinimoEScontato = FALSE) " 
				 		+ "OR (s1.DataFine < CURDATE() AND p1.PrezzoMinimoEScontato = TRUE) OR (s1.DataInizio <= CURDATE() AND s1.DataFine >= CURDATE())) AS s ON p.ID_Prodotto = s.ID_Prodotto "
				 + "WHERE w.Utente = ? AND p.Cancellato = FALSE "
				 + "ORDER BY w.DataInserimentoWishlist ASC";

		if(numeroProdotti >= 0) {
			selectSQL +=  " LIMIT " + numeroProdotti;
		}

		try {
			connection = DriverManagerConnectionPool.getConnection();
			preparedStatement = connection.prepareStatement(selectSQL);
			
			preparedStatement.setInt(1, id_utente);
   
			ResultSet rs = preparedStatement.executeQuery();
			
			while (rs.next()) {
        	  	
	        	if(rs.getDate("DataFine") == null) {
	        		
	        		ProdottoBean bean;
		        	Boolean SceltaBean = rs.getBoolean("PrezzoMinimoEScontato");
	        		
	        		if(SceltaBean) {
	        			ProdottoInOffertaBean prodottoInOfferta = this.creaProdottoInOffertaBean(rs);
		        		bean = prodottoInOfferta;
		        	} else {
		        		bean = this.creaProdottoBean(rs);
		        	}
	        		wishList.setProdottoFirst(bean);
		            
	        	} else {
	        		Date dataInizio = rs.getDate("DataInizio");
	        		Date dataFine = rs.getDate("DataFine");
                    Date oggi = new Date(System.currentTimeMillis());
                    
	        		if(((dataInizio.before(oggi) || dataInizio.equals(oggi)) && (dataFine.after(oggi) || dataFine.equals(oggi))) && rs.getBoolean("PrezzoMinimoEScontato") == false) {
	        			ProdottoInOffertaBean prodottoAggiornato = EventoAggiornaDB_Dao.getProdottoInOffertaBeanAggiornato(rs.getInt("ID_Prodotto"));
	        			wishList.setProdottoFirst((ProdottoBean) prodottoAggiornato);
	        		} else {
	        			if(dataFine.before(oggi) && rs.getBoolean("PrezzoMinimoEScontato") == true ) {
		        			ProdottoBean prodottoAggiornato = (ProdottoBean) EventoAggiornaDB_Dao.getProdottoBeanAggiornato(rs.getInt("ID_Prodotto"));
		        			wishList.setProdottoFirst(prodottoAggiornato);
		        		} else {
		        			ProdottoBean bean;
				        	Boolean SceltaBean = rs.getBoolean("PrezzoMinimoEScontato");
			        		
			        		if(SceltaBean) {
			        			ProdottoInOffertaBean prodottoInOfferta = this.creaProdottoInOffertaBean(rs);
				        		bean = prodottoInOfferta;
				        	} else {
				        		bean = this.creaProdottoBean(rs);
				        	}
			        		wishList.setProdottoFirst(bean);
		        		}
	        		}
	        	}
	        }
		} finally {
			if (preparedStatement != null) {
				preparedStatement.close();
			}
			if (connection != null) {
				DriverManagerConnectionPool.releaseConnection(connection);
			}
		}
		return wishList;
	}
	
	@Override
	public synchronized WishListBean getProdotti(int id_utente) throws SQLException {
		WishListBean wishList = getProdotti(-1, id_utente);
	    return wishList;
	}
	
	@Override
	public synchronized WishListBean getProdottiGuest(int numeroProdotti, LinkedList<Integer> prodottiGuest) throws SQLException {
		
		Connection connection = null;
	    PreparedStatement preparedStatement = null;
		WishListBean wishList = new WishListBean();
		
		StringBuilder queryBuilder = new StringBuilder ("SELECT p.ID_Prodotto, p.Nome, p.Marca, p.Immagine, p.PrezzoMinimo, p.PrezzoMinimoEScontato, p.PrezzoInizialePrezzoMinimo, s.PercentualeSconto, s.DataInizio, s.DataFine "
				 + "FROM " + TABLE_Prodotto + " p LEFT JOIN " 
				 	+ "(SELECT p1.ID_Prodotto, s1.PercentualeSconto, s1.DataInizio, s1.DataFine "
				 	+ "FROM " + TABLE_Prodotto + " p1 "
				 	+ "JOIN " + TABLE_Sconto + " s1 ON p1.ID_Prodotto = s1.Prodotto "
				 	+ "WHERE (s1.DataInizio <= CURDATE() AND s1.DataFine >= CURDATE() AND p1.PrezzoMinimoEScontato = FALSE) " 
				 		+ "OR (s1.DataFine < CURDATE() AND p1.PrezzoMinimoEScontato = TRUE) OR (s1.DataInizio <= CURDATE() AND s1.DataFine >= CURDATE())) AS s ON p.ID_Prodotto = s.ID_Prodotto "
				 + "WHERE p.Cancellato = FALSE AND p.ID_Prodotto IN (");
		
		queryBuilder.append(prodottiGuest.get(0));
		
		for(int i = 1; i < prodottiGuest.size(); i++) {
			queryBuilder.append(", ");
			queryBuilder.append(prodottiGuest.get(i));
		}
				 		 
		queryBuilder.append(")");
		
		String selectSQL = queryBuilder.toString();
		
		if(numeroProdotti >= 0) {
			selectSQL +=  " LIMIT " + numeroProdotti;
		}

		try {
			connection = DriverManagerConnectionPool.getConnection();
			preparedStatement = connection.prepareStatement(selectSQL);
   
			ResultSet rs = preparedStatement.executeQuery();

			while (rs.next()) {
        	  	
	        	if(rs.getDate("DataFine") == null) {
	        		
	        		ProdottoBean bean;
		        	Boolean SceltaBean = rs.getBoolean("PrezzoMinimoEScontato");
	        		
	        		if(SceltaBean) {
	        			ProdottoInOffertaBean prodottoInOfferta = this.creaProdottoInOffertaBean(rs);
		        		bean = prodottoInOfferta;
		        	} else {
		        		bean = this.creaProdottoBean(rs);
		        	}
	        		wishList.setProdottoFirst(bean);
		            
	        	} else {
	        		Date dataInizio = rs.getDate("DataInizio");
	        		Date dataFine = rs.getDate("DataFine");
                    Date oggi = new Date(System.currentTimeMillis());
                    
	        		if(((dataInizio.before(oggi) || dataInizio.equals(oggi)) && (dataFine.after(oggi) || dataFine.equals(oggi))) && rs.getBoolean("PrezzoMinimoEScontato") == false) {
	        			ProdottoInOffertaBean prodottoAggiornato = EventoAggiornaDB_Dao.getProdottoInOffertaBeanAggiornato(rs.getInt("ID_Prodotto"));
	        			wishList.setProdottoFirst((ProdottoBean) prodottoAggiornato);
	        		} else {
	        			if(dataFine.before(oggi) && rs.getBoolean("PrezzoMinimoEScontato") == true ) {
		        			ProdottoBean prodottoAggiornato = (ProdottoBean) EventoAggiornaDB_Dao.getProdottoBeanAggiornato(rs.getInt("ID_Prodotto"));
		        			wishList.setProdottoFirst(prodottoAggiornato);
		        		} else {
		        			ProdottoBean bean;
				        	Boolean SceltaBean = rs.getBoolean("PrezzoMinimoEScontato");
			        		
			        		if(SceltaBean) {
			        			ProdottoInOffertaBean prodottoInOfferta = this.creaProdottoInOffertaBean(rs);
				        		bean = prodottoInOfferta;
				        	} else {
				        		bean = this.creaProdottoBean(rs);
				        	}
			        		wishList.setProdottoFirst(bean);
		        		}
	        		}
	        	}
	        }
		} finally {
			if (preparedStatement != null) {
				preparedStatement.close();
			}
			if (connection != null) {
				DriverManagerConnectionPool.releaseConnection(connection);
			}
		}
		return wishList;
	}
	
	@Override
	public synchronized WishListBean getProdottiGuest(LinkedList<Integer> prodottiGuest) throws SQLException {
		WishListBean wishList = getProdottiGuest(-1, prodottiGuest);
	    return wishList;
	}
	
	@Override
	public synchronized Boolean isIn(int id_prodotto) throws SQLException {
		
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		
		Boolean prodotto_trovato = false;

		String selectSQL = "SELECT p.ID_Prodotto "
						 + "FROM " + TABLE_Prodotto + " p "
						 + "WHERE p.ID_Prodotto = ? AND p.Cancellato = FALSE ";

		try {
			connection = DriverManagerConnectionPool.getConnection();
			preparedStatement = connection.prepareStatement(selectSQL);
			preparedStatement.setInt(1, id_prodotto);

			ResultSet rs = preparedStatement.executeQuery();
			
			if(rs.next()) {
				prodotto_trovato = true;
			} else {
				prodotto_trovato = false;
			}

		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				DriverManagerConnectionPool.releaseConnection(connection);
			}
		}
	return prodotto_trovato;
	}
	
	@Override
	public synchronized Boolean isIn(int id_prodotto, int id_utente) throws SQLException {
		
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		
		Boolean prodotto_giapresente = false;

		String selectSQL = "SELECT w.Prodotto "
						 + "FROM " + TABLE_WishList + " w "
						 + "WHERE w.Prodotto = ? AND Utente = ?";

		try {
			connection = DriverManagerConnectionPool.getConnection();
			preparedStatement = connection.prepareStatement(selectSQL);
			preparedStatement.setInt(1, id_prodotto);
			
			preparedStatement.setInt(2, id_utente);
			
			ResultSet rs = preparedStatement.executeQuery();
			
			if(rs.next()) {
				prodotto_giapresente = true;
			} else {
				prodotto_giapresente = false;
			}

		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				DriverManagerConnectionPool.releaseConnection(connection);
			}
		}
	return prodotto_giapresente;
	}
	
	private ProdottoBean creaProdottoBean(ResultSet rs) throws SQLException {
		
		ProdottoBean prodotto = new ProdottoBean();
		
		prodotto.setId(rs.getInt("ID_prodotto"));
        prodotto.setNome(rs.getString("Nome"));
        prodotto.setMarca(rs.getString("Marca"));
        byte[] Immagine = rs.getBytes("Immagine");
        if(Immagine != null) {
        	prodotto.setImageFromByteArray(Immagine);
        }
        prodotto.setPrezzoMinimo(rs.getBigDecimal("PrezzoMinimo"));
        
        return prodotto;
	}
	
	private ProdottoInOffertaBean creaProdottoInOffertaBean(ResultSet rs) throws SQLException {
		
		ProdottoInOffertaBean prodotto = new ProdottoInOffertaBean();
		
		prodotto.setId(rs.getInt("ID_prodotto"));
        prodotto.setNome(rs.getString("Nome"));
        prodotto.setMarca(rs.getString("Marca"));
        byte[] Immagine = rs.getBytes("Immagine");
        if(Immagine != null) {
        	prodotto.setImageFromByteArray(Immagine);
        }
        prodotto.setPrezzoMinimo(rs.getBigDecimal("PrezzoMinimo"));
        prodotto.setPrezzoIniziale(rs.getBigDecimal("PrezzoInizialePrezzoMinimo"));
        prodotto.setPercentualeSconto(rs.getBigDecimal("PercentualeSconto"));
        
        return prodotto;
	}

}


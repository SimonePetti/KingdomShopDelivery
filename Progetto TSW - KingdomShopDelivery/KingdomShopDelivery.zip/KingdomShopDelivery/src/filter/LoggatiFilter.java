package filter;

import java.io.IOException;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class LoggatiFilter implements Filter {
       
	@Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
      
		HttpServletRequest httpRequest = (HttpServletRequest) request;
        HttpServletResponse httpResponse = (HttpServletResponse) response;
        HttpSession session = httpRequest.getSession(true);
        String sendRedirect = "";

        if (session.getAttribute("idUtente") == null) { 
        	// Utente non loggato
        	if(httpRequest.getServletPath().equals("/confermaAcquisto.jsp")) {sendRedirect = "?sendRedirect=confermaAcquisto";}
        	
            httpResponse.sendRedirect(httpRequest.getContextPath() + "/login.jsp" + sendRedirect);
            return;
        } else {
            // Utente loggato
            chain.doFilter(request, response);
        }
    }
}

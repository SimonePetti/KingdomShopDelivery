package filter;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import model.beans.ConfermaOrdineBean;
import model.dao.CarrelloDao;
import model.dao.interfacce.CarrelloDaoInterfaccia;

public class ConfermaAcquistoFilter implements Filter {
	
	static CarrelloDaoInterfaccia CarrelloDao = new CarrelloDao();
	
	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		
		HttpServletRequest httpRequest = (HttpServletRequest) request;
        HttpServletResponse httpResponse = (HttpServletResponse) response;
        HttpSession session = httpRequest.getSession(true);
        String stato_acquisto = session.getAttribute("stato_acquisto") != null ? "successo" : "incompleto";
        
        if (session.getAttribute("idUtente") != null) { 
        	
        	try {
        		if(CarrelloDao.getNumeroProdottiDisponibili((Integer) session.getAttribute("idUtente")) == 0) {
        			httpResponse.sendRedirect(httpRequest.getContextPath() + "/carrello");
                    return;
        		}
        	ConfermaOrdineBean ordine = (ConfermaOrdineBean) session.getAttribute("AcquistoDaConfermare");
        	
        	if(!httpRequest.getServletPath().equals("/confermaAcquisto/pagamento")) {
    
        		if(!httpRequest.getServletPath().equals("/confermaAcquisto/indirizzo")) {
        		
        			if((ordine.getIdIndirizzoSpedizione() == -1 || ordine.getIdIndirizzoFatturazione() == -1) && !stato_acquisto.equals("incompleto")) {
        			
        				httpResponse.sendRedirect(httpRequest.getContextPath() + "/confermaAcquisto/indirizzo");
        				return;
        			}
        		
        			if(httpRequest.getServletPath().equals("/confermaAcquisto/finalizza")) {
        			
        				if(ordine.getTipoPagamento().equals("") && request.getParameter("metodo-pagamento") == null) {
        					httpResponse.sendRedirect(httpRequest.getContextPath() + "/confermaAcquisto/pagamento");
        					return;
        				}
        			}
        			
        			if(stato_acquisto.equals("successo")) {
        				session.removeAttribute("stato_acquisto");
        			}
        		}
        	} else {
        		if(httpRequest.getServletPath().equals("/confermaAcquisto/pagamento") && (ordine.getIdIndirizzoSpedizione() == -1 || ordine.getIdIndirizzoFatturazione() == -1)) {
        			httpResponse.sendRedirect(httpRequest.getContextPath() + "/confermaAcquisto/indirizzo");
					return;
        		}
        	}
        		
        	} catch (SQLException e) {
    			System.out.println("Error:" + e.getMessage());
    		}
        	
            chain.doFilter(request, response);
        } else {
        	// Utente non loggato
        	
            httpResponse.sendRedirect(httpRequest.getContextPath() + "/login.jsp?sendRedirect=confermaAcquisto");
            return;
        }
	}
}

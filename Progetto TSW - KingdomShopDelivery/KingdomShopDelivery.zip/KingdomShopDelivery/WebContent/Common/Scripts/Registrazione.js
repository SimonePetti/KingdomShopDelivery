function submitForm(form) {

	// Resetta tutti i messaggi di errore prima di eseguire la validazione
    let errorMessages = form.getElementsByClassName("form-error");
    let n_messaggi = errorMessages.length;
    for (let i = 0; i < n_messaggi; i++) {
        errorMessages[i].innerHTML = "";
    }
    document.getElementsByClassName("registrazione-error")[0].innerHTML = "";
	
	if(validateForm()) {
		let email = document.getElementById("email").value.trim();
		checkEmailExistence(email, form);
	}
}

function validateForm() {
		
	let valido = true;
		
	let nome = document.getElementById("nome").value.trim();
	let cognome = document.getElementById("cognome").value.trim();
	let email = document.getElementById("email").value.trim();
	let password = document.getElementById("password").value.trim();
	let prefissoTelefono = document.getElementById("prefissoTelefono").value.trim();
	let numeroTelefono = document.getElementById("numeroTelefono").value.trim();

	if (nome === "") {
    	valido = false;
        document.getElementById("error-nome").innerHTML = "Il campo nome è obbligatorio.";
    } else {
       	if(!checkNome(nome)) {
       		valido = false;
       		document.getElementById("error-nome").innerHTML = "Nome non valido, può contenere solo lettere e spazi.";
       	} 
    }
		
    if (cognome === "") {
        valido = false;
        document.getElementById("error-cognome").innerHTML = "Il campo cognome è obbligatorio.";
    } else {
      	if(!checkCognome(cognome)) {
      		valido = false;
      		document.getElementById("error-cognome").innerHTML = "Cognome non valido, può contenere solo lettere,spazi, apici singoli e trattini.";
       	}
    }
        
    if (email === "") {
        valido = false;
        document.getElementById("error-email").innerHTML = "Il campo email è obbligatorio.";
    } else {
       	if(!checkEmail(email)) {
      		valido = false;
      		document.getElementById("error-email").innerHTML = "Email non valida, può contenere solo lettere, spazi, apici singoli, trattini, punti, numeri e una @.";
       	}
    }
        
    if (password === "") {
        valido = false;
        document.getElementById("error-password").innerHTML = "Il campo password è obbligatorio.";
    } else {
      	if(!checkPassword(password)) {
       		valido = false;
       		document.getElementById("error-password").innerHTML = "Password non valida, deve essere lunga almeno 6 caratteri e contenere almeno: una lettera minuscola, una lettera maiuscola, un numero e un carattere speciale.";
       	}
    }
        
    if (prefissoTelefono === "") {
        valido = false;
        document.getElementById("error-prefissoTelefono").innerHTML = "Il campo prefisso telefonico è obbligatorio.";
    } else {
       	if(!checkPrefissoTelefono(prefissoTelefono)) {
       		valido = false;
       		document.getElementById("error-prefissoTelefono").innerHTML = "Prefisso telefonico non valido.";
       	}
    }
        
    if (numeroTelefono === "") {
        valido = false;
        document.getElementById("error-numeroTelefono").innerHTML = "Il campo numero di telefono è obbligatorio.";
    } else {
      	if(!checkNumeroTelefono(numeroTelefono)) {
       		valido = false;
       		document.getElementById("error-numeroTelefono").innerHTML = "Numero di telefono non valido.";
       	}
    }        
 return valido;
}	

function checkNome(nome) {
	let nomePattern = /^[A-Za-zÀ-Úà-ú]+(\s+[A-Za-zÀ-Úà-ú]+)*$/;
	return nome.match(nomePattern) ? true : false; 
}
	
function checkCognome(cognome) {
	let cognomePattern = /^[A-Za-zÀ-Úà-ú]+(\s*('|-)\s*[A-Za-zÀ-Úà-ú]+)?(\s+[A-Za-zÀ-Úà-ú]+)*$/;
	return cognome.match(cognomePattern) ? true : false;
}
	
function checkEmail(email) {
	let emailPattern = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
	return email.match(emailPattern) ? true : false;
}
	
function checkPassword(password) {
	let passwordPattern = /^(?=.*[A-ZÀ-Ù])(?=.*[a-zà-ù])(?=.*\d)(?=.*[^\w\d\s]).{6,}$/;
	return password.match(passwordPattern) ? true : false;
}
	
function checkPrefissoTelefono(prefissoTelefono) {
	let prefissoTelefonoPattern = /^([0-9]{1,3})$/;
	return prefissoTelefono.match(prefissoTelefonoPattern) ? true : false;
}
	
function checkNumeroTelefono(numeroTelefono) {
	let numeroTelefonoPattern = /^([0-9]{10})$/;
	return numeroTelefono.match(numeroTelefonoPattern) ? true : false;
}


function checkEmailExistence(email, form) {
	let xhr = new XMLHttpRequest();
    xhr.open("POST", "checkEmail", true);
    xhr.setRequestHeader("Content-Type", "application/json");
    xhr.setRequestHeader("Connection", "close");//Google, per esempio rifiuta questo header
        
    // Flag per determinare se la richiesta è stata abortita
    let aborted = false;

	// Timeout per abortire la richiesta dopo 10 secondi
    let timeout = setTimeout(function() {
    	if (xhr.readyState < 4) {
    		xhr.abort();
        	aborted = true;
        	document.getElementById("error-generico").innerHTML = "La richiesta di registrazione ha superato il tempo limite. Riprova più tardi.";
		}
	}, 10000); // 10 secondi    
       
	xhr.onreadystatechange = function() {
    	if(xhr.readyState === 4) {
    		clearTimeout(timeout); // Cancella il timeout se la richiesta è completata
        	if(!aborted) {
        		if(xhr.status === 200) {
        			//Richiesta andata a buon fine
            		let response = JSON.parse(xhr.responseText);
            		
            		const url = new URL(window.location.href);
            		const params = new URLSearchParams(url.search);
            		const sendRedirectParametro = params.get('sendRedirect');
            		let sendRedirect = "";
            		if(sendRedirectParametro && sendRedirectParametro == "confermaAcquisto") {
						sendRedirect = "?sendRedirect=confermaAcquisto";
					}
            		
            		if (response.EmailGiaPresente == "true") {
                		document.getElementById("error-email").innerHTML = "Esiste già un account con questa email. Vai alla pagina di <a href='login.jsp" + sendRedirect + "'>Login</a>";
                	} else {
						var inputsendRedirect = document.createElement('input');
        				inputsendRedirect.type = 'hidden';
        				inputsendRedirect.name = 'sendRedirect';
        				inputsendRedirect.value = sendRedirect;
        				form.appendChild(inputsendRedirect);
						form.submit();
					}
				} else {
            		//Altri problemi
            		document.getElementById("error-generico").innerHTML = "Errore durante la registrazione. Riprova più tardi.";
            	}	
        	}
		}
	};    
	xhr.send(JSON.stringify({ EmailDaControllare : email}));
}
function updateQuantita(prodottoId, tagliaId) {
	var elementoSelect = document.getElementById("quantitaProdotto_" + prodottoId + "_" + tagliaId);
	var quantita;
	
	if(prodottoId == -1 && tagliaId == -1) {
		quantita = -1;
	} else {
		quantita = elementoSelect.value;
	}
	
	var xhr = new XMLHttpRequest();
	xhr.open("POST", "carrello", true);
	xhr.setRequestHeader("Content-Type", 'application/x-www-form-urlencoded');
	xhr.setRequestHeader("Connection", "close");//Google lo rifiuta
	
	// Flag per determinare se la richiesta è stata abortita
    let aborted = false;

	// Timeout per abortire la richiesta dopo 10 secondi
    let timeout = setTimeout(function() {
    	if (xhr.readyState < 4) {
    		xhr.abort();
        	aborted = true;
        	document.getElementById("error-generico").innerHTML = "La richiesta ha superato il tempo limite. Riprova più tardi.";
		}
	}, 10000); // 10 secondi    
      
	xhr.onreadystatechange = function() {
    	if(xhr.readyState === 4) {
    		clearTimeout(timeout); // Cancella il timeout se la richiesta è completata
        	if(!aborted) {
        		if(xhr.status === 200) {
        			//Richiesta andata a buon fine
            		let response = JSON.parse(xhr.responseText);
            		if (response.ModificaEffettuata == "true") {
            			console.log("La modifica è stata effettuata con successo");
                	} else {
						document.getElementById("error-generico").innerHTML = "Si è verificato un errore. Riprova più tardi.";
					}
					aggiornaCarrello(response);
				} else {
            		document.getElementById("error-generico").innerHTML = "Si è verificato un errore. Riprova più tardi.";
            	}	
        	}
		}
	};
	xhr.send(JSON.stringify({ action : "modificaQuantita", idProdotto : prodottoId, idTaglia : tagliaId, quantitaNuova : quantita}));
}

var aggiungiMessaggioVariazionePrezzoProdotto = false;

function aggiornaCarrello(carrelloAggiornato) {
	
	var carrelloDisponibiliContenitore = document.getElementById("CarrelloDisponibili");
	var carrelloNonDisponibiliContenitore = document.getElementById("CarrelloNonDisponibili");
	var avvisiContenitore = document.getElementById("avvisi-contenitore");
	var informazioniTotaleContenitore = document.getElementById("contenitore-contenitore-informazioniPrezzoTotaleEconfermaAcquisto");
	
	var ContenitoriDaSpostareinCarrelloDisponibili = [];
	var ContenitoriDaSpostareinCarrelloNonDisponibili = [];
	
	var carrelloPrecedente = document.getElementsByClassName("prodotto");

	var carrelloPrecedenteArray = Array.from(carrelloPrecedente);
	
	var CarrelloAttuale;
	var CarrelloInCuiInserire;
	
	var aggiornaTotale = false;
	var aggiungiMessaggioEliminazioneProdotto = false;
	
	//Controllo quali prodotti devono essere spostati di carrello e nel frattempo controllo quali prodotti ci saranno nel nuovo carrello
	if(carrelloAggiornato.CarrelloProdottiDisponibili) {

		carrelloAggiornato.CarrelloProdottiDisponibili.forEach(function(prodotto) {
		controllaEPosizionaProdotto(prodotto, true, carrelloPrecedenteArray, ContenitoriDaSpostareinCarrelloDisponibili);
	});

		//Elimino i prodotti che non devono essere più nel carrello, se il carrelloNDT ha length maggiore di 0 (quindi ha un elemento al suo interno) allora fai:
		if(ContenitoriDaSpostareinCarrelloDisponibili.length > 0) {
			carrelloAggiornato.CarrelloProdottiDisponibili = carrelloAggiornato.CarrelloProdottiDisponibili.filter(function(prodotto) {
				return !ContenitoriDaSpostareinCarrelloDisponibili.some(function(prodottoSpostato) {
					return prodottoSpostato.id == prodotto.id && prodottoSpostato.id_taglia == prodottoSpostato.id_taglia;
				});
			});
		}
	}

	if(carrelloAggiornato.CarrelloProdottiNonDisponibili) {
		carrelloAggiornato.CarrelloProdottiNonDisponibili.forEach(function(prodotto) {
			controllaEPosizionaProdotto(prodotto, false, carrelloPrecedenteArray, ContenitoriDaSpostareinCarrelloNonDisponibili);
		});
		
		if(ContenitoriDaSpostareinCarrelloNonDisponibili.length > 0) {
			carrelloAggiornato.CarrelloProdottiNonDisponibili = carrelloAggiornato.CarrelloProdottiNonDisponibili.filter(function(prodotto) {
				return !ContenitoriDaSpostareinCarrelloNonDisponibili.some(function(prodottoSpostato) {
					return prodottoSpostato.id == prodotto.id && prodottoSpostato.id_taglia == prodottoSpostato.id_taglia;
				});
			});
		}
	}
	
	if(!carrelloDisponibiliContenitore) {

		if(carrelloAggiornato.CarrelloProdottiDisponibili.length > 0 || ContenitoriDaSpostareinCarrelloDisponibili.length > 0 || ContenitoriDaSpostareinCarrelloDisponibili.length > 0) {
			
			carrelloDisponibiliContenitore = document.createElement("div");
			carrelloDisponibiliContenitore.class="CarrelloDisponibili";
			carrelloDisponibiliContenitore.id = "CarrelloDisponibili";
			carrelloDisponibiliContenitore.innerHTML = `<h2 class="nome_sezione" id="Carrello">Carrello</h2>`;
			
			//il contenitore del totale non esiste, crealo
			informazioniTotaleContenitore = document.createElement("div");
			informazioniTotaleContenitore.className = "contenitore-contenitore-informazioniPrezzoTotaleEconfermaAcquisto";
			
			//il contenitore-carrelli non esiste, crealo
			let contenitore_carrello = document.getElementById("contenitore-carrello");
			let contenitore_carrelli = document.createElement("div");
			contenitore_carrelli.className = "contenitore-carrelli";
			contenitore_carrelli.id = "contenitore-carrelli";
			
			//Rimuovo il messaggio di andare ad esplorare la home
			document.getElementById("carrelloDisponibili_vuoto").remove();
			
			contenitore_carrelli.appendChild(carrelloDisponibiliContenitore);
			if(carrelloNonDisponibiliContenitore) {contenitore_carrelli.appendChild(carrelloNonDisponibiliContenitore)}
			contenitore_carrello.appendChild(contenitore_carrelli);
			
			aggiornaTotale = true;
		}
	} else {
		if(carrelloAggiornato.CarrelloProdottiDisponibili.length == 0 && ContenitoriDaSpostareinCarrelloNonDisponibili.length == 0 && ContenitoriDaSpostareinCarrelloDisponibili.length == 0) {

			carrelloDisponibiliContenitore.remove();
			informazioniTotaleContenitore.remove();
			
			let contenitore_carrelli = document.getElementById("contenitore-carrelli");
			contenitore_carrelli.replaceWith(...contenitore_carrelli.childNodes); // ... serve per passare tutti i figli di contenitore_carrelli come argomenti separati al metodo replacewith
			let carrello_vuoto = document.createElement("div");
			carrello_vuoto.class = "carrelloDisponibili_vuoto";
			carrello_vuoto.id = "carrelloDisponibili_vuoto";
			carrello_vuoto.innerHTML = `<div align='center'>
							<h2 align='center'>Carrello vuoto</h2> 
							<a href='home.jsp' style="justify-content : center; align-items : center">Esplora prodotti</a>
						</div>`;
			document.getElementById("contenitore-carrello").insertBefore(carrello_vuoto, document.getElementById("contenitore-carrello").firstChild);
		} else {
			aggiornaTotale = true;
		}
	}

	if(!carrelloNonDisponibiliContenitore) {
		if(carrelloAggiornato.CarrelloProdottiNonDisponibili.length > 0 || ContenitoriDaSpostareinCarrelloNonDisponibili.length > 0) {
			//Se il contenitore non esiste, crealo...
			carrelloNonDisponibiliContenitore = document.createElement("div");
			carrelloNonDisponibiliContenitore.id = "CarrelloNonDisponibili";
			carrelloNonDisponibiliContenitore.className = "CarrelloNonDisponibili";
			carrelloNonDisponibiliContenitore.innerHTML = "<h2 class='nome_sezione' id='NonDisponibile'>Non Disponibile</h2>";
			
			//Aggiungi come primo figlio
			let contenitore_carrelli = document.getElementById("contenitore-carrelli");
			
			if(contenitore_carrelli) {
				contenitore_carrelli.appendChild(carrelloNonDisponibiliContenitore);	
			} else {
				document.getElementById("sezione-carrello").appendChild(carrelloNonDisponibiliContenitore);	
			}
		}
	} else {
		//CarrelloNonDisponibileEsiste
		if(carrelloAggiornato.CarrelloProdottiNonDisponibili.length == 0 && ContenitoriDaSpostareinCarrelloNonDisponibili.length == 0) {
			carrelloNonDisponibiliContenitore.remove();
		}
	}
	
	//Aggiorna i prodotti disponibili
	if(carrelloAggiornato.CarrelloProdottiDisponibili) {
		carrelloAggiornato.CarrelloProdottiDisponibili.forEach(function(prodotto) {
			aggiornaOcreaProdotto(carrelloDisponibiliContenitore, prodotto, true);
		});
	} 
	
	//Aggiorna i prodotti non disponibili
	if(carrelloAggiornato.CarrelloProdottiNonDisponibili) {
		carrelloAggiornato.CarrelloProdottiNonDisponibili.forEach(function(prodotto) {
			aggiornaOcreaProdotto(carrelloNonDisponibiliContenitore, prodotto, false);
		})
	}
	
	//Ora prendo i contenitori da spostare e li aggiungo ai rispettivi carrelli...
	if(ContenitoriDaSpostareinCarrelloDisponibili.length > 0) {
		ContenitoriDaSpostareinCarrelloDisponibili.forEach(function(prodotto) {
			CarrelloAttuale = document.getElementById("CarrelloNonDisponibili");
			CarrelloInCuiInserire = document.getElementById("CarrelloDisponibili");
			spostaContenitoreNellAltroCarrello(prodotto, CarrelloAttuale, CarrelloInCuiInserire, false, true);
		});
	}
	
	if(ContenitoriDaSpostareinCarrelloNonDisponibili.length > 0) {
		ContenitoriDaSpostareinCarrelloNonDisponibili.forEach(function(prodotto) {
			CarrelloAttuale = document.getElementById("CarrelloDisponibili");
			CarrelloInCuiInserire = document.getElementById("CarrelloNonDisponibili");
			spostaContenitoreNellAltroCarrello(prodotto, CarrelloAttuale, CarrelloInCuiInserire, true, false);
		});
	}
	
	//Controlla i vari contenitori e vedi quali mantenere/togliere
	if(carrelloPrecedenteArray.length > 0) {
		carrelloPrecedenteArray.forEach(function(prodottoContenitore) {
			prodottoContenitore.remove();
		});
		aggiungiMessaggioEliminazioneProdotto = true;
	}
	
	//Aggiorna informazioni prezzo totale se esiste il contenitore dei prodotti Disponibili
	if(aggiornaTotale) {
		aggiornaInformazioniTotale(informazioniTotaleContenitore, carrelloAggiornato.CarrelloInformazioniTotale);
	}
	
	//Aggiorna gli avvisi
	if(aggiungiMessaggioVariazionePrezzoProdotto) {carrelloAggiornato.Messaggi.push({id_tag : 'MessaggioVariazionePrezzoProdotto', Messaggio : 'Il prezzo di alcuni prodotti è stato aggiornato.'});}
	if(aggiungiMessaggioEliminazioneProdotto) {carrelloAggiornato.Messaggi.push({id_tag : 'MessaggioEliminazioneProdotto', Messaggio : 'Alcuni articoli sono stati eliminati.'});}

	if(carrelloAggiornato.Messaggi) {
		if(!avvisiContenitore) {
			avvisiContenitore = document.createElement("div");
			avvisiContenitore.className = "avvisi-contenitore";
			avvisiContenitore.id = "avvisi-contenitore";
			document.body.insertBefore(avvisiContenitore, document.getElementById("contenitore-carrello"));
		}
		aggiornaAvvisi(avvisiContenitore, carrelloAggiornato.Messaggi);
	}
	
}

function aggiornaInformazioniTotale(informazioniTotaleContenitore, informazioniTotale) {
	
	if(informazioniTotaleContenitore.hasChildNodes()) {
		if(document.getElementById("Subtotale-valore").innerHTML != informazioniTotale.subtotale) {document.getElementById("Subtotale-valore").innerHTML = informazioniTotale.subtotale;}
		if(document.getElementById("CostoSpedizione-valore").innerHTML != informazioniTotale.costo_spedizione) {document.getElementById("CostoSpedizione-valore").innerHTML = informazioniTotale.costo_spedizione;}
		if(document.getElementById("CostoTotale-valore").innerHTML != informazioniTotale.costo_totale) {document.getElementById("CostoTotale-valore").innerHTML = informazioniTotale.costo_totale;}

	} else {

		informazioniTotaleContenitore.innerHTML = ` 
		<h2 class="nome_sezione" id="Totale">Totale</h2>
			<div class="contenitore-contenitore-informazioniPrezzoTotale">
				<div id="contenitore-SubTotale">
            		<span id="Subtotale">Subtotale:</span>
            		<span id="Subtotale-valore">` + informazioniTotale.subtotale + `</span>
            		<span id="Subtotale-valuta">€</span>
            	</div>
            	<div id="contenitore-CostoSpedizione">
            		<span id="CostoSpedizione">Spedizione:</span>
            		<span id="CostoSpedizione-valore">` + informazioniTotale.costo_spedizione + `</span>
            		<span id="CostoSpedizione-valuta">€</span>
            	</div>
            	<div id="contenitore-CostoTotale">
            		<span id="CostoTotale">Totale (IVA inclusa)</span>
            		<span id="CostoTotale-valore">` + informazioniTotale.costo_totale + `</span>
            		<span id="CostoTotale-valuta">€</span>
            	</div>
            </div>
            <form id="formCarrello" method="POST" action="confermaAcquisto" onSubmit="event.preventDefault(); confermaOrdine()">
            	<button type="submit" id="confermaAcquisto" class="confermaAcquisto">Procedi all'acquisto</button><br/>
            </form>
		`;
	}
}

function spostaContenitoreNellAltroCarrello(prodotto, CarrelloAttuale, CarrelloInCuiInserire, isDisponibileAttualmente, isDisponibile) {
	
	var id_contenitoreProdotto = "prodotto_" + prodotto.id_prodotto + "_" + prodotto.id_taglia;
	var contenitoreProdotto = document.getElementById(id_contenitoreProdotto);
	var nuovaClasse = isDisponibileAttualmente ? "non-disponibile" : "disponibile";
	
	//Modifica il prodotto, se necessario
	if(isDisponibileAttualmente) {
		document.getElementById("prodotto_contenuto_quantita_" + prodotto.id_prodotto + "_" + prodotto.id_taglia).remove();
		aggiornaContenitoreProdotto(prodotto, isDisponibile);
	} else {
		var contenitoreSelect = document.createElement("div");
		contenitoreSelect.className = "prodotto_contenuto_quantita";
		contenitoreSelect.id = "prodotto_contenuto_quantita_" + prodotto.id_prodotto + "_" + prodotto.id_taglia;
		contenitoreSelect.innerHTML = "<select id='quantitaProdotto_" + prodotto.id_prodotto + "_" + prodotto.id_taglia + "' onChange='updateQuantita(" + prodotto.id_prodotto + "," + prodotto.id_taglia + ")'></select>";
		document.getElementById("prodotto_contenuto_informazioni_" + prodotto.id_prodotto + "_" + prodotto.id_taglia).insertBefore(contenitoreSelect, document.getElementById("prodotto_contenuto_parte_inferiore_" + prodotto.id_prodotto + "_" + prodotto.id_taglia));
		aggiornaContenitoreProdotto(prodotto, isDisponibile);
	}

	contenitoreProdotto.classList.replace(contenitoreProdotto.classList[1], nuovaClasse);
	//Rimuovo il contenitore
	CarrelloAttuale.removeChild(contenitoreProdotto);
	//Aggiungi a destinazione
	CarrelloInCuiInserire.insertBefore(contenitoreProdotto, CarrelloInCuiInserire.firstElementChild.nextSibling);//IL primo elemento è la scritta Non Disponibile/Disponibile
}

function aggiornaOcreaProdotto(contenitoreCarrello, prodotto, isDisponibile) {
	var id_contenitoreProdotto = "prodotto_" + prodotto.id_prodotto + "_" + prodotto.id_taglia;
	var contenitoreProdotto = document.getElementById(id_contenitoreProdotto);
	
	if(!contenitoreProdotto) {
		//Crea un nuovo elemento perchè non esiste
		contenitoreProdotto = creaContenitoreProdotto(prodotto, isDisponibile);

		contenitoreCarrello.insertBefore(contenitoreProdotto, contenitoreCarrello.firstElementChild.nextSibling);//da firstChild a fistChild.nextSibling, firstChild a firstElementChild
	} else {
		//Aggiorna il prodotto esistente
		aggiornaContenitoreProdotto(prodotto, isDisponibile);
	}
}

function aggiornaContenitoreProdotto(prodotto, isDisponibile) {
	
	var prodotto_id = prodotto.id_prodotto + "_" + prodotto.id_taglia;
	
	var immagineAttuale = document.getElementById("prodotto_immagine_" + prodotto_id).children[0];
	var marcaProdottoAttuale = document.getElementById("prodotto_contenuto_dettagli_" + prodotto_id).children[0];
	var nomeProdottoAttuale = document.getElementById("prodotto_contenuto_dettagli_" + prodotto_id).children[1];
	var nomeTagliaAttuale = document.getElementById("prodotto_contenuto_dettagli_" + prodotto_id).children[2];
	var prezzoTagliaAttuale = document.getElementById("prezzoProdotto_" + prodotto_id);
	var prezzoInizialeAttuale = document.getElementById("prezzoInizialeProdotto_" + prodotto_id);
	var percentualeScontoAttuale = document.getElementById("percentualeScontoProdotto_" + prodotto_id);
	var ivaAttuale = document.getElementById("prodotto_contenuto_iva_" + prodotto_id).children[0];
	
	if(immagineAttuale.src != "data:image/jpeg;base64," + prodotto.immagine && prodotto.immagine != "") {
		immagineAttuale.src = "data:image/jpeg;base64," + prodotto.immagine;
	}
	if(immagineAttuale.alt != prodotto.nome_prodotto) {immagineAttuale.alt = prodotto.nome_prodotto;}
	
	if(marcaProdottoAttuale.innerHTML != prodotto.marca_prodotto) {marcaProdottoAttuale.innerHTML = prodotto.marca_prodotto;}
	if(nomeProdottoAttuale.innerHTML != prodotto.nome_prodotto) {nomeProdottoAttuale.innerHTML = prodotto.nome_prodotto;}
	if(nomeTagliaAttuale.innerHTML != prodotto.nome_taglia) {nomeTagliaAttuale.innerHTML = prodotto.nome_taglia;}
	
	if(isDisponibile) { 
		let select = document.getElementById("quantitaProdotto_" + prodotto_id);
		let quantitaMassimaSelezionabile = 1;
		let n_opzioni;
			
		if(prodotto.quantita_disponibile_taglia > 10) {
			quantitaMassimaSelezionabile = 10;
		} else {
			quantitaMassimaSelezionabile = prodotto.quantita_disponibile_taglia;
		}
		
		if((!select.selectedOptions[0] || select.selectedOptions[0].value != prodotto.quantita_inserita) && select.options.length != quantitaMassimaSelezionabile) {
			n_opzioni = select.options.length;
			
			//Rimuovi gli elementi in eccesso
			while(n_opzioni > quantitaMassimaSelezionabile) {
				select.options[n_opzioni -1].remove();
				n_opzioni--;
			}
			
			//Aggiungi options mancanti se ci sono
			while(n_opzioni < quantitaMassimaSelezionabile) {
				let nuovaOpzione = document.createElement("option");
				nuovaOpzione.value = n_opzioni + 1;
				nuovaOpzione.innerHTML = n_opzioni + 1;
				select.appendChild(nuovaOpzione);
				n_opzioni++;
			}
			
			for(var i = 0; i < n_opzioni; i++) {
				let opzione = select.options[i];
				if(opzione.value == prodotto.quantita_inserita) {
					opzione.selected = true;
				} else {
					opzione.selected = false;
				}
			}
		} 
	}
	
	/* Parte per aggiornare i bottoni...*/
	if(prezzoTagliaAttuale.innerHTML != prodotto.prezzo_taglia) {prezzoTagliaAttuale.innerHTML = prodotto.prezzo_taglia; aggiungiMessaggioVariazionePrezzoProdotto = true;}
	
	if(prodotto.taglia_in_offerta) {
		if(prezzoInizialeAttuale.innerHTML != prodotto.prezzo_iniziale) {prezzoInizialeAttuale.innerHTML = prodotto.prezzo_iniziale;}
		if(percentualeScontoAttuale.innerHTML != prodotto.percentuale_sconto) {percentualeScontoAttuale.innerHTML = prodotto.percentuale_sconto;}
	} else {
		if(prezzoInizialeAttuale) {
			document.getElementById("prodotto_contenuto_prezzo_" + prodotto_id).removeChild(prezzoInizialeAttuale);
			document.getElementById("prodotto_contenuto_prezzo_" + prodotto_id).removeChild(percentualeScontoAttuale);
		}
	}
	
	var ivaNuova = "IVA(%):" + prodotto.iva;

	if(ivaAttuale.innerHTML != ivaNuova) {ivaAttuale.innerHTML = "IVA(%):" + prodotto.iva;}
}

function creaContenitoreProdotto(prodotto, isDisponibile) {
	var contenitoreProdotto = document.createElement("div");
	contenitoreProdotto.className = isDisponibile ? "prodotto disponibile" : "prodotto non-disponibile";
	contenitoreProdotto.id = "prodotto_" + prodotto.id_prodotto + "_" + prodotto.id_taglia;
	contenitoreProdotto.innerHTML = inserisciInContenitoreProdotto(prodotto);
	return contenitoreProdotto;
}

function inserisciInContenitoreProdotto(prodotto) {
	
	var select = creaSelectQuantita(prodotto.quantita_disponibile_taglia, prodotto.quantita_inserita, prodotto);
	
	var prezzo = `<div><span id="prezzoProdotto_` + prodotto.id_prodotto + `_` + prodotto.id_taglia + `">` + prodotto.prezzo_taglia + `</span><span>€</span></div>`;
	
	if(prodotto.taglia_in_offerta == true) {
		prezzo += `\n <span id="prezzoInizialeProdotto_` + prodotto.id_prodotto + `_` + prodotto.id_taglia + `">` + prodotto.prezzo_iniziale + `</span>
				   <span id="percentualeScontoProdotto_` + prodotto.id_prodotto + `_` + prodotto.id_taglia + `">` + prodotto.percentuale_sconto + `</span>`;
	}
	
	var dettagli = `
		<div class="prodotto_immagine" id="prodotto_immagine_` + prodotto.id_prodotto + `_` + prodotto.id_taglia + `">
			<img src="data:image/jpeg;base64,` + prodotto.immagine + `" alt="` + prodotto.nome_prodotto + `" height="50">
		</div>
		<div class="prodotto_contenuto" id="prodotto_contenuto_` + prodotto.id_prodotto + `_` + prodotto.id_taglia + `">
			<div class="prodotto_contenuto_informazioni" id="prodotto_contenuto_informazioni_` + prodotto.id_prodotto + `_` + prodotto.id_taglia + `">
				<div class="prodotto_contenuto_dettagli" id="prodotto_contenuto_dettagli_` + prodotto.id_prodotto + `_` + prodotto.id_taglia + `">
					<h2 class="prodotto_marca">` + prodotto.marca_prodotto + `</h2>
            		<h1 class="prodotto_nome">` + prodotto.nome_prodotto + `</h1>
            		<h2 class="prodotto_taglia">` + prodotto.nome_taglia + `</h2>
				</div>
				` + select + `
				<div class="prodotto_contenuto_parte-inferiore" id="prodotto_contenuto_parte_inferiore_` + prodotto.id_prodotto + `_` + prodotto.id_taglia + `">
					<div class="prodotto_contenuto_bottoni" id="prodotto_contenuto_bottoni_` + prodotto.id_prodotto + `_` + prodotto.id_taglia + `">
						<a href="prodotto?id=` + prodotto.id_prodotto + `" target="_blank">Dettagli</a>
                    	<a href="wishlist?action=add&id=` + prodotto.id_prodotto + `">Aggiungi a wishlist</a><!-- Da modificare -->
                    	<a href="carrello?action=delete&id=` + prodotto.id_prodotto + `taglia=` + prodotto.id_taglia + `">Elimina dal carrello</a>
					</div>
					<div class="prodotto_contenuto_prezzo" id="prodotto_contenuto_prezzo_` + prodotto.id_prodotto + `_` + prodotto.id_taglia + `">
						` + prezzo + `
					</div>
					<div class="prodotto_contenuto_iva" id="prodotto_contenuto_iva_` + prodotto.id_prodotto + `_` + prodotto.id_taglia + `">
						<h3 class="prodotto_iva">`+ "IVA (%): " + prodotto.iva + `</h3>
					</div>
				</div>
			</div>
		</div>
	`;
	
	return dettagli;
}

function creaSelectQuantita(quantitaDisponibileTaglia, quantitaInserita, prodotto) {

	var opzioni = ``;
    var select = ``;
    var quantitaMassimaSelezionabile;
        
    if(quantitaDisponibileTaglia > 0) {
			
		quantitaMassimaSelezionabile = 1;
			
		if(quantitaDisponibileTaglia > 10) {
			quantitaMassimaSelezionabile = 10;
		} else {
			quantitaMassimaSelezionabile = quantitaDisponibileTaglia;
		}
	
		for(var i = 1; i <= quantitaMassimaSelezionabile; i++) {
			if(i == quantitaInserita) {
				opzioni += `<option value="` + i + `" selected="selected">` + i + `</option>\n`;
			} else {
				opzioni += `<option value="` + i + `">` + i + `</option>\n`;
			} 
		}
			
		select = `<div class="prodotto_contenuto_quantita" id="prodotto_contenuto_quantita_` + prodotto.id_prodotto + `_` + prodotto.id_taglia + `">
				<select id="quantitaProdotto_` + prodotto.id_prodotto + `_` + prodotto.id_taglia + `" onChange="updateQuantita(` + prodotto.id_prodotto + `,` + prodotto.id_taglia + `)">
					` + opzioni + `
				</select>
			</div>`;
		return select;
	}
	return select;
}

function controllaEPosizionaProdotto(prodotto, isDisponibile, carrelloPrecedente, CarrelloTemp) {
	
	var id_contenitoreProdotto = "prodotto_" + prodotto.id_prodotto + "_" + prodotto.id_taglia;
	var contenitoreProdotto = document.getElementById(id_contenitoreProdotto);
	
	//se esiste, controllo se la posizione nel carrelloEGiusta
	if(contenitoreProdotto) {
		
		for (var i = 0; i < carrelloPrecedente.length; i++) {
			if (carrelloPrecedente[i].id === id_contenitoreProdotto) {
				carrelloPrecedente.splice(i, 1);
				break;
			}
		}
		//se il prodotto non si trova nel contenitore corretto, lo sposto in quello temporaneo
		if(isDisponibile != (contenitoreProdotto.classList[1] == "disponibile" ? true : false)) {
			CarrelloTemp.push(prodotto);
		}
	}
}

function aggiornaAvvisi(contenitore, messaggi) {
	contenitore.innerHTML = ""; //Puliamo i messaggi
	
	messaggi.forEach(function (messaggio) {
		var divMessaggio = document.createElement("div");
		divMessaggio.id = messaggio.id_tag;
		divMessaggio.className = "avviso";
		divMessaggio.innerHTML = messaggio.Messaggio;
		contenitore.appendChild(divMessaggio);
	});
}




function confermaOrdine() {

	var carrelloDaVerificare = preparaCarrelloDaVerificare();
	
	var form = document.getElementById("formCarrello");
	
	//Chiamata AJAX per verificare quantità e prezzi, invia form
	verificaCarrello(carrelloDaVerificare, form);
}

function preparaCarrelloDaVerificare() {
	var prodottiDaVerificare = [];
	var prodotti = document.getElementsByClassName("disponibile");
	var n_prodotti = prodotti.length;
	
	for(var i=0; i < n_prodotti; i++) {
		var prodotto = prodotti[i];
		
		// Utilizziamo il metodo split() per dividere la stringa in base al carattere _
		var InfoProdotto = prodotto.getAttribute("id").split('_');

		// Ora parti[0] conterrà l'id del prodotto e parti[1] conterrà la taglia del prodotto
		var id_prodotto = InfoProdotto[1];
		var id_taglia_prodotto = InfoProdotto[2];
		
		var prezzo = document.getElementById("prezzoProdotto_" + id_prodotto + "_" + id_taglia_prodotto).innerHTML;
		
		prodottiDaVerificare.push({
			id : id_prodotto,
			idTaglia : id_taglia_prodotto,
			prezzoProdotto : prezzo 
		});
	}
	return prodottiDaVerificare;
}

function verificaCarrello(carrello, form) {
	var xhr = new XMLHttpRequest();
	xhr.open("POST", "procediAllAcquisto", true);
	xhr.setRequestHeader("Content-Type", "application/json");
	xhr.setRequestHeader("Connection", "close");
	
	// Flag per determinare se la richiesta è stata abortita
    let aborted = false;

	// Timeout per abortire la richiesta dopo 10 secondi
    let timeout = setTimeout(function() {
    	if (xhr.readyState < 4) {
    		xhr.abort();
        	aborted = true;
        	document.getElementById("error-generico").innerHTML = "La richiesta ha superato il tempo limite. Riprova più tardi.";
		}
	}, 10000); // 10 secondi    
      
	xhr.onreadystatechange = function() {
    	if(xhr.readyState === 4) {
    		clearTimeout(timeout); // Cancella il timeout se la richiesta è completata
        	if(!aborted) {
        		if(xhr.status === 200) {
        			//Richiesta andata a buon fine
            		let response = JSON.parse(xhr.responseText);
            		
            		if(response.contatoreModifiche > 0) {
						updateQuantita(-1,-1);
					} else {
							form.submit();	
						}
				} else {
            		document.getElementById("error-generico").innerHTML = "Errore. Riprova più tardi.";
            	}	
        	}
		}
	};
	xhr.send(JSON.stringify({ Azione : "verificaCarrello", CarrelloDaVerificare : carrello }));
}
document.addEventListener('DOMContentLoaded', function () {
    var searchInput = document.getElementById('searchInput');
    var suggestionsList = document.getElementById('suggestionsList');
    var searchButton = document.getElementById('searchButton');
    var overlay = document.createElement('div');
    overlay.className = 'dark-overlay';
    document.body.appendChild(overlay);

    searchInput.addEventListener('input', function () {
        var query = searchInput.value;
	
        if (query.length >= 2) {

            var xhr = new XMLHttpRequest();
            xhr.open('GET', './suggerimenti?query=' + encodeURIComponent(query), true);
            xhr.setRequestHeader('Content-Type', 'application/json');
            xhr.onreadystatechange = function () {
                if (xhr.readyState === 4 && xhr.status === 200) {
                    var risposta = JSON.parse(xhr.responseText);
                    var suggerimenti = risposta.Suggerimenti;
                    suggestionsList.innerHTML = '';
                    if(suggerimenti.length > 0) {
						suggerimenti.forEach(function (suggestion) {
                        	var li = document.createElement('li');
                       		li.classList.add('list-group-item');
                        	li.textContent = suggestion;
                        	li.addEventListener('click', function () {
                            	searchInput.value = suggestion;
                            	suggestionsList.innerHTML = '';
                            	window.location.href = './risultati?query=' + encodeURIComponent(suggestion);
                        	});
                        	suggestionsList.appendChild(li);
                    	});
                    	suggestionsList.style.display = 'block';
                    	overlay.style.display = 'block';  // Mostra l'overlay
					} else {
						suggestionsList.style.display = 'none';
                        overlay.style.display = 'none';
					}
                } else {
					suggestionsList.innerHTML = '';
                    suggestionsList.style.display = 'none';
                    overlay.style.display = 'none';  // Mostra l'overlay
				}
            };
            xhr.send();
        } else {
            suggestionsList.innerHTML = '';
            suggestionsList.style.display = 'none';
            overlay.style.display = 'none';  // Nascondi l'overlay
        }
    });  
    
searchButton.addEventListener('click', function (event) {
        event.preventDefault();
        var query = searchInput.value;
        if (query.length > 0) {
            window.location.href = 'risultati?query=' + encodeURIComponent(query);
        }
    });

    searchInput.addEventListener('focus', function () {
        if (searchInput.value.length >= 2) {
            overlay.style.display = 'block';
        }
    });

    overlay.addEventListener('click', function () {
        overlay.style.display = 'none';
        suggestionsList.innerHTML = '';  // Nascondi i suggerimenti
        suggestionsList.style.display = 'none';
        searchInput.blur();
    });
    
    // Aggiungi evento di gestione del clic sul documento per nascondere i suggerimenti
    document.addEventListener('click', function (event) {
        if (!searchInput.contains(event.target) && !suggestionsList.contains(event.target)) {
            suggestionsList.innerHTML = '';  // Nascondi i suggerimenti
            suggestionsList.style.display = 'none';  // Nascondi i suggerimenti
            overlay.style.display = 'none';  // Nascondi l'overlay
        }
    });
}); 
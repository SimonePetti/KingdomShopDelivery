function submitForm(form) {
	
	// Resetta tutti i messaggi di errore prima di eseguire la validazione
    let errorMessages = form.getElementsByClassName("form-error");
    let n_messaggi = errorMessages.length;
    for (let i = 0; i < n_messaggi; i++) {
        errorMessages[i].innerHTML = "";
    }
    if(document.getElementById("registrazione-successo") != null) {document.getElementById("registrazione-successo").innerHTML = "";}
    
	if(validateForm()) {
		
	   const url = new URL(window.location.href);
       const params = new URLSearchParams(url.search);
       const sendRedirectParametro = params.get('sendRedirect');
       let sendRedirect = "";
       if(sendRedirectParametro && sendRedirectParametro == "confermaAcquisto") {
			sendRedirect = "confermaAcquisto";
		}
		var inputsendRedirect = document.createElement('input');
        inputsendRedirect.type = 'hidden';
        inputsendRedirect.name = 'sendRedirect';
        inputsendRedirect.value = sendRedirect;
        form.appendChild(inputsendRedirect);
		form.submit();
	}
}

function validateForm() {
		
	let valido = true;

	let email = document.getElementById("email").value.trim();
	let password = document.getElementById("password").value.trim();
        
    if (email === "") {
        valido = false;
        document.getElementById("error-email").innerHTML = "Il campo email è obbligatorio.";
    } else {
       	if(!checkEmail(email)) {
      		valido = false;
      		document.getElementById("error-email").innerHTML = "Email non valida";
       	}
    }
        
    if (password === "") {
        valido = false;
        document.getElementById("error-password").innerHTML = "Il campo password è obbligatorio.";
    } else {
      	if(!checkPassword(password)) {
       		valido = false;
       		document.getElementById("error-password").innerHTML = "Password non valida";
       	}
    }   
 return valido;
}	

function checkEmail(email) {
	let emailPattern = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
	return email.match(emailPattern) ? true : false;
}
	
function checkPassword(password) {
	let passwordPattern = /^(?=.*[A-Z])(?=.*[a-z])(?=.*\d)(?=.*[^\w\d\s]).{6,}$/;
	return password.match(passwordPattern) ? true : false;
}
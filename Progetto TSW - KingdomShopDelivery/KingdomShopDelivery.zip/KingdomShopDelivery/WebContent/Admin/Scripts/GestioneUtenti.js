function confermaModifica(event, id_utente, nuovo_ruolo) {
    event.preventDefault();
    
    var conferma = confirm("Sei sicuro di voler cambiare il ruolo di questo utente?");
    if (conferma) {
        var url = "./modificaRuolo?utente=" + id_utente + "&ruolo=" + nuovo_ruolo;
        
        window.location.href = url;
    }
}
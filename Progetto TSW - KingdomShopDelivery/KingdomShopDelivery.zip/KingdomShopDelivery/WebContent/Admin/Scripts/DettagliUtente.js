function submitForm(form) {
	
    let errorMessages = form.getElementsByClassName("form-error");
    let n_messaggi = errorMessages.length;
    for (let i = 0; i < n_messaggi; i++) {
        errorMessages[i].innerHTML = "";
    }

	if(validateForm()) {		
		form.submit();
	}
}

function validateForm() {
		
	let valido = true;
		
	let data_inizio = document.getElementById("dataInizio").value;
	let data_fine = document.getElementById("dataFine").value;
	
	if(data_inizio == "" && data_fine == "") {
		window.location.href= window.location;
		valido = false;
	} else {

		if(data_inizio != "" && data_fine != "" && data_inizio > data_fine) {
			document.getElementById("filtroData").innerHTML = "La data di fine non può essere minore di quella di inizio";
			valido = false;
		}	
	}
	
	return valido;
}
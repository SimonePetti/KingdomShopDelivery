function confermaEliminazione(event, idProdotto) {
    event.preventDefault();
    
    var conferma = confirm("Sei sicuro di voler eliminare questo prodotto?");
    if (conferma) {
        var url = "./eliminaProdotto?id=" + idProdotto;
        
        window.location.href = url;
    }
}

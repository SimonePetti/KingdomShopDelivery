function submitForm(form) {
	
    let errorMessages = form.getElementsByClassName("form-error");
    let n_messaggi = errorMessages.length;
    for (let i = 0; i < n_messaggi; i++) {
        errorMessages[i].innerHTML = "";
    }

	if(validateForm()) {		
		form.submit();
	}
}

function validateForm() {
		
	let valido = true;
		
	let nome = document.getElementById("nome").value.trim();
	let marca = document.getElementById("marca").value.trim();
	let descrizione = document.getElementById("descrizione").value.trim();
	let categoria = document.getElementById("categoria").value;
	let sotto_categoria = document.getElementById("sottocategoria").value;
	let iva = document.getElementById("iva").value.trim();	

	if (nome === "") {
    	valido = false;
        document.getElementById("error-nome").innerHTML = "Il campo nome è obbligatorio.";
    } else {
		if(nome.length > 100) {
			valido = false;
			document.getElementById("error-nome").innerHTML = "Il nome non può superare i 100 caratteri.";
		} else {
			if(!checkNome(nome)) {
       			valido = false;
       			document.getElementById("error-nome").innerHTML = "Nome non valido, può contenere solo lettere e spazi.";
       		} 
		}
    }
		
    if (marca === "") {
        valido = false;
        document.getElementById("error-marca").innerHTML = "Il campo cognome è obbligatorio.";
    } else {
		if(marca.length > 100) {
			valido = false;
			document.getElementById("error-marca").innerHTML = "La marca non può superare i 100 caratteri.";
		} else {
			if(!checkMarca(marca)) {
      			valido = false;
      			document.getElementById("error-marca").innerHTML = "Marca non valida, può contenere solo lettere, spazi, apici singoli, trattini e numeri.";
       		}
		}
    }
        
    if(descrizione === "") {
		valido = false;
		document.getElementById("error-descrizione").innerHTML = "Il campo descrizione è obbligatorio.";
	} else {
		if(descrizione.length > 2000) {
			valido = false;
			document.getElementById("error-descrizione").innerHTML = "La descrizione non può superare i 2000 caratteri";
		}
	}
        
    if (categoria === "") {
        valido = false;
        document.getElementById("error-categoria").innerHTML = "Il campo categoria è obbligatorio.";
    } else {
     	if(sotto_categoria === "" && categoria === "Armatura") {
			valido = false;
			document.getElementById("error-sottocategoria").innerHTML = "Il campo sottocategoria è obbligatorio per la categoria Armatura.";
		} else {
			if(sotto_categoria != "" && categoria != "Armatura") {
				valido = false;
				document.getElementById("error-sottocategoria").innerHTML = "Il campo sottocategoria è da inserire solo per la categoria Armatura.";
			}
		}
    }
    
    if(iva === "") {
		valido = false;
		document.getElementById("iva").innerHTML = "Il campo IVA è obbligatorio";
	} else {
		if(iva < 0 || iva > 100) {
			document.getElementById("iva").innerHTML = "L'IVA deve essere compresa tra il 5% e il 95%";
		}
	}

    if(!validateScontoFields()) {
		valido = false;
	}	
	
	if(!validateNuovaTaglia()) {
		valido = false;
	}
	
	return valido;
}	

function checkNome(nome) {
	let nomePattern = /^[A-Za-zÀ-Úà-ú0-9]+(\s+[A-Za-zÀ-Úà-ú0-9]+)*$/;
	return nome.match(nomePattern) ? true : false;
}

function checkMarca(marca) {
	let marcaPattern = /^[A-Za-zÀ-Úà-ú0-9]+(\s+[A-Za-zÀ-Úà-ú0-9]+)*$/;
	return marca.match(marcaPattern) ? true : false;
}


function validateScontoFields() {
	
	var percentualeScontoInput = document.getElementById('taglie_percentuale_sconto').value.trim();
    var dataInizioInput = document.getElementById('taglie_data_inizio');
    var dataFineInput = document.getElementById('taglie_data_fine');
    var error_generico = document.getElementById('error-taglie-generico');

    var today = new Date();
    var yesterday = new Date(today);
    yesterday.setDate(today.getDate() - 1);

    if (percentualeScontoInput || dataInizioInput.value || dataFineInput.value) {
    	if (!percentualeScontoInput || !dataInizioInput.value || !dataFineInput.value) {
        	error_generico.innerHTML = "Tutti e tre i campi dello sconto devono essere riempiti.";
            return false;
        } else {
			if (dataInizioInput.value > dataFineInput.value) {
        		document.getElementById("error-taglie_data_inizio").innerHTML = "La data di inizio deve essere almeno uguale a quella di fine";
        		document.getElementById("error-taglie_data_fine").innerHTML = "Lo sconto deve finire almeno nello stesso giorno della data di inizio.";
        		return false;	
        	}
		}
	}
	return true;
}

function checkNomeTaglia(nomeTaglia) {
	let nomeTagliaPattern = /^(XS|S|M|L|XL|XXL|\d+(\.\d+|,\d+)?cm|\d+(\.\d+|,\d+)?X\d+(\.\d+|,\d+)?cm|\d+(\.\d+|,\d+)?X\d+(\.\d+|,\d+)?X\d+(\.\d+|,\d+)?cm)$/;
	return nomeTaglia.match(nomeTagliaPattern) ? true : false;
}

function checkPrezzoTaglia(prezzoTaglia) {
	let prezzoTagliaPattern = /^([0-9]{1,4}|[0-9]{1,4}(\.|,)[0-9]{1,2})$/;
	return prezzoTaglia.match(prezzoTagliaPattern) ? true : false;
}

function validateNuovaTaglia() {
    const nuovoNomeTagliaInput = document.getElementById('nuovo_nome_taglia');
    const nuovoPrezzoTagliaInput = document.getElementById('nuovo_prezzo_taglia');
    const nuovoQuantitaTagliaInput = document.getElementById('nuovo_quantita_taglia');
    const error_generico = document.getElementById('error-nuova-taglia-generico');
    
    let valido = true;
  
    
    if (nuovoNomeTagliaInput.value || nuovoPrezzoTagliaInput.value || nuovoQuantitaTagliaInput.value) {
    	if (!nuovoNomeTagliaInput.value || !nuovoPrezzoTagliaInput.value || !nuovoQuantitaTagliaInput.value) {
        	error_generico.innerHTML = "Tutti e tre i campi della nuova taglia devono essere riempiti.";
           	valido = false;
        } else {
			if(nuovoNomeTagliaInput.length > 20) {
				valido = false;
				document.getElementById("error-nuovo_nome_taglia").innerHTML = "Il nome della nuova taglia non può superare i 20 caratteri.";
		} else {
			if(!checkNomeTaglia(nuovoNomeTagliaInput.value)) {
       			valido = false;
       			document.getElementById("error-nuovo_nome_taglia").innerHTML = "Il nome della taglia deve essere XS, S, M, L, XL, XXL o una misura in cm (es. 30cm, 30X20cm, 30X20X10cm con o senza ,/.).";
       		}
		}
	}
	} else {
		error_generico.innerHTML = "Impossibile inserire il prodotto senza inserire una taglia.";
	}
    return valido;
}
function aggiungiCarta() {
	var messaggi_redirect = document.getElementById("contenitore-messaggiRedirect");
  	if(messaggi_redirect != null ) {messaggi_redirect.innerHTML = "";}
   	var contenitore = document.getElementById("contenitore-carte");
 	var form_carta = document.getElementById("form-carta");
 	var contenitore_parte_form = document.getElementById("azione-su-carta");
    contenitore.innerHTML= "";
    var azione_nome = document.getElementById("azione-nome");
    azione_nome.innerHTML = "Aggiungi una carta";
    var azione_inserimento = document.createElement("input");
    azione_inserimento.type = "hidden";
    azione_inserimento.name = "action";
    azione_inserimento.value = "inserimento";
    form_carta.insertBefore(azione_inserimento, document.getElementById("contenitore-submit"));
  	contenitore_parte_form.style.display = "block";
	contenitore.appendChild(contenitore_parte_form);
}

function modificaCarta(id_carta,scadenza,nome) {
	var messaggi_redirect = document.getElementById("contenitore-messaggiRedirect");
  	if(messaggi_redirect != null ) {messaggi_redirect.innerHTML = "";}
  	var contenitore = document.getElementById("contenitore-carte");
  	var form_carta = document.getElementById("form-modifica-carta");
 	var modifica_carta = document.getElementById("modifica-carta");
    contenitore.innerHTML= "";

    var azione_modifica = document.createElement("input");
    azione_modifica.type = "hidden";
    azione_modifica.name = "action";
    azione_modifica.value = "modifica_" + id_carta;
    form_carta.insertBefore(azione_modifica, document.getElementById("contenitore-submit-modifica"));
    
    document.getElementById("nome-completo-modifica").value = nome;
    
    var anno_mese = scadenza.split("-");
    var select_mese = document.getElementById("scadenza-mese-modifica");
    var select_anno = document.getElementById("scadenza-anno-modifica");
    rendiSelectedOpzione(select_mese, anno_mese[1]);
    rendiSelectedOpzione(select_anno, anno_mese[0]);

  	modifica_carta.style.display = "block";
	contenitore.appendChild(modifica_carta);
}

function rendiSelectedOpzione(select, valore) {
	n_opzioni = select.options.length;
	for (var i = 0; i < n_opzioni; i++) {
    	if (select.options[i].value == valore) {
        	select.options[i].selected = "selected";
            break;
        }
    }
}

function confermaEliminaCarta(id_carta,numero,scadenza,nome) {
	
	let messaggi = document.getElementsByClassName("messaggio");
    let n_messaggi = messaggi.length;

    for (let i = 0; i < n_messaggi; i++) {
        messaggi[i].innerHTML = "";
    }
	
	var contenitore_azioni = document.getElementById("bottoni-carta_" + id_carta);
	contenitore_azioni.innerHTML = ` <div>Eliminare la carta?</div>
								<button onClick="annullaconfermaEliminaCarta(\'` + id_carta + `\',\'` + numero + `\',\'` + scadenza + `\',\'` + nome + `\')" class="button-elimina">Annulla</button>
								<button onClick="eliminaCarta(` + id_carta + `)" class="button">Conferma</button>
							`;
}

function annullaconfermaEliminaCarta(id_carta,numero,scadenza,nome) {

	var contenitore_azioni = document.getElementById("bottoni-carta_" + id_carta);
	contenitore_azioni.innerHTML = ` <button onClick="confermaEliminaCarta(\'` + id_carta + `\',\'` + numero + `\',\'` + scadenza + `\',\'` + nome + `\')" class="button-elimina">Elimina</button>
								<button onClick="modificaCarta(\'` + id_carta + `\',\'` + numero + `\',\'` + scadenza + `\',\'` + nome + `\')" class="button">Modifica</button>
							`;
}

function eliminaCarta(id_carta) {
	
    var azione_inserimento = document.createElement("input");
    azione_inserimento.type = "hidden";
    azione_inserimento.name = "action";
    azione_inserimento.value = "elimina_" + id_carta;
    
    var form_indirizzo = document.getElementById("form-carta");
    form_indirizzo.innerHTML = "";
    form_indirizzo.appendChild(azione_inserimento);
    form_indirizzo.submit();
}

function submitFormInserisciCarta(form) {
	// Resetta tutti i messaggi di errore prima di eseguire la validazione
    let errorMessages = form.getElementsByClassName("form-error");
    let n_messaggi = errorMessages.length;
    for (let i = 0; i < n_messaggi; i++) {
        errorMessages[i].innerHTML = "";
    }
    var contenitore_messaggiRedirect = document.getElementById("contenitore-messaggiRedirect");
    if(contenitore_messaggiRedirect != null) {contenitore_messaggiRedirect.innerHTML = "";}
	
	if(validateFormInserisciCarta()) {
		form.submit();
	}
}

function validateFormInserisciCarta() {
	let valido = true;
	
	let numero = document.getElementById("numero").value.trim();
	let nome = document.getElementById("nome-completo").value.trim();
	let scadenza_mese = document.getElementById("scadenza-mese").value.trim()
	let scadenza_anno = document.getElementById("scadenza-anno").value.trim();
	let cvv = document.getElementById("cvv").value.trim();
	let oggi = new Date();
	let mese_corrente = oggi.getMonth() + 1;
	let anno_corrente = oggi.getFullYear();

	if (numero === "") {
        valido = false;
        document.getElementById("error-numero").innerHTML = "Il campo numero è obbligatorio.";
    } else {
      	if(!checkNumero(numero)) {
       		valido = false;
       		document.getElementById("error-numero").innerHTML = "Numero della carta non valido, deve contenere al massimo 16 cifre";
       	}
    }

	if (nome === "") {
    	valido = false;
        document.getElementById("error-nomeCompleto").innerHTML = "Il campo nome è obbligatorio.";
    } else {
       	if(!checkNome(nome)) {
       		valido = false;
       		document.getElementById("error-nomeCompleto").innerHTML = "Nome sulla carta non valido, può contenere solo lettere,spazi, apici singoli e trattini.";
       	} 
    }
        
    if (cvv === "") {
        valido = false;
        document.getElementById("error-cvv").innerHTML = "Il campo CVV è obbligatorio.";
    } else {
       	if(!checkCVV(cvv)) {
      		valido = false;
      		document.getElementById("error-cvv").innerHTML = "CVV non valido, può contenere al massimo 4 cifre";
       	}
    } 
		
	if(scadenza_mese < mese_corrente && scadenza_anno <= anno_corrente) {
		document.getElementById("error-scadenza").innerHTML = "Carta già scaduta.";
       	valido = false;	
	}

 return valido;
}	



function submitFormModificaCarta(form) {
	// Resetta tutti i messaggi di errore prima di eseguire la validazione
    let errorMessages = form.getElementsByClassName("form-error");
    let n_messaggi = errorMessages.length;
    for (let i = 0; i < n_messaggi; i++) {
        errorMessages[i].innerHTML = "";
    }
	
	if(validateFormModificaCarta()) {
		form.submit();
	}
}

function validateFormModificaCarta() {
	let valido = true;
	
	let nome = document.getElementById("nome-completo-modifica").value.trim();
	let scadenza_mese = document.getElementById("scadenza-mese-modifica").value.trim();
	let scadenza_anno = document.getElementById("scadenza-anno-modifica").value.trim();
	let oggi = new Date();
	let mese_corrente = oggi.getMonth() + 1;
	let anno_corrente = oggi.getFullYear();

	if (nome === "") {
    	valido = false;
        document.getElementById("error-nomeCompleto-modifica").innerHTML = "Il campo nome è obbligatorio.";
    } else {
       	if(!checkNome(nome)) {
       		valido = false;
       		document.getElementById("error-nomeCompleto-modifica").innerHTML = "Nome sulla carta non valido, può contenere solo lettere,spazi, apici singoli e trattini.";
       	} 
    }
		
	if(scadenza_mese < mese_corrente && scadenza_anno <= anno_corrente) {
		document.getElementById("error-scadenza-modifica").innerHTML = "Carta già scaduta.";
       	valido = false;	
	}
 return valido;
}


function checkNumero(numero) {
	let numeroPattern = /^([0-9]{10,16})$/;
	return numero.match(numeroPattern) ? true : false;
}

function checkNome(nome) {
	let nomePattern = /^[A-Za-zÀ-Úà-ú]+(\s*('|-)\s*[A-Za-zÀ-Úà-ú]+)?(\s+[A-Za-zÀ-Úà-ú]+)*$/;
	return nome.match(nomePattern) ? true : false;
}

function checkCVV(cvv) {
	let cvvPattern = /^([0-9]{3,4})$/;
	return cvv.match(cvvPattern) ? true : false;
}
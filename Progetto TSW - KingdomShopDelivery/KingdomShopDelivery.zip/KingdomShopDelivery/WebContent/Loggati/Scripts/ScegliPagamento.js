function mostraCarte() {
	var cartaDiv = document.getElementById("metodo-carta");
    var selezionaCartaDiv = document.getElementById("carta-seleziona-carta");
    selezionaCartaDiv.style.display = "block"; // Mostra il div delle carte
    cartaDiv.appendChild(selezionaCartaDiv);
    var consegnaDiv = document.getElementById("informazioni-MetodoConsegna");
    consegnaDiv.style.display = "none"; // Nasconde il div delle informazioni di consegna
}


function informazioniMetodoConsegna() {
	var consegnaDiv = document.getElementById("metodo-consegna");
    var informazioniConsegnaDiv = document.getElementById("informazioni-MetodoConsegna");
    informazioniConsegnaDiv.style.display = "block"; // Mostra il div delle informazioni di consegna
    consegnaDiv.appendChild(informazioniConsegnaDiv);

    var cartaDiv = document.getElementById("carta-seleziona-carta");
    cartaDiv.style.display = "none"; // Nasconde il div delle carte (se era visibile)
}

function submitForm(form) {
	
	// Resetta tutti i messaggi di errore prima di eseguire la validazione
    let errorMessages = form.getElementsByClassName("form-error");
    let n_messaggi = errorMessages.length;
    for (let i = 0; i < n_messaggi; i++) {
        errorMessages[i].innerHTML = ""; //verificare se utilizzare innerText o innerHTML
    }
    
    if(validateForm()) {
		form.submit();
	}
}

function validateForm() {
		
	let valido = true;
	
	const radio_metodo = document.getElementsByName('metodo-pagamento');
    let selezionato_metodo = false;
    let metodo_selezionato;
    
    for (let i = 0; i < radio_metodo.length; i++) {
        if (radio_metodo[i].checked) {
            selezionato_metodo = true;
            metodo_selezionato = radio_metodo[i].value;
            break;
        }
    }
    
    if (!selezionato_metodo) {
        document.getElementById("error-metodoPagamento").innerHTML = "Scegli un metodo di pagamento.";
        valido = false;
    } else {
		if(metodo_selezionato == "carta") {
			let selezionata_carta = false;
			const radio_carta = document.getElementsByName("seleziona-carta");
			
			for (let i = 0; i < radio_carta.length; i++) {
        		if (radio_carta[i].checked) {
            		selezionata_carta = true;
            		break;
        		}
    		}
    		
    		if(!selezionata_carta) {
				document.getElementById("error-selezionaCarta").innerHTML = "Selezionare una carta di credito."
				valido = false;
			}
		}
	}
       
 return valido;
}	

function submitForm(form) {
	
	// Resetta tutti i messaggi di errore prima di eseguire la validazione
    let errorMessages = form.getElementsByClassName("form-error");
    let n_messaggi = errorMessages.length;
    for (let i = 0; i < n_messaggi; i++) {
        errorMessages[i].innerHTML = "";
    }
    
    if(validateForm()) {
		form.submit();
	}
}

function validateForm() {
		
	let valido = true;
	
	const radio_spedizione = document.getElementsByName('indirizzo_spedizione');
    let selezionato_spedizione = false;
    const radio_fatturazione = document.getElementsByName('indirizzo_fatturazione');
    let selezionato_fatturazione = false;
    
    for (let i = 0; i < radio_spedizione.length; i++) {
        if (radio_spedizione[i].checked) {
            selezionato_spedizione = true;
            break;
        }
    }
    
    if (!selezionato_spedizione) {
        document.getElementById("error-indirizzoSpedizione").innerHTML = "Scegli un indirizzo di spedizione.";
        valido = false;
    }
    
    for (let i = 0; i < radio_fatturazione.length; i++) {
        if (radio_fatturazione[i].checked) {
            selezionato_fatturazione = true;
            break;
        }
    }
    
    if (!selezionato_fatturazione) {
        document.getElementById("error-indirizzoFatturazione").innerHTML = "Scegli un indirizzo di fatturazione.";
        valido = false;
    }
    
    let noteSpedizione = document.getElementById("spedizione-note");
    
    if(noteSpedizione.value.trim().length > 500) {
		document.getElementById("error-noteSpedizione").innerHTML = "Le note di spedizione non devono superare i 500 caratteri";
	}
       
 return valido;
}	
function aggiungiIndirizzo() {
	var messaggi_redirect = document.getElementById("contenitore-messaggiRedirect");
  	if(messaggi_redirect != null ) {messaggi_redirect.innerHTML = "";}
   	var contenitore = document.getElementById("contenitore-indirizzi");
 	var form_indirizzo = document.getElementById("form-indirizzo");
 	var contenitore_parte_form = document.getElementById("azione-su-indirizzo");
    contenitore.innerHTML= "";
    var azione_nome = document.getElementById("azione-nome");
    azione_nome.innerHTML = "Aggiungi un indirizzo";
    var azione_inserimento = document.createElement("input");
    azione_inserimento.type = "hidden";
    azione_inserimento.name = "action";
    azione_inserimento.value = "inserimento";
    form_indirizzo.insertBefore(azione_inserimento, document.getElementById("contenitore-submit"));
  	contenitore_parte_form.style.display = "block";
	contenitore.appendChild(contenitore_parte_form);
}

function modificaIndirizzo(id_indirizzo,nome,cognome,via,civico,cap,citta,provincia,paese,tipo) {

	var messaggi_redirect = document.getElementById("contenitore-messaggiRedirect");
  	if(messaggi_redirect != null ) {messaggi_redirect.innerHTML = "";}
  	var contenitore = document.getElementById("contenitore-indirizzi");
  	var form_indirizzo = document.getElementById("form-indirizzo");
 	var modifica_indirizzo = document.getElementById("azione-su-indirizzo");
    contenitore.innerHTML= "";
    var azione_nome = document.getElementById("azione-nome");
    azione_nome.innerHTML = "Modifica l'indirizzo";
    var azione_modifica = document.createElement("input");
    azione_modifica.type = "hidden";
    azione_modifica.name = "action";
    azione_modifica.value = "modifica_" + id_indirizzo;
    form_indirizzo.insertBefore(azione_modifica, document.getElementById("contenitore-submit"));
    document.getElementById("nome").value = nome;
    document.getElementById("cognome").value = cognome;
    document.getElementById("via").value = via;
    document.getElementById("civico").value = civico;
    document.getElementById("cap").value = cap;
    document.getElementById("citta").value = citta;
    document.getElementById("provincia").value = provincia;
    document.getElementById("paese").value = paese;
    
    if(tipo == "Spedizione-Fatturazione") {
		document.getElementById("spedizione").checked = true;
		document.getElementById("fatturazione").checked = true;
	} else {
		if(tipo == "Spedizione") {document.getElementById("spedizione").checked = true;}
		if(tipo == "Fatturazione") {document.getElementById("fatturazione").checked = true;}
	}
  	modifica_indirizzo.style.display = "block";
	contenitore.appendChild(modifica_indirizzo);
}

function confermaEliminaIndirizzo(id_indirizzo,nome,cognome,via,civico,cap,citta,provincia,paese,tipo) {
	
	let messaggi = document.getElementsByClassName("messaggio");
    let n_messaggi = messaggi.length;

    for (let i = 0; i < n_messaggi; i++) {
        messaggi[i].innerHTML = "";
    }
	

	var contenitore_azioni = document.getElementById("bottoni-indirizzo_" + id_indirizzo);
	contenitore_azioni.innerHTML = ` <div>Eliminare l'indirizzo?</div> 
								<button onClick="annullaConfermaEliminaIndirizzo(\'` + id_indirizzo + `\',\'` + nome + `\',\'` + cognome + `\',\'` + via + `\',\'` + civico + `\',\'` + cap + `\',\'` + citta + `\',\'` + provincia + `\',\'` + paese + `\',\'` + tipo + `\')" class="button-elimina">Annulla</button>
								<button onClick="eliminaIndirizzo(` + id_indirizzo + `)" class="button">Conferma</button>
							`;
}

function annullaConfermaEliminaIndirizzo(id_indirizzo,nome,cognome,via,civico,cap,citta,provincia,paese,tipo) {

	var contenitore_azioni = document.getElementById("bottoni-indirizzo_" + id_indirizzo);
	contenitore_azioni.innerHTML = ` <button onClick="confermaEliminaIndirizzo(` + id_indirizzo + `,\'` + nome + `\',\'` + cognome + `\',\'` + via + `\',\'` + civico + `\',\'` + cap + `\',\'` + citta + `\',\'` + provincia + `\',\'` + paese + `\',\'` + tipo + `\')" class="button-elimina">Elimina</button>
								<button onClick="modificaIndirizzo(` + id_indirizzo + `,\'` + nome + `\',\'` + cognome + `\',\'` + via + `\',\'` + civico + `\',\'` + cap + `\',\'` + citta + `\',\'` + provincia + `\',\'` + paese + `\',\'` + tipo + `\')" class="button">Modifica</button>
							`;
}

function eliminaIndirizzo(id_indirizzo) {
	
    var azione_inserimento = document.createElement("input");
    azione_inserimento.type = "hidden";
    azione_inserimento.name = "action";
    azione_inserimento.value = "elimina_" + id_indirizzo;
    
    var form_indirizzo = document.getElementById("form-indirizzo");
    form_indirizzo.innerHTML = "";
    form_indirizzo.appendChild(azione_inserimento);
    form_indirizzo.submit();
}


function submitForm(form) {
	
	// Resetta tutti i messaggi di errore prima di eseguire la validazione
    let errorMessages = form.getElementsByClassName("form-error");
    let n_messaggi = errorMessages.length;
    for (let i = 0; i < n_messaggi; i++) {
        errorMessages[i].innerHTML = "";
    }
    var contenitore_messaggiRedirect = document.getElementById("contenitore-messaggiRedirect");
    if(contenitore_messaggiRedirect != null) {contenitore_messaggiRedirect.innerHTML = "";}
	
	if(validateForm()) {
		form.submit();
	}
}

function validateForm() {

	let valido = true;
		
	let nome = document.getElementById("nome").value.trim();
	let cognome = document.getElementById("cognome").value.trim();
	let via = document.getElementById("via").value.trim();
	let civico = document.getElementById("civico").value.trim();
	let cap = document.getElementById("cap").value.trim();
	let citta = document.getElementById("citta").value.trim();
	let provincia = document.getElementById("provincia").value.trim();
	let paese = document.getElementById("paese").value.trim();
	let tipo_spedizione = document.getElementById("spedizione").checked;
	let tipo_fatturazione = document.getElementById("fatturazione").checked;

	if (nome === "") {
    	valido = false;
        document.getElementById("error-nome").innerHTML = "Il campo nome è obbligatorio.";
    } else {
       	if(!checkNome(nome)) {
       		valido = false;
       		document.getElementById("error-nome").innerHTML = "Nome non valido, può contenere solo lettere e spazi.";
       	} 
    }
		
    if (cognome === "") {
        valido = false;
        document.getElementById("error-cognome").innerHTML = "Il campo cognome è obbligatorio.";
    } else {
      	if(!checkCognome(cognome)) {
      		valido = false;
      		document.getElementById("error-cognome").innerHTML = "Cognome non valido, può contenere solo lettere, spazi, apici singoli e trattini.";
       	}
    }
        
    if (via === "") {
        valido = false;
        document.getElementById("error-via").innerHTML = "Il campo via è obbligatorio.";
    } else {
       	if(!checkVia(via)) {
      		valido = false;
      		document.getElementById("error-via").innerHTML = "Via non valida, può contenere solo lettere, spazi, apici singoli, trattini e numeri.";
       	}
    }
        
    if (civico === "") {
        valido = false;
        document.getElementById("error-civico").innerHTML = "Il campo civico è obbligatorio.";
    } else {
      	if(!checkCivico(civico)) {
       		valido = false;
       		document.getElementById("error-civico").innerHTML = "Civico non valido, deve contenere al massimo 5 cifre";
       	}
    }
        
    if (cap === "") {
        valido = false;
        document.getElementById("error-cap").innerHTML = "Il campo CAP è obbligatorio.";
    } else {
       	if(!checkCap(cap)) {
       		valido = false;
       		document.getElementById("error-cap").innerHTML = "CAP non valido, deve contenere esattamente 5 cifre.";
       	}
    }
        
    if (citta === "") {
        valido = false;
        document.getElementById("error-citta").innerHTML = "Il campo città è obbligatorio.";
    } else {
      	if(!checkCitta(citta)) {
       		valido = false;
       		document.getElementById("error-citta").innerHTML = "Città non valida, può contenere solo lettere, spazi,apostrofi e trattini";
       	}
    } 
    
    if (provincia === "") {
        valido = false;
        document.getElementById("error-provincia").innerHTML = "Il campo provincia è obbligatorio.";
    } else {
      	if(!checkProvincia(provincia)) {
       		valido = false;
       		document.getElementById("error-provincia").innerHTML = "Provincia non valida, può contenere solo lettere, spazi,apostrofi e trattini";
       	}
    } 
    
    if (paese === "") {
        valido = false;
        document.getElementById("error-paese").innerHTML = "Il campo paese è obbligatorio.";
    } else {
      	if(!checkPaese(paese)) {
       		valido = false;
       		document.getElementById("error-paese").innerHTML = "Paese non valido, può contenere solo lettere, spazi,apostrofi e trattini";
       	}
    } 
    
    if (!tipo_spedizione && !tipo_fatturazione) {
        document.getElementById("error-tipo").innerHTML = "Seleziona almeno una delle due opzioni.";
        valido = false;
    }

 return valido;
}	

function checkNome(nome) {
	let nomePattern = /^[A-Za-zÀ-Úà-ú]+(\s+[A-Za-zÀ-Úà-ú]+)*$/;
	return nome.match(nomePattern) ? true : false;
}
	
function checkCognome(cognome) {
	let cognomePattern = /^[A-Za-zÀ-Úà-ú]+(\s*('|-)\s*[A-Za-zÀ-Úà-ú]+)?(\s+[A-Za-zÀ-Úà-ú]+)*$/;
	return cognome.match(cognomePattern) ? true : false;
}
	
function checkVia(via) {
	let viaPattern = /^[A-Za-zÀ-Úà-ú\s\.,'\-0-9]+$/; 
	return via.match(viaPattern) ? true : false;
}

function checkCivico(civico) {
	let civicoPattern = /^([0-9]{1,5})$/;
	return civico.match(civicoPattern) ? true : false;
}
	
function checkCap(cap) {
	let capPattern =  /^([0-9]{5})$/;
	return cap.match(capPattern) ? true : false;
}
	
function checkCitta(citta) {
	let cittaPattern = /^[A-Za-zÀ-Úà-ú\s'-]+$/; 
	return citta.match(cittaPattern) ? true : false;
}

function checkProvincia(provincia) {
	let provinciaPattern = /^[A-Za-zÀ-Úà-ú\s'-]+$/;
	return provincia.match(provinciaPattern) ? true : false;
}

function checkPaese(paese) {
	let paesePattern = /^[A-Za-zÀ-Úà-ú\s'-]+$/;
	return paese.match(paesePattern) ? true : false;
}
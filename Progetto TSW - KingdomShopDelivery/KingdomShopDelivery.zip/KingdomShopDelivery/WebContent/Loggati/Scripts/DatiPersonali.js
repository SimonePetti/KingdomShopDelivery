function modificaDatiPersonali(nome,cognome,prefisso,telefono) {
	var contenitore = document.getElementById("contenitore-datiPersonali");
	contenitore.innerHTML = "";
	var contenitore_form_modificaDati = document.getElementById("contenitore-form-modificaDati");
	var form_modificaDati = document.getElementById("form-modificaDati");
	
	var azione_modificaDati = document.createElement("input");
    azione_modificaDati.type = "hidden";
    azione_modificaDati.name = "action";
    azione_modificaDati.value = "modificaDati";
    form_modificaDati.insertBefore(azione_modificaDati, document.getElementById("contenitore-submit-modificaDati"));
  	contenitore_form_modificaDati.style.display = "block";
  	document.getElementById("nome").value = nome;
  	document.getElementById("cognome").value = cognome;
  	document.getElementById("prefissoTelefono").value = prefisso;
  	document.getElementById("numeroTelefono").value = telefono;
	contenitore.appendChild(contenitore_form_modificaDati);
}

function submitFormModificaDati(form) {

	// Resetta tutti i messaggi di errore prima di eseguire la validazione
    let errorMessages = form.getElementsByClassName("form-error");
    let n_messaggi = errorMessages.length;
    for (let i = 0; i < n_messaggi; i++) {
        errorMessages[i].innerHTML = "";
    }
	
	if(validateFormModificaDati()) {
		form.submit();
	}
}

function validateFormModificaDati() {
		
	let valido = true;
		
	let nome = document.getElementById("nome").value.trim();
	let cognome = document.getElementById("cognome").value.trim();
	let prefissoTelefono = document.getElementById("prefissoTelefono").value.trim();
	let numeroTelefono = document.getElementById("numeroTelefono").value.trim();

	if (nome === "") {
    	valido = false;
        document.getElementById("error-nome").innerHTML = "Il campo nome è obbligatorio.";
    } else {
       	if(!checkNome(nome)) {
       		valido = false;
       		document.getElementById("error-nome").innerHTML = "Nome non valido, può contenere solo lettere e spazi.";
       	} 
    }
		
    if (cognome === "") {
        valido = false;
        document.getElementById("error-cognome").innerHTML = "Il campo cognome è obbligatorio.";
    } else {
      	if(!checkCognome(cognome)) {
      		valido = false;
      		document.getElementById("error-cognome").innerHTML = "Cognome non valido, può contenere solo lettere,spazi, apici singoli e trattini.";
       	}
    }
        
    if (prefissoTelefono === "") {
        valido = false;
        document.getElementById("error-prefissoTelefono").innerHTML = "Il campo prefisso telefonico è obbligatorio.";
    } else {
       	if(!checkPrefissoTelefono(prefissoTelefono)) {
       		valido = false;
       		document.getElementById("error-prefissoTelefono").innerHTML = "Prefisso telefonico non valido.";
       	}
    }
        
    if (numeroTelefono === "") {
        valido = false;
        document.getElementById("error-numeroTelefono").innerHTML = "Il campo numero di telefono è obbligatorio.";
    } else {
      	if(!checkNumeroTelefono(numeroTelefono)) {
       		valido = false;
       		document.getElementById("error-numeroTelefono").innerHTML = "Numero di telefono non valido.";
       	}
    }        
 return valido;
}	

function checkNome(nome) {
	let nomePattern = /^[A-Za-zÀ-Úà-ú]+(\s+[A-Za-zÀ-Úà-ú]+)*$/;
	return nome.match(nomePattern) ? true : false;
}
	
function checkCognome(cognome) {
	let cognomePattern = /^[A-Za-zÀ-Úà-ú]+(\s*('|-)\s*[A-Za-zÀ-Úà-ú]+)?(\s+[A-Za-zÀ-Úà-ú]+)*$/;
	return cognome.match(cognomePattern) ? true : false;
}
	
function checkPrefissoTelefono(prefissoTelefono) {
	let prefissoTelefonoPattern = /^([0-9]{1,3})$/; 
	return prefissoTelefono.match(prefissoTelefonoPattern) ? true : false;
}
	
function checkNumeroTelefono(numeroTelefono) {
	let numeroTelefonoPattern = /^([0-9]{10})$/;
	return numeroTelefono.match(numeroTelefonoPattern) ? true : false;
}

function modificaEmail(email) {
	
	var contenitore = document.getElementById("contenitore-datiPersonali");
	contenitore.innerHTML = "";
	var contenitore_form_modificaEmail = document.getElementById("contenitore-form-modificaEmail");
	var form_modificaEmail = document.getElementById("form-modificaEmail");
	
	var azione_modificaEmail = document.createElement("input");
    azione_modificaEmail.type = "hidden";
    azione_modificaEmail.name = "action";
    azione_modificaEmail.value = "modificaEmail";
    form_modificaEmail.insertBefore(azione_modificaEmail, document.getElementById("contenitore-submit-modificaEmail"));
  	contenitore_form_modificaEmail.style.display = "block";
  	document.getElementById("emailAttuale").value = email;
	contenitore.appendChild(contenitore_form_modificaEmail);

}

function submitFormModificaEmail(form) {

	// Resetta tutti i messaggi di errore prima di eseguire la validazione
    let errorMessages = form.getElementsByClassName("form-error");
    let n_messaggi = errorMessages.length;
    for (let i = 0; i < n_messaggi; i++) {
        errorMessages[i].innerHTML = "";
    }
    
    var error_generico = document.getElementById("error-generico");
    if(error_generico != null) {error_generico.innerHTML = "";}
    
    var email = document.getElementById("emailNuova").value;
	
	if(validateFormModificaEmail()) {
		checkEmailExistence(email, form);
	}
}

function validateFormModificaEmail() {
		
	let valido = true;
		
	let emailAttuale = document.getElementById("emailAttuale").value.trim();
	let emailNuova = document.getElementById("emailNuova").value.trim();
	let password = document.getElementById("password").value.trim();
	
	if(emailAttuale == emailNuova) {
		document.getElementById("error-emailNuova").innerHTML = "La nuova email deve essere diversa da quella attuale.";
		return false;
	}
        
    if (emailAttuale === "") {
        valido = false;
        document.getElementById("error-emailAttuale").innerHTML = "Il campo email è obbligatorio.";
    } else {
       	if(!checkEmail(emailAttuale)) {
      		valido = false;
      		document.getElementById("error-emailAttuale").innerHTML = "Email non valida, può contenere solo lettere, spazi, apici singoli, trattini, punti, numeri e una @.";
       	}
    }
    
    if (emailNuova === "") {
        valido = false;
        document.getElementById("error-emailNuova").innerHTML = "Il campo email è obbligatorio.";
    } else {
       	if(!checkEmail(emailNuova)) {
      		valido = false;
      		document.getElementById("error-emailNuova").innerHTML = "Email non valida, può contenere solo lettere, spazi, apici singoli, trattini, punti, numeri e una @.";
       	}
    }
        
    if (password === "") {
        valido = false;
        document.getElementById("error-password").innerHTML = "Il campo password è obbligatorio.";
    } else {
      	if(!checkPassword(password)) {
       		valido = false;
       		document.getElementById("error-password").innerHTML = "Password non valida";
       	}
    }       
 return valido;
}	

function checkEmailExistence(email, form) {
	let xhr = new XMLHttpRequest();
    xhr.open("POST", "../checkEmail", true);
    xhr.setRequestHeader("Content-Type", "application/json");
    xhr.setRequestHeader("Connection", "close");//Google rifiuta questo header
        
    // Flag per determinare se la richiesta è stata abortita
    let aborted = false;

	// Timeout per abortire la richiesta dopo 10 secondi
    let timeout = setTimeout(function() {
    	if (xhr.readyState < 4) {
    		xhr.abort();
        	aborted = true;
        	
        	var error_generico = document.getElementById("error-generico");
        	if(error_generico != null) {
				error_generico.innerHTML = "La richiesta di modifica ha superato il tempo limite. Riprova più tardi";
			} else {
				error_generico = document.createElement("div");
				error_generico.id = "error-generico";
        		error_generico.className = "error-generico";
        		error_generico.innerHTML = "La richiesta di modifica ha superato il tempo limite. Riprova più tardi";
        		form.appendChild(error_generico);
			}
		}
	}, 10000); // 10 secondi    

	xhr.onreadystatechange = function() {
    	if(xhr.readyState === 4) {
    		clearTimeout(timeout); // Cancella il timeout se la richiesta è completata
        	if(!aborted) { 
        		if(xhr.status === 200) {
        			//Richiesta andata a buon fine
            		let response = JSON.parse(xhr.responseText);
            		
            		if (response.EmailGiaPresente == "true") {
                		document.getElementById("error-emailAttuale").innerHTML = "Esiste già un account con questa email.";
                	} else {
						form.submit();
					}
				} else {
            		//Altri problemi
            		
            		var error_generico = document.getElementById("error-generico");
        			if(error_generico != null) {
						error_generico.innerHTML = "Errore durante la modifica. Riprova più tardi";
					} else {
						error_generico = document.createElement("div");
						error_generico.id = "error-generico";
        				error_generico.className = "error-generico";
        				error_generico.innerHTML = "Errore durante la modifica. Riprova più tardi";
        				form.appendChild(error_generico);
					}
            	}	
        	}
		}
	};    
	xhr.send(JSON.stringify({ EmailDaControllare : email}));
}


function modificaPassword(email) {
	var contenitore = document.getElementById("contenitore-datiPersonali");
	contenitore.innerHTML = "";
	var contenitore_form_modificaPassword = document.getElementById("contenitore-form-modificaPassword");
	var form_modificaPassword = document.getElementById("form-modificaPassword");
	
	var azione_modificaPassword = document.createElement("input");
    azione_modificaPassword.type = "hidden";
    azione_modificaPassword.name = "action";
    azione_modificaPassword.value = "modificaPassword";
    form_modificaPassword.insertBefore(azione_modificaPassword, document.getElementById("contenitore-submit-modificaPassword"));
  	contenitore_form_modificaPassword.style.display = "block";
  	document.getElementById("email").value = email;
	contenitore.appendChild(contenitore_form_modificaPassword);
}


function submitFormModificaPassword(form) {

	// Resetta tutti i messaggi di errore prima di eseguire la validazione
    let errorMessages = form.getElementsByClassName("form-error");
    let n_messaggi = errorMessages.length;
    for (let i = 0; i < n_messaggi; i++) {
        errorMessages[i].innerHTML = "";
    }
	
	if(validateFormModificaPassword()) {
		form.submit();
	}
}

function validateFormModificaPassword() {
		
	let valido = true;
		
	let email = document.getElementById("email").value.trim();
	let passwordAttuale = document.getElementById("passwordAttuale").value.trim();
	let passwordNuova = document.getElementById("passwordNuova").value.trim();

	if (email === "") {
        valido = false;
        document.getElementById("error-email").innerHTML = "Il campo email è obbligatorio.";
    } else {
       	if(!checkEmail(email)) {
      		valido = false;
      		document.getElementById("error-email").innerHTML = "Email non valida, può contenere solo lettere, spazi, apici singoli, trattini, punti, numeri e una @.";
       	}
    }
    
    if (passwordAttuale === "") {
        valido = false;
        document.getElementById("error-passwordAttuale").innerHTML = "Il campo password è obbligatorio.";
    } else {
      	if(!checkPassword(passwordAttuale)) {
       		valido = false;
       		document.getElementById("error-passwordAttuale").innerHTML = "Password non valida.";
       	}
    }
    
    if (passwordNuova === "") {
        valido = false;
        document.getElementById("error-passwordNuova").innerHTML = "Il campo password è obbligatorio.";
    } else {
      	if(!checkPassword(passwordNuova)) {
       		valido = false;
       		document.getElementById("error-passwordNuova").innerHTML = "Password non valida, deve essere lunga almeno 6 caratteri e contenere almeno: una lettera minuscola, una lettera maiuscola, un numero e un carattere speciale.";
       	}
    }
	       
 return valido;
}	

function checkEmail(email) {
	let emailPattern = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
	return email.match(emailPattern) ? true : false;
}
	
function checkPassword(password) {
	let passwordPattern = /^(?=.*[A-ZÀ-Ù])(?=.*[a-zà-ù])(?=.*\d)(?=.*[^\w\d\s]).{6,}$/;
	return password.match(passwordPattern) ? true : false;
}